package sci.tool.function;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.util.Log;


/** SIM.java: 获取手机SIM卡信息，需添加权限<uses-permission android:name="android.permission.READ_PHONE_STATE"/> ----- 2017-12-27 下午8:26:14 */
public class SIM
{
	private static TelephonyManager manager;
	
	private SIM(Context paramContext)
	{
		System.out.println("SIM卡信息：\r\n" + Info(paramContext));
	}
	
	public static String Info(Context paramContext)
	{
		StringBuilder tmp = new StringBuilder();
		tmp.append("deviceId: " + deviceId(paramContext) + "\r\n");
		tmp.append("NetworkType: " + getNetworkType(paramContext) + "\r\n");
		tmp.append("PhoneNumber: " + getPhoneNumber(paramContext) + "\r\n");
		tmp.append("PhoneType: " + getPhoneType(paramContext) + "\r\n");
		tmp.append("SimOperator: " + getSimOperator(paramContext) + "\r\n");
		tmp.append("SimOperatorName: " + getSimOperatorName(paramContext) + "\r\n");
		tmp.append("SimSerialNumber: " + getSimSerialNumber(paramContext) + "\r\n");
		tmp.append("SimState: " + getSimState(paramContext) + "\r\n");
		tmp.append("SimType: " + getSimType(paramContext) + "\r\n");
		tmp.append("SubscriberId: " + getSubscriberId(paramContext) + "\r\n");
		tmp.append("hasSim: " + hasSim(paramContext) + "\r\n");
		tmp.append("isStateReady: " + isStateReady(paramContext) + "\r\n");
		
		return tmp.toString();
	}
	
	private static TelephonyManager getManager(Context paramContext)
	{
		if (manager == null)
		{
			try
			{
				manager = (TelephonyManager) paramContext.getSystemService("phone");
			}
			finally
			{}
		}
		
		return manager;
	}
	
	public static final String deviceId(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager != null) { return localTelephonyManager.getDeviceId(); }
		return "";
	}
	
	public static final int getNetworkType(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager != null)
		{
			int i = localTelephonyManager.getNetworkType();
			Log.i("LOG", "type:" + i);
			return i;
		}
		return 0;
	}
	
	public static final String getPhoneNumber(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return "";
		try
		{
			String str = localTelephonyManager.getLine1Number();
			return str;
		}
		catch (Throwable localThrowable)
		{}
		return "";
	}
	
	public static final int getPhoneType(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return 0;
		return localTelephonyManager.getPhoneType();
	}
	
	public static final String getSimOperator(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return "";
		return localTelephonyManager.getSimOperator();
	}
	
	public static final String getSimOperatorName(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return "";
		return localTelephonyManager.getSimOperatorName();
	}
	
	public static final String getSimSerialNumber(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return "";
		return localTelephonyManager.getSimSerialNumber();
	}
	
	public static final int getSimState(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return 0;
		return localTelephonyManager.getSimState();
	}
	
	public static final String getSimType(Context paramContext)
	{
		String str = "";
		if (isStateReady(paramContext)) str = getSimOperator(paramContext);
		return str;
	}
	
	public static final String getSubscriberId(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		if (localTelephonyManager == null) return "";
		return localTelephonyManager.getSubscriberId();
	}
	
	public static final boolean hasSim(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		return (localTelephonyManager != null) && (localTelephonyManager.getSimState() == 1);
	}
	
	public static final boolean isStateReady(Context paramContext)
	{
		TelephonyManager localTelephonyManager = getManager(paramContext);
		return (localTelephonyManager != null) && (localTelephonyManager.getSimState() == 5);
	}
}
