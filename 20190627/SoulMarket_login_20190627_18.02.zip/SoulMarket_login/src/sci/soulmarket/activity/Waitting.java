package sci.soulmarket.activity;

import sci.tool.function.ActivityComponent;
import android.os.Bundle;


public class Waitting extends ActivityComponent
{
	/** 处理逻辑对象参数 */
	public static abstract class WaittingPram
	{
		/** 需要在线程中执行的逻辑 */
		public abstract void Function();
	}
	
	@Override
	public void Init(Bundle savedInstanceState)
	{
		setContentView("layout_waitting");
		
//		CallBackF call = new CallBackF()
//		{
//			@Override
//			public void F()
//			{
//				Instatnce.finish();
//				Tools.ShowActivity(Instatnce, Announcement.class, "appId", LtSDK.AppId);
//			}
//		};
//		
//		Tools.AutoHide(Instatnce, 3000, call);
	}

	@Override
	public void Click(String viewId)
	{
		// TODO Auto-generated method stub
	}

	@Override
	public void onBackPressed()
	{
		
	}
	
}
