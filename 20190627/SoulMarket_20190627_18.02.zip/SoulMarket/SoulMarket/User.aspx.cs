﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoulMarket
{
    public partial class User : System.Web.UI.Page
    {
        string TYPE = "";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            ScTool.getParam(Request, this);
            TYPE = Request["TYPE"];
            
            string data = "";
            if (TYPE == null)
            {
                NoteInfo();

                InitDB();
                ScTool.showTable(this.Controls, DB, TAB);
            }
            else
            {
                TYPE = TYPE.Trim().ToLower();
                string NAME = Request["NAME"];
                string PASS = Request["PASS"];

                if (TYPE.Equals("add"))
                {
                    data = add(NAME, PASS);
                }
                else if (TYPE.Equals("update"))
                {
                    data = update(NAME, PASS, Request["token"], Request["NickName"], Request["RealName"], Request["IdCard"], Request["Address"], Request["ext"]);
                }
                else if (TYPE.Equals("delete"))
                {
                    data = delete(NAME);
                }
                else if (TYPE.Equals("checkuser"))
                {
                    data = checkUser(NAME);
                }
                else if (TYPE.Equals("login"))
                {
                    data = login(NAME, PASS);
                }
                else if (TYPE.Equals("checktoken"))
                {
                    data = checkToken(Request["ID"], Request["token"]);
                }
                else if (TYPE.Equals("logout"))
                {
                    data = logout(NAME, PASS);
                }

                Response.Write(data);
            }
        }

        /// <summary>
        /// 接口使用说明信息
        /// </summary>
        private void NoteInfo()
        {
            String url = "http://" + Request.Params.Get("HTTP_HOST") + "/" + this.GetType().Name.Replace("_", "/").Replace("/aspx", ".aspx") + "?";
            StringBuilder builder = new StringBuilder();

            builder.AppendLine("接口使用说明：");
            builder.AppendLine("");
            builder.AppendLine("添加：\t" + url + "TYPE=add&NAME=用户名&PASS=密码");
            builder.AppendLine("修改：\t" + url + "TYPE=update&NAME=用户名&PASS=密码&token=xxx&NickName=昵称&RealName=小明&IdCard=3421**&Address=地址&ext=拓展参数");
            builder.AppendLine("删除：\t" + url + "TYPE=delete&NAME=用户名");
            builder.AppendLine("");
            builder.AppendLine("查询User：\t" + url + "TYPE=checkUser&NAME=用户名");
            builder.AppendLine("查询token：\t" + url + "TYPE=checkToken&ID=xxx&token=txxx");
            builder.AppendLine("登录：\t" + url + "TYPE=login&NAME=用户名&PASS=密码");
            builder.AppendLine("登出：\t" + url + "TYPE=logout&NAME=用户名&PASS=密码");

            Response.Write(ScTool.Pre(builder.ToString()));
        }

        //----------------------------------------------------------------

        private static String DBName = "SoulMarket_DB";
        private static DataBase DB = null;              // 本地数据库连接对象
        private static string TAB = "UserInfo";      // 记录用户初次使用信息

        private static void InitDB()
        {
            if (DB == null) DB = new DataBase(DBName, ScTool.UserName, ScTool.Password);    // 连接指定的数据库，若不存在则创建
        }

        /// <summary>
        /// 检测数据表是否存在，若不存在则创建
        /// </summary>
        private static bool CheckTab(DataBase DB)
        {
            bool exist = false;

            InitDB();
            if(!DB.ExistTab(TAB))
            {
                Dictionary<string, int> ColumnInfo = new Dictionary<string,int>();
                ColumnInfo.Add("NAME", 18);
                ColumnInfo.Add("PASS", 32);

                ColumnInfo.Add("token", 32);
                ColumnInfo.Add("NickName", 30); 
                ColumnInfo.Add("RealName", 20);
                ColumnInfo.Add("IdCard", 20);
                ColumnInfo.Add("Address", 100);
                ColumnInfo.Add("ext", 100);

                ColumnInfo.Add("creatDateTime", 24);
                ColumnInfo.Add("lastDateTime", 24);
                ColumnInfo.Add("count", 20);

                exist = DB.CreateTable(TAB, ColumnInfo);
            }
            else exist = true;

            return exist;
        }

        /// <summary>
        /// 添加
        /// </summary>
        public static string add(string NAME, string PASS)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null || PASS == null) return "fail, 添加的账号、密码不应为空";

            int count = DB.SelectValue(TAB, NAME, "NAME").RowList().Count;
            if (count > 0) return "fail, 账号 " + NAME + " 已存在！";    // 账号已存在，则不添加

            List<string> values = new List<string>();
            values.Add(NAME);
            values.Add(PASS);

            values.Add("");

            // 生成昵称
            string nickName = "";
            if(NAME.Length >= 10)
            {
                int start = NAME.Length - 8;
                nickName = NAME.Substring(0, start) + "****" + NAME.Substring(NAME.Length - 4);
            }
            values.Add(nickName);

            values.Add("");
            values.Add("");
            values.Add(""); 
            values.Add("");

            string time = DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss");
            values.Add(time);
            values.Add(time);
            values.Add("1");

            string result = DB.InsetValue(TAB, values);
            return result;
        }


        /// <summary>
        /// 修改
        /// </summary>
        public static string update(string NAME, string PASS, string token, string NickName, string RealName, string IdCard, string Address, string ext, bool countAdd = false)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null) return "fail, 待修改的账号，不应为空";


            Dictionary<string, string> datas = new Dictionary<string, string>();

            if (PASS != null) datas.Add("PASS", PASS);

            if (token != null) datas.Add("token", token);
            if (NickName != null) datas.Add("NickName", NickName);
            if (RealName != null) datas.Add("RealName", RealName);
            if (IdCard != null) datas.Add("IdCard", IdCard);
            if (Address != null) datas.Add("Address", Address);
            if (ext != null) datas.Add("ext", ext);

            string time = DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss");
            datas.Add("lastDateTime", time);

            if(countAdd)    // 更新次数值
            {
                Dictionary<string, string> Iteam = DB.SelectValue(TAB, NAME, "NAME").RowDic();
                long count = long.Parse(Iteam["count"]);
                datas.Add("count", (count + 1) + "");
            }

            string result = DB.UpdateValue(TAB, NAME, datas, "NAME");
            return result;
        }

        /// <summary>
        /// 删除
        /// </summary>
        public static string delete(string NAME)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null) return "fail, 待修改的账号，不应为空";

            bool result = DB.DeletValue(TAB, NAME, "NAME");

            return result ? "success" : "fail";
        }

        /// <summary>
        /// 查询，指定账号是否存在
        /// </summary>
        public static string checkUser(string NAME)
        {
            if (!CheckTab(DB)) return ScTool.ToJson("fail", "数据表创建失败！请检查数据库是否可以正常连接。");
            if (NAME == null ) return ScTool.ToJson("fail", "查询的账号、密码不应为空");

            int count = DB.SelectValue(TAB, NAME, "NAME", null, null).RowList().Count;
            //if (count > 0) update(NAME, null, null, null, null, null, null, null, true);  // 更新次数值

            if (count > 0) return ScTool.ToJson("success", "账户存在");
            else return ScTool.ToJson("fail", "账户不存在");
        }

        // {"status":"success","msg":"登录成功","ID":"100","token":"244ce143b6a01e7894f73de00584c802","NickName":""}
        /// <summary>
        /// 登录，
        /// 根据账号密码查询 用户ID/token
        /// </summary>
        public static string login(string NAME, string PASS)
        {
            if (!CheckTab(DB)) return ScTool.ToJson("fail", "数据表创建失败！请检查数据库是否可以正常连接。");
            if (NAME == null || PASS == null) return ScTool.ToJson("fail", "查询的账号、密码不应为空");

            Dictionary<string, string> ortherConditions = new Dictionary<string,string>();
            ortherConditions.Add("PASS", PASS);

            Dictionary<String, String> rowDic = DB.SelectValue(TAB, NAME, "NAME", null, ortherConditions).RowDic();
            if (rowDic.ContainsKey("NAME"))
            {
                string userLoginStr = NAME + "_" + PASS + "_" + DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss.ffff");
                string token = MD5.Encrypt(userLoginStr);

                update(NAME, null, token, null, null, null, null, null, true);  // 更新token、登录次数

                // 获取用户ID、token信息
                Dictionary<string, string> param = new Dictionary<string, string>();
                if (rowDic.ContainsKey("ID")) param.Add("ID", rowDic["ID"]);
                if (rowDic.ContainsKey("token")) param.Add("token", token);
                if (rowDic.ContainsKey("NickName")) param.Add("NickName", rowDic["NickName"]);

                return ScTool.ToJson("success", "登录成功", param);
            }
            else return ScTool.ToJson("fail", "登录失败，用户名或密码不正确");
        }

        // {"status":"success","msg":"token验证成功"}
        /// <summary>
        /// 查询token是否有效
        /// </summary>
        public static string checkToken(string ID, string token)
        {
            if (!CheckTab(DB)) return ScTool.ToJson("fail", "数据表创建失败！请检查数据库是否可以正常连接。");
            if (ID == null || token == null) return ScTool.ToJson("fail", "查询的ID、token不应为空");

            Dictionary<string, string> ortherConditions = new Dictionary<string, string>();
            ortherConditions.Add("token", token);

            int count = DB.SelectValue(TAB, ID, "ID", null, ortherConditions).RowList().Count;
            //if (count > 0) update(NAME, null, null, null, null, null, null, null, true);  // 更新次数值

            if (count > 0) return ScTool.ToJson("success", "token验证成功");
            else return ScTool.ToJson("fail", "token验证失败");
        }

        /// <summary>
        /// 登出，
        /// 根据账号密码清除对应的token
        /// </summary>
        public static string logout(string NAME, string PASS)
        {
            if (!CheckTab(DB)) return ScTool.ToJson("fail", "数据表创建失败！请检查数据库是否可以正常连接。");
            if (NAME == null || PASS == null) return ScTool.ToJson("fail", "查询的账号、密码不应为空");

            Dictionary<string, string> ortherConditions = new Dictionary<string, string>();
            ortherConditions.Add("PASS", PASS);

            Dictionary<String, String> rowDic = DB.SelectValue(TAB, NAME, "NAME", null, ortherConditions).RowDic();
            if (rowDic.ContainsKey("NAME"))
            {
                string token = "";
                update(NAME, null, token, null, null, null, null, null, false);  // 清除token

                // 获取用户ID、token信息
                Dictionary<string, string> param = new Dictionary<string, string>();
                if (rowDic.ContainsKey("ID")) param.Add("ID", rowDic["ID"]);
                if (rowDic.ContainsKey("token")) param.Add("token", token);
                if (rowDic.ContainsKey("NickName")) param.Add("NickName", rowDic["NickName"]);

                return ScTool.ToJson("success", "登出成功", param);
            }
            else return ScTool.ToJson("fail", "登出失败，用户名或密码不正确");
        }

    }
}