package sci.soulmarket.activity;

import android.os.Bundle;
import sci.soulmarket.activity.account.LoginActivity;
import sci.tool.function.ActivityComponent;
import sci.tool.function.Tools;

public class MainActivity extends ActivityComponent
{

	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_main");
	}

	@Override
	public void Click(String viewId)
	{
		if(viewId.equals("login"))
		{
			Tools.ShowActivity(context, LoginActivity.class);
		}
	}	
	
}
