
package sci.soulmarket.activity;

import sci.tool.ActivityComponent;
import android.os.Bundle;


public class LoginActivity extends ActivityComponent
{
	
	/** 设置界面显示 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_login");
	}
	
	/** 按钮点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("btn_login"))
		{
			
		}
	}
	
}
