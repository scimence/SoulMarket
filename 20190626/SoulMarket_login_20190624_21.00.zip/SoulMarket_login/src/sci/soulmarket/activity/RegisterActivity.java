
package sci.soulmarket.activity;

import sci.tool.function.ActivityComponent;
import sci.tool.function.CallBack2;
import sci.tool.function.Preference;
import sci.tool.function.Server;
import sci.tool.function.ThreadTool;
import sci.tool.function.ThreadTool.ThreadPram;
import sci.tool.function.Tools;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;


public class RegisterActivity extends ActivityComponent
{
	Preference localInfo;
	
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_register");
		
		localInfo = new Preference(this, "LtAccountInfo");
		
		EditText("edit_phone").setText(LoginActivity.PhoneNumber);
		EditText("edit_phone").setEnabled(false);
	}
	
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("dialog_header_back"))
		{
			this.finish();
		}
		else if (viewId.equals("check_allowprotocal"))
		{
			int gray = Color.parseColor("#b9b9b9");
			int blue = Color.parseColor("#5677fc");
			
			Button Register = Button("btn_register");
			if (CheckBox("check_allowprotocal").isChecked())
			{
				Register.setEnabled(true);
				Register.setTextColor(blue);
			}
			else
			{
				Register.setEnabled(false);
				Register.setTextColor(gray);
			}
		}
		else if (viewId.equals("btn_register"))
		{
			String PhoneNumber = EditText("edit_phone").getText().toString().trim();
			String password = EditText("edit_password").getText().toString().trim();
			
			if (PhoneNumber.equals(""))
			{
				SetTip("未获取到手机号信息，无法注册！");
				return;
			}
			
			if (password.equals("") || password.length() < 5)
			{
				SetTip("请输入密码，长度大于5位");
			}
			else
			{
				String md5 = Tools.MD5(password+"X");
				String msg = "MarketReg+" + md5;
				
				CallBack2 call = new CallBack2()
				{
					@Override
					public void OnSuccess(Object... data)
					{
						SetTip((String) data[0]);
					}
					
					@Override
					public void Onfail(Object... data)
					{
						SetTip((String) data[0]);
					}
				};
				
				Server.CheckUser(this, PhoneNumber, md5, call);
				
				boolean result = Tools.SendSMS(PhoneNumber, msg);
				if(result)
				{
				
				}
			}
		}
	}
	
	private void SetTip(final String msg)
	{
		final TextView text = TextView("textTip");
		
		ThreadTool.RunInMainThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				text.setText("提示：" + msg);
				text.setTextColor(Color.RED);
			}
		});
		// TextView("textTip").setText(msg);
		// TextView("textTip").setTextColor(Color.RED);
	}
	
}
