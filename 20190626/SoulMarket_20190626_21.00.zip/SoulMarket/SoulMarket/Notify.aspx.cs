﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoulMarket
{
    /// <summary>
    /// 通知信息解析：
    /// com.sc.notificationservices#681190477515911#1533107942652#标题#内容
    /// </summary>
    public class NotifyData
    {
        public string package = "";
        public string phoneId = "";
        public string msgId = "";
        public string tittle = "";
        public string content = "";

        /// <summary>
        /// 解析通知信息内容
        /// </summary>
        public NotifyData(string data)
        {
            int i = 0;
            while (!data.Equals(""))
            {
                string[] A = ScTool.splitTwo(data, "#");

                data = A[1];

                i++;
                if (i == 1) package = A[0];
                else if (i == 2) phoneId = A[0];
                else if (i == 3) msgId = A[0];
                else if (i == 4) tittle = A[0];
                else if (i == 5) content = A[0];
            }
        }
    }

    /// <summary>
    /// 负责对通知信息进行处理
    /// </summary>
    public partial class Notify : System.Web.UI.Page
    {
        /// <summary>
        /// 获取请求参数信息
        /// </summary>
        private String getParam(String LogName = "")
        {
            String Url = Request.Url.ToString();
            String param = "";

            Url = System.Web.HttpUtility.UrlDecode(Url);                    // 解码参数
            if (Url.Contains("?"))
            {
                param = Url.Substring(Url.IndexOf("?") + 1);                // 获取参数信息

                if (LogName.Equals("")) LogName = this.GetType().Name;
                LogTool log = new LogTool(LogName);                         // 记录至log中
                if (param.Contains("(") || param.Contains("到账"))
                {
                    log.WriteLine(param);
                }
            }
            return param;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            String param = getParam();                                  // 获取通知消息
            //param = "param=com.sc.notificationservices#866170022772077#1518361220871#标题#内容";
            //param=com.sc.notificationservices#681190477515911#1533107942652#标题#内容
            //param = "com.eg.android.AlipayGphone#866170022772077#1533477407672#支付宝通知#成功收款0.1元。享免费提现等更多专属服务，点击查看";
            if (param.StartsWith("param=")) param = param.Substring("param=".Length);

            NotifyData data = new NotifyData(param);

            string result = "fail";
            if (data.package.Equals("com.sc.notificationservices"))
            {
                //DB = new DataBase(ScTool.DBName(ScTool.PayTypeAli), ScTool.UserName, ScTool.Password);
                //result = recordInCahsier(DB, data.phoneId);

                //if (result.Equals("success"))
                //{
                //    DB = new DataBase(ScTool.DBName(ScTool.PayTypeWechat), ScTool.UserName, ScTool.Password);
                //    result = recordInCahsier(DB, data.phoneId);
                //}
            }
        }
    }
}