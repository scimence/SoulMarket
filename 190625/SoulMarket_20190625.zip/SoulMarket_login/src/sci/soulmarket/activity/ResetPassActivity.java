package sci.soulmarket.activity;

import sci.tool.function.ActivityComponent;
import android.os.Bundle;
import android.view.View;

public class ResetPassActivity extends ActivityComponent
{

	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_reset_pass");
//		localInfo = new Preference(this, "LtAccountInfo");
		
		EditText("edit_phone").setText(LoginActivity.PhoneNumber);
		EditText("edit_phone").setEnabled(false);
	}

	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("dialog_header_back"))
		{
			this.finish();
		}
		else 
		{
			
		}
	}	
	
	public void OnBack(View view)
	{
		this.finish();
	}
}
