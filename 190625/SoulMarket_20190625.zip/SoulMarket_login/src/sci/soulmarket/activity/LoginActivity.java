
package sci.soulmarket.activity;

import java.util.HashMap;

import org.json.JSONObject;

import sci.tool.function.ActivityComponent;
import sci.tool.function.CallBack;
import sci.tool.function.FJHttp;
import sci.tool.function.LogTool;
import sci.tool.function.Preference;
import sci.tool.function.SIM;
import sci.tool.function.ThreadTool;
import sci.tool.function.ThreadTool.ThreadPram;
import sci.tool.function.Tools;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;


public class LoginActivity extends ActivityComponent
{
	Preference localInfo;
	
	boolean showPassword = false;		// 是否显示密码
	boolean saveAccountInfo = true;		// 是否保存帐号、密码信息
	
	public static String PhoneNumber = ""; // 当前手机号
	
	/** 设置界面显示 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_login");
		
		localInfo = new Preference(this, "LtAccountInfo");
		
		PhoneNumber = SIM.getPhoneNumber(this);
		loadAccountInfo();
	}
	
	/** 按钮点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("btn_login"))
		{
			String name = EditText("edit_account").getText().toString();
			String password = EditText("edit_password").getText().toString();
			
			CallBack call = new CallBack()
			{
				@Override
				public void Onfail()
				{
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void OnSuccess()
				{
					// TODO Auto-generated method stub
					
				}
			};
			
			UserLogin(name, password, call);
		}
		else if (viewId.equals("password_eye"))
		{
			showPassword = !showPassword;
			if (showPassword)
				EditText("edit_password").setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			else EditText("edit_password").setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		}
		else if (viewId.equals("btn_register"))
		{
			Tools.ShowActivity(context, RegisterActivity.class);  // 跳转注册界面
			// context.finish();
		}
		else if (viewId.equals("btn_foget"))
		{
			Tools.ShowActivity(context, ResetPassActivity.class); // 跳转重置密码界面
			// context.finish();
		}
	}
	
	// 设置是否记住帐号密码信息
	private void setSaveState(boolean save)
	{
		saveAccountInfo = save;
	}
	
	// 保存帐号信息
	private void SaveAccountInfo(/* String uname, String password */)
	{
		String uname = EditText("edit_account").getText().toString();
		String password = EditText("edit_password").getText().toString();
		
		localInfo.put("isSaved", saveAccountInfo + "");
		if (saveAccountInfo)
		{
			localInfo.put("uname", uname);
			localInfo.put("password", password);
		}
		else
		{
			localInfo.put("uname", "");
			localInfo.put("password", "");
		}
	}
	
	// 载入本地帐号信息
	private void loadAccountInfo()
	{
		boolean isSaved = localInfo.get("isSaved").equals("true");
		setSaveState(isSaved);	// 显示是否保存帐号
		
		if (uname.equals(""))	// 若帐号为空则载入本地配置帐号信息
		{
			uname = localInfo.get("uname");
			password = localInfo.get("password");
		}
		
		if (uname.equals("")) uname = PhoneNumber;
		
		EditText("edit_account").setText(uname);
		EditText("edit_password").setText(password);
	}
	
	// --------------------
	
	// 乐堂登录，获取到用户信息
	public static String login_msg = "";	// 登录服务器返回信息
	
	public static String uid = "";			// 用户id
	public static String uname = "";		// 用户名称
	public static String password = "";		// 密码
	public static String token = "";		// token
	
	public static boolean isLoginSuccess = false;	// 记录当前是否登录成功
	
	/** 检测是否已登录成功，若未登录，则自动调出登录 */
	public static boolean checkLogin(Context context)
	{
		if (isLoginSuccess) Tools.ShowActivity(context, LoginActivity.class);
		return isLoginSuccess;
	}
	
	/** 乐堂用户登录 */
	public void UserLogin(final String name, final String password, final CallBack call)
	{
		ThreadTool.RunInCachedThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				try
				{
					// String Url = LtConfig.URL(Instance, "/User/login");
					String Url = "";
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uname", name);
					map.put("password", password);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "乐堂用户登录 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "登录返回信息 ->> " + rdata);
					// 登录返回信息 ->>
					// {"status":1,"msg":"\u767b\u5f55\u6210\u529f","content":{"uid":"5667094","uname":"6t1bxiyq","nname":"6t1bxiyq","reg_date":"2018-03-09 09:25:22","token":"0d6af827e1c6d786aea25692eb479f2e","ip":"218.104.71.178"}}
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					login_msg = userJson.getString("msg");
					
					switch (status)
					{
						case 200:		// 登录成功
							JSONObject contentJson = userJson.getJSONObject("data");
							
							uid = contentJson.getString("uid");			// 乐堂用户ID
							uname = contentJson.getString("uname");
							token = contentJson.getString("token");
							
							isLoginSuccess = true;
							if (call != null) call.OnSuccess();
							Tools.showText("乐堂用户登录成功" + "，用户名: " + uname + "，用户ID: " + uid);
							break;
						
						default:	// 登录失败
							// Log.d(TAG, "乐堂用户登录失败！" + login_msg);
							LogTool.showText("登录失败！" + login_msg);
							
							isLoginSuccess = false;
							if (call != null) call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					LogTool.showText("登录异常！");
					ex.printStackTrace();
					if (call != null) call.Onfail();
				}
			}
		});
		
	}
	
}
