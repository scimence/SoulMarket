
package sci.soulmarket.activity;

import sci.tool.function.ActivityComponent;
import sci.tool.function.Preference;
import sci.tool.function.Tools;
import android.graphics.Color;
import android.os.Bundle;


public class RegisterActivity extends ActivityComponent
{
	Preference localInfo;
	
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_register");
		
		localInfo = new Preference(this, "LtAccountInfo");
		
		EditText("edit_phone").setText(LoginActivity.PhoneNumber);
		EditText("edit_phone").setEnabled(false);
	}
	
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("dialog_header_back"))
		{
			this.finish();
		}
		else if (viewId.equals("btn_register"))
		{
			String PhoneNumber = EditText("edit_phone").getText().toString().trim();
			String password = EditText("edit_password").getText().toString().trim();
			
			if(PhoneNumber.equals(""))
			{
				SetTip("未获取到手机号信息，无法注册！");
				return;
			}
			
			if(password.equals("") || password.length() < 5)
			{
				SetTip("请输入密码，长度大于5位");
			}
			else
			{
				String msg = "MarketReg+" + password;
				Tools.SendSMS(PhoneNumber, msg);
			}
		}
	}
	
	private void SetTip(String msg)
	{
		TextView("textTip").setText(msg);
		TextView("textTip").setTextColor(Color.RED);
	}
	
}
