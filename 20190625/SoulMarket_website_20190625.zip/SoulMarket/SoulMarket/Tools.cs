﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace SoulMarket
{
    public class Tools
    {
        /// <summary>
        /// 获取请求参数信息
        /// </summary>
        public static String getParam(HttpRequest Request, Page pageObj)
        {
            String Url = Request.Url.ToString();
            String param = "";
            if (Url.Contains("?"))
            {
                param = Url.Substring(Url.IndexOf("?") + 1);                // 获取参数信息

                LogTool log = new LogTool(pageObj.GetType().Name);          // 记录至log中
                log.WriteLine(param);
            }
            return param;
        }

    }
}