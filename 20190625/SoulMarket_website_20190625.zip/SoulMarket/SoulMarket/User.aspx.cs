﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoulMarket
{
    public partial class User : System.Web.UI.Page
    {
        string TYPE = "";
        DataBase DB = null;
        string TAB = "UserInfo";

        protected void Page_Load(object sender, EventArgs e)
        {
            Tools.getParam(Request, this);
            TYPE = Request["TYPE"];

            string data = "";
            if (TYPE == null)
            {
                data = NoteInfo();
            }
            else
            {
                DB = new DataBase("SoulMarket_DB", "sa", "sa12345");

                TYPE = TYPE.Trim().ToLower();
                string NAME = Request["NAME"];
                string PASS = Request["PASS"];

                if (TYPE.Equals("add"))
                {
                    data = add(NAME, PASS);
                }
                else if (TYPE.Equals("check"))
                {
                    data = check(NAME, PASS);
                }
                else if (TYPE.Equals("update"))
                {
                    data = update(NAME, PASS, Request["NickName"], Request["RealName"], Request["IdCard"], Request["Address"], Request["ext"]);
                }
                else if (TYPE.Equals("delete"))
                {
                    data = delete(NAME);
                }
            }

            Response.Write(data);
        }

        /// <summary>
        /// 接口使用说明信息
        /// </summary>
        private String NoteInfo()
        {
            StringBuilder Str = new StringBuilder();

            String url = "http://" + Request.Params.Get("HTTP_HOST") + "/" + this.GetType().Name.Replace("_", ".") + "?";

            Str.AppendLine("<pre>");

            Str.AppendLine("接口使用说明：");
            Str.AppendLine("");
            Str.AppendLine("添加：" + url + "TYPE=add&NAME=用户名&PASS=密码");
            Str.AppendLine("修改：" + url + "TYPE=update&NAME=用户名&PASS=密码");
            Str.AppendLine("删除：" + url + "TYPE=delete&NAME=用户名");
            Str.AppendLine("查询：" + url + "TYPE=check&NAME=用户名&PASS=密码");

            Str.AppendLine("</pre>");

            return Str.ToString();
        }

        private bool CheckTab(DataBase DB)
        {
            bool exist = false;
            if(!DB.ExistTab(TAB))
            {
                Dictionary<string, int> ColumnInfo = new Dictionary<string,int>();
                ColumnInfo.Add("NAME", 18);
                ColumnInfo.Add("PASS", 32);
                ColumnInfo.Add("NickName", 30); 
                ColumnInfo.Add("RealName", 20);
                ColumnInfo.Add("IdCard", 20);
                ColumnInfo.Add("Address", 100);
                ColumnInfo.Add("ext", 100);
                ColumnInfo.Add("creatDateTime", 24);
                ColumnInfo.Add("lastDateTime", 24);
                ColumnInfo.Add("count", 20);

                exist = DB.CreateTable(TAB, ColumnInfo);
            }
            return exist;
        }

        /// <summary>
        /// 添加
        /// </summary>
        private string add(string NAME, string PASS)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null || PASS == null) return "fail, 添加的账号、密码不应为空";

            List<string> list = DB.SelectValueList(TAB, NAME, "NAME");
            if (list.Count > 0) return "fail, 账号 " + NAME + " 已存在！";    // 账号已存在，则不添加

            List<string> values = new List<string>();
            values.Add(NAME);
            values.Add(PASS);

            values.Add("");
            values.Add("");
            values.Add("");
            values.Add(""); 
            values.Add("");

            string time = DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss");
            values.Add(time);
            values.Add(time);
            values.Add("1");

            string result = DB.InsetValue(TAB, values);
            return result;
        }


        /// <summary>
        /// 修改
        /// </summary>
        private string update(string NAME, string PASS, string NickName, string RealName, string IdCard, string Address, string ext)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null) return "fail, 待修改的账号，不应为空";


            Dictionary<string, string> datas = new Dictionary<string, string>();

            if (PASS != null) datas.Add("PASS", PASS);
            if (NickName != null) datas.Add("NickName", NickName);
            if (RealName != null) datas.Add("RealName", RealName);
            if (IdCard != null) datas.Add("IdCard", IdCard);
            if (Address != null) datas.Add("Address", Address);
            if (ext != null) datas.Add("ext", ext);

            string time = DateTime.Now.ToString("yyyy-MM-dd_HH:mm:ss");
            datas.Add("lastDateTime", time);

            //datas.Add("count", time);

            string result = DB.UpdateValue(TAB, NAME, datas, "NAME");
            return result;
        }


        /// <summary>
        /// 删除
        /// </summary>
        private string delete(string NAME)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null) return "fail, 待修改的账号，不应为空";

            bool result = DB.DeletValue(TAB, NAME, "NAME");

            return result ? "success" : "fail";
        }

        /// <summary>
        /// 查询
        /// </summary>
        private string check(string NAME, string PASS)
        {
            if (!CheckTab(DB)) return "fail, 数据表创建失败！请检查数据库是否可以正常连接。";
            if (NAME == null || PASS == null) return "fail, 查询的账号、密码不应为空";

            String sql = "select * from [" + TAB + "]" + " where NAME='" + NAME + "'" + " and PASS='" + PASS + "'";
            List<String> list = DB.ExecuteList(sql);

            return list.Count > 0 ? "success" : "fail";
        }
    }
}