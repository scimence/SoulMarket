/** Automatically generated file. DO NOT MODIFY */
package sci.soulmarket.plugin.login;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}