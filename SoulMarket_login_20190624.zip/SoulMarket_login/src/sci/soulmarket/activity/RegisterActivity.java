
package sci.soulmarket.activity;

import sci.tool.function.ActivityComponent;
import sci.tool.function.Preference;
import sci.tool.function.SIM;
import sci.tool.function.Tools;
import android.os.Bundle;


public class RegisterActivity extends ActivityComponent
{
	Preference localInfo;
	
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_register");
		
		localInfo = new Preference(this, "LtAccountInfo");
	}
	
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("btn_register"))
		{
			String PhoneNumber = SIM.getPhoneNumber(this);
			// String name = EditText("edit_account").getText().toString();
			String password = EditText("edit_password").getText().toString();
			
			String msg = "SoulReg+" + password;
			Tools.SendSMS(PhoneNumber, msg);
		}
	}
	
}
