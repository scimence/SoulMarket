package sci.tool.function;

import sci.tool.function.ThreadTool.ThreadPram;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.RelativeLayout;


//package com.sci.circulargallary;
//
//import android.app.Activity;
//import android.os.Bundle;
// 
// 
//public class MainActivity extends Activity
//{
//	@Override
//	protected void onCreate(Bundle savedInstanceState)
//	{
//		super.onCreate(savedInstanceState);
//		// setContentView(R.layout.activity_main);
//		
//		// 从图像资源创建循环Gallery，并添加至当前Activity中
//		int[] pics = { R.drawable.pic1, R.drawable.pic2, R.drawable.pic3, R.drawable.pic4, R.drawable.pic5, R.drawable.pic6, R.drawable.pic7 };
//		setContentView(new CircularGallery(this, pics));
//	}
//}

/** CircularGallery 循环Gallery，包含n张子图像，显示为2n张子图，在【0.5n， 1.5n】循环切换 ----- 2015-8-19 下午3:32:21 wangzhongyuan */
public class CircularGallery extends RelativeLayout
{
	private Context context;		// 控件所处的上下文环境
	private Gallery gallery;
	private ImageAdapter adapter;
	private int select;				// 记录当前选中的子图像索引
	
	private int[] picIds;			// 所有图像资源id
	private Drawable[] pics;		// 所有轮播图
	
	private int PicCount()
	{
		return (pics != null ? pics.length : picIds.length);
	}
	
	/** 获取当前选中的子控件id = [0, pics.length) */
	public int selected()
	{
		return select;
	}
	
	/** 选中子控件变动时调用该函数，子类可重写该函数，执行子控件选项变动逻辑 */
	public void selecteChanged()
	{
		// if(selected() == 0) ...;
		// else if(selected() == 1) ...;
	}
	
	private boolean autoChange = false;		// 是否自动切换
	private Handler autoHandler = null;
	private long autoDelayMillis = 3000;
	
	/** 设置CircularGallery自动切换 */
	public void AutoChange(final boolean auto, final long delayMillis)
	{
		autoChange = auto;
		autoDelayMillis = delayMillis;
		
		autoSwitch();
	}
	
	// 自动切换至下一个视图
	private void autoSwitch()
	{
		if (!autoChange) return;
		
		if (autoHandler == null) autoHandler = new Handler(Looper.getMainLooper());
		
		if (autoHandler != null) autoHandler.postDelayed(new Runnable()
		{
			@Override
			public void run()
			{
				// int len = PicCount();
				gallery.setSelection(select + 1);
				// SelectNext();
				
				autoSwitch();
			}
		}, autoDelayMillis);
	}
	
	// -----------
	
	/** 创建循环Gallery pics = { R.drawable.pic1, R.drawable.pic2, R.drawable.pic3, R.drawable.pic4, R.drawable.pic5}; */
	public CircularGallery(Context context, int[] picIds)
	{
		super(context);
		this.context = context;
		this.picIds = picIds;
		
		creatMainView();
	}
	
	/** 创建循环Gallery pics为所有待轮播的图像; */
	public CircularGallery(Context context, Drawable[] pics, int gW, int gH, int pW, int pH, long dellayMillions)
	{
		super(context);
		this.context = context;
		this.pics = pics;
		
		this.gW = gW;
		this.gH = gH;
		this.pW = pW;
		this.pH = pH;
		
		creatMainView();
		AutoChange(true, dellayMillions);	// 设置为自动切换
	}
	
	int gW = -1, gH = -1;	// CircularGallery整体大小
	int pW = -1, pH = -1;	// CircularGallery中展示的图像大小
	public CallBack2 garlleryClickCall = null;	// 执行garllery图片点击回调
	
	// 创建CircularImageView的子控件，以代码布局的方式显示PicId对应的图像
	@SuppressWarnings("deprecation")
	private void creatMainView()
	{
		int space = 5;									// 子图像之间的间隔
		
		int w2 = 160, h2 = 220;							// CircularGallery中展示的图像大小
		int w = w2 * 5 + space * 6, h = h2 + space * 2;	// CircularGallery整体大小
		
		// 设定CircularGallery整体大小和图像的大小
		if (gW != -1 && gH != -1)
		{
			w = gW;
			h = gH;
		}
		
		if (pW != -1 && pH != -1)
		{
			w2 = pW;
			h2 = pH;
		}
		
		// 控件主体部分
		RelativeLayout body = new RelativeLayout(context);	// 创建一个相对布局的视图
		// body.setBackgroundColor(Color.GRAY); // 为其设置背景色
		body.setBackgroundColor(Color.TRANSPARENT); // 为其设置背景色
		
		// 添加主体部分到主界面
		RelativeLayout.LayoutParams paramsBody = new RelativeLayout.LayoutParams(w, h);
		paramsBody.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
		this.addView(body, paramsBody);
		
		// 添加Gallery到
		gallery = new Gallery(context);
		RelativeLayout.LayoutParams parms = new RelativeLayout.LayoutParams(w, h2);
		parms.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
		body.addView(gallery, parms);
		
		if (pics != null)
			adapter = new ImageAdapter(context, pics, w2, h2);
		else adapter = new ImageAdapter(context, picIds, w2, h2);
		
		gallery.setAdapter(adapter); 					// gallery添加ImageAdapter图片资源
		gallery.setGravity(Gravity.CENTER_HORIZONTAL); 	// 设置水平居中显示
		gallery.setSelection(PicCount());			// 设置起始图片显示位置（可以用来制作gallery循环显示效果）
//		gallery.setUnselectedAlpha(0.3f); 				// 设置未选中图片的透明度
		gallery.setSpacing(5); 							// 设置图片之间的间距
		
		gallery.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				// Toast.makeText(context, "图片 " + position, Toast.LENGTH_SHORT).show();
				
				// 记录选择的图像索引
				select = position;
				if (select >= PicCount()) select -= PicCount();
				Log.i("CircularGallery", "选择图片 " + select);
				// Toast.makeText(context, "图片 " + select, Toast.LENGTH_SHORT).show();
				
				// 执行轮播图点击回调逻辑
				if (garlleryClickCall != null)
				{
					ThreadTool.RunInMainThread(new ThreadPram()
					{
						@Override
						public void Function()
						{
							try
							{
								garlleryClickCall.OnSuccess(select);
							}
							catch (Exception ex)
							{
								Log.i("CircularGallery", "garlleryClickCall 异常！");
								ex.printStackTrace();
							}
							
						}
					});
				}
			}
		});
		
		gallery.setOnItemSelectedListener(new OnItemSelectedListener()
		{
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
			{
				int len = PicCount();
				
				// 使得所有的图像在[0.5, 1.5)*len之间，无限循环切换
				int first = len / 2, last = first + len;
				while (position < first)
					position += len;
				while (position >= last)
					position -= len;
				
				gallery.setSelection(position);
				// adapter.notifyDataSetChanged();
				
				// 记录选择的图像索引
				select = position;
				if (select >= len) select -= len;
				
				selecteChanged();
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> parent)
			{}
		});
	}
	
	// int autoSelect = 0;
	//
	// /** 选取Gallery下一个图像，间隔i */
	// private void SelectNext()
	// {
	// int len = PicCount();
	//
	// int position = autoSelect++;
	// if (autoSelect >= len) autoSelect = 0;
	//
	// // 使得所有的图像在[0.5, 1.5)*len之间，无限循环切换
	// int first = len / 2, last = first + len;
	// while (position < first)
	// position += len;
	// while (position >= last)
	// position -= len;
	//
	// gallery.setSelection(position);
	// }
	
	/** ImageAdapter 用于获取子图像 ----- 2015-8-13 上午11:34:51 wangzhongyuan */
	class ImageAdapter extends BaseAdapter
	{
		private Context context;
		public int[] picIds;		// 子图像资源id
		public Drawable[] pics;		// 子图像
		
		int W, H;					// 子图像尺寸
				
		public ImageAdapter(Context context, int[] picIds, int w, int h)
		{
			this.context = context;
			this.picIds = picIds;
			W = w;
			H = h;
		}
		
		public ImageAdapter(Context context, Drawable[] pics, int w, int h)
		{
			this.context = context;
			this.pics = pics;
			W = w;
			H = h;
		}
		
		// 子图像总数
		public int getCount()
		{
			// 在Gallery中设置2倍图片数组长度的图像，用于循环显示图像信息
			if (pics != null)
				return pics.length * 2;
			else return picIds.length * 2;
		}
		
		// 获取图片位置
		public Object getItem(int index)
		{
			return picIds[index];
		}
		
		// 获取图片ID
		public long getItemId(int index)
		{
			return index;
		}
		
		// 获取index对应的子View
		public View getView(int index, View convertView, ViewGroup parent)
		{
			ImageView imageView = new ImageView(context);
			
			if (pics != null)
				imageView.setImageDrawable(pics[index % pics.length]);
			else imageView.setImageResource(picIds[index % picIds.length]);
			
			imageView.setLayoutParams(new Gallery.LayoutParams(W, H));
			imageView.setScaleType(ImageView.ScaleType.FIT_XY);
			return imageView;
		}
	}
}

