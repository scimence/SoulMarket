﻿
package sci.listview;

import org.json.JSONArray;
import org.json.JSONObject;

import sci.tool.function.WebTool;
import android.graphics.drawable.Drawable;
import android.util.Log;


/** ListIteamData.java: 定义该结构用于表示列表项的数据结构 ----- 2018-10-25 下午8:20:46 scimence */
public class ListIteamData
{
	public String iconUrl, btnUrl1, btnUrl2, note;		// 图标url地址、按钮url、灰色按钮url、文本说明信息
	
	Drawable icon, btn1, btn2;							// 图标图像、按钮图像、灰色按钮图像
	public boolean isClicked = false;					// 其他信息，记录列表项是否已点击
	
	ListIteamData()
	{}
	
	// public ListIteamData(String... data)
	// {
	// this.iconUrl = data[0];
	// this.btnUrl1 = data[1];
	// this.note1 = data[2];
	// this.note2 = data[3];
	// }
	
	// 从Json对象创建
	public ListIteamData(JSONObject obj)
	{
		try
		{
			this.iconUrl = obj.optString("iconUrl", "");
			this.btnUrl1 = obj.optString("btnUrl1", "");
			this.btnUrl2 = obj.optString("btnUrl2", "");
			this.note = obj.optString("note", "");
			
			// 下载图像资源
			icon = WebTool.GetDrawable(iconUrl);
			btn1 = WebTool.GetDrawable(btnUrl1);
			btn2 = WebTool.GetDrawable(btnUrl2);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	// ---------------------------------
	
	// 从Json数组解析数据
	public static ListIteamData[] ToArray(JSONArray data)
	{
		ListIteamData[] Array = new ListIteamData[data.length()];
		
		for (int i = 0; i < data.length(); i++)
		{
			try
			{
				JSONObject obj = data.getJSONObject(i);
				Array[i] = new ListIteamData(obj);
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				Log.e("thumbsupPage.java", "数据ListIteamData解析异常!");
			}
		}
		return Array;
	}
}
