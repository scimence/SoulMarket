
package sci.tool.function;

import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.HashMap;

import org.json.JSONObject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;


public class Server
{
	/** 获取应用配置信息 */
	public static void GetAppConfig(final Context context, final CallBack2 call)
	{
		try
		{
			String Url = MarketConfig.URL(context, "/config/app.txt");
			String rdata = WebTool.GetString(Url);
			
			LogTool.showText("GetAppConfig信息 ->> " + Url );    // 请求参数信息
			LogTool.showText("服务器返回信息 ->> " + rdata);
			
			// {"status":"success","msg":"账户存在"}
			// 解析获取的ClientId
			JSONObject userJson = new JSONObject(rdata);
			boolean success = userJson.optString("status", "").equals("success");
			String msg = userJson.optString("msg", "");
			String smsNumber = userJson.optString("smsNumber", "");
			String directModify = userJson.optString("directModify", "").trim().toLowerCase();
			
			if (call != null)
			{
				if (success)
					call.OnSuccess(msg, smsNumber, directModify);
				else call.Onfail(msg);
			}
		}
		catch (Exception ex)
		{
			LogTool.showToast(context, "GetAppConfig信息异常！");
			ex.printStackTrace();
		}
	}
	
	/** 查询User是否已存在 */
	public static void CheckUser(final Context context, final String NAME, final CallBack2 call)
	{
		ThreadTool.RunInCachedThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				try
				{
					// String Url = LtConfig.URL(context, "/Coupon/lists");
					String Url = MarketConfig.URL(context, "/Request.aspx");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("NAME", NAME);
					map.put("TYPE", "checkUser");
					// AddSign(map, Url);
					
					// String rdata = "";
					String rdata = FJHttp.request(Url, map, "get");
					
					LogTool.showText("CheckUser信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));    // 请求参数信息
					LogTool.showText("服务器返回信息 ->> " + rdata);
					
					// {"status":"success","msg":"账户存在"}
					// 解析获取的ClientId
					JSONObject userJson = new JSONObject(rdata);
					boolean success = userJson.optString("status", "").equals("success");
					String msg = userJson.optString("msg", "");
					
					if (call != null)
					{
						if (success)
							call.OnSuccess(msg);
						else call.Onfail(msg);
					}
				}
				catch (Exception ex)
				{
					LogTool.showToast(context, "CheckUser信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 用户登录 */
	public static void UserLogin(final Context context, final String NAME, final String PASS, final CallBack2 call)
	{
		ThreadTool.RunInCachedThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				try
				{
					// String Url = LtConfig.URL(context, "/Coupon/lists");
					String Url = MarketConfig.URL(context, "/Request.aspx");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("NAME", NAME);
					map.put("PASS", PASS);
					map.put("TYPE", "login");
					// AddSign(map, Url);
					
					// String rdata = "";
					String rdata = FJHttp.request(Url, map, "get");
					
					LogTool.showText("UserLogin信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));    // 请求参数信息
					LogTool.showText("服务器返回信息 ->> " + rdata);
					
					// {"status":"success","msg":"登录成功","ID":"103","token":"9ae24280898668a6cf7b8cce18d83b40","NickName":"180****6710"}
					// 解析获取的ClientId
					JSONObject userJson = new JSONObject(rdata);
					boolean success = userJson.optString("status", "").equals("success");
					String msg = userJson.optString("msg", "");
					
					
					if (call != null)
					{
						if (success)
						{
							String ID = userJson.optString("ID", "");
							String token = userJson.optString("token", "");
							String NickName = userJson.optString("NickName", "");
							
							call.OnSuccess(msg, ID, token, NickName);
						}
						else call.Onfail(msg);
					}
				}
				catch (Exception ex)
				{
					LogTool.showToast(context, "UserLogin信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}

	/** 用户登出 */
	public static void UserLogout(final Context context, final String NAME, final String PASS, final CallBack2 call)
	{
		ThreadTool.RunInCachedThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				try
				{
					String Url = MarketConfig.URL(context, "/Request.aspx");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("NAME", NAME);
					map.put("PASS", PASS);
					map.put("TYPE", "logout");
					
					String rdata = FJHttp.request(Url, map, "get");
					
					LogTool.showText("UserLogout信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));    // 请求参数信息
					LogTool.showText("服务器返回信息 ->> " + rdata);
					
					// {"status":"success","msg":"登录成功","ID":"103","token":"9ae24280898668a6cf7b8cce18d83b40","NickName":"180****6710"}
					// 解析获取的ClientId
					JSONObject userJson = new JSONObject(rdata);
					boolean success = userJson.optString("status", "").equals("success");
					String msg = userJson.optString("msg", "");
					
					
					if (call != null)
					{
						if (success)
						{
							String ID = userJson.optString("ID", "");
							String token = userJson.optString("token", "");
							String NickName = userJson.optString("NickName", "");
							
							call.OnSuccess(msg, ID, token, NickName);
						}
						else call.Onfail(msg);
					}
				}
				catch (Exception ex)
				{
					LogTool.showToast(context, "UserLogout信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 查询用户Token信息是否验证通过 */
	public static void CheckToken(final Context context, final String ID, final String token, final CallBack2 call)
	{
		ThreadTool.RunInCachedThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				try
				{
					String Url = MarketConfig.URL(context, "/Request.aspx");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("ID", ID);
					map.put("token", token);
					map.put("TYPE", "checkToken");
					
					String rdata = FJHttp.request(Url, map, "get");
					
					LogTool.showText("CheckToken信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));    // 请求参数信息
					LogTool.showText("服务器返回信息 ->> " + rdata);
					
					// {"status":"success","msg":"账户存在"}
					// 解析获取的ClientId
					JSONObject userJson = new JSONObject(rdata);
					boolean success = userJson.optString("status", "").equals("success");
					String msg = userJson.optString("msg", "");
					
					if (call != null)
					{
						if (success)
							call.OnSuccess(msg);
						else call.Onfail(msg);
					}
				}
				catch (Exception ex)
				{
					LogTool.showToast(context, "CheckToken信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	//-----------------------
	
	/** 添加用户账号 */
	public static void UserAdd(final Context context, final String NAME, final String PASS, final CallBack2 call)
	{
		ThreadTool.RunInCachedThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				try
				{
					// String Url = LtConfig.URL(context, "/Coupon/lists");
					String Url = MarketConfig.URL(context, "/Request.aspx");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("NAME", NAME);
					map.put("PASS", PASS);
					map.put("TYPE", "add");
					// AddSign(map, Url);
					
					// String rdata = "";
					String rdata = FJHttp.request(Url, map, "get");
					
					LogTool.showText("UserAdd信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));    // 请求参数信息
					LogTool.showText("服务器返回信息 ->> " + rdata);
					
					// fail, 账号 用户名 已存在！
					boolean success = !rdata.equals("") && !rdata.contains("fail");
					
					if (call != null)
					{
						if (success)
						{
							call.OnSuccess(rdata);
						}
						else call.Onfail(rdata);
					}
				}
				catch (Exception ex)
				{
					LogTool.showToast(context, "UserAdd信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}

	/** 修改用户信息 */
	public static void UserUpdate(final Context context, final String NAME, final String PASS, final String NickName, final String RealName, final String IdCard, final String Address, final String ext, final CallBack2 call)
	{
		ThreadTool.RunInCachedThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				try
				{
					// String Url = LtConfig.URL(context, "/Coupon/lists");
					String Url = MarketConfig.URL(context, "/Request.aspx");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("NAME", NAME);
					if(PASS != null) map.put("PASS", PASS);
					map.put("TYPE", "update");
					
					if(NickName != null) map.put("NickName", NickName);
					if(RealName != null) map.put("RealName", RealName);
					if(IdCard != null) map.put("IdCard", IdCard);
					if(Address != null) map.put("Address", Address);
					if(ext != null) map.put("ext", ext);
					// AddSign(map, Url);
					
					// String rdata = "";
					String rdata = FJHttp.request(Url, map, "get");
					
					LogTool.showText("UserUpdate信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));    // 请求参数信息
					LogTool.showText("服务器返回信息 ->> " + rdata);
					
					// fail, 账号 用户名 已存在！
					boolean success = !rdata.equals("") && !rdata.contains("fail");
					
					if (call != null)
					{
						if (success)
						{
							call.OnSuccess(rdata);
						}
						else call.Onfail(rdata);
					}
				}
				catch (Exception ex)
				{
					LogTool.showToast(context, "UserUpdate信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	

	
	//------------------------------
	
	/** 添加签名验证信息 */
	public static void AddSign(HashMap<String, String> map, String url)
	{
		String action = url;
		if (url.contains("/")) action = url.substring(url.lastIndexOf("/") + 1);
		
		String timestamp = (System.currentTimeMillis() / 1000) + "";
		String sign = MD5(timestamp + action);
		
		map.put("timestamp", timestamp);
		map.put("sign", sign);
	}
	
	/** 获取MD5值 */
	public static String MD5(String data)
	{
		MessageDigest md5 = null;
		try
		{
			md5 = MessageDigest.getInstance("MD5");
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			e.printStackTrace();
			return "";
		}
		
		char[] charArray = data.toCharArray();
		byte[] byteArray = new byte[charArray.length];
		
		for (int i = 0; i < charArray.length; i++)
			byteArray[i] = (byte) charArray[i];
		
		byte[] md5Bytes = md5.digest(byteArray);
		StringBuffer hexValue = new StringBuffer();
		for (int i = 0; i < md5Bytes.length; i++)
		{
			int val = ((int) md5Bytes[i]) & 0xff;
			if (val < 16) hexValue.append("0");
			hexValue.append(Integer.toHexString(val));
		}
		
		return hexValue.toString();
	}
	
	/** 从网络上下载图片资源 */
	public static Bitmap DownloadBitmap(String imgUrl)
	{
		Bitmap bmp = null;
		try
		{
			URL picUrl = new URL(imgUrl);
			
			// 打开连接
			URLConnection con = picUrl.openConnection();
			InputStream in = con.getInputStream();
			bmp = BitmapFactory.decodeStream(in);
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return bmp;
	}
	
	// 缓存Drawable图像
	private static HashMap<String, Drawable> DrawableDic = new HashMap<String, Drawable>();
	
	/** 从网络上下载图片,转为Drawable */
	public static Drawable DownloadDrawable(String imgUrl)
	{
		Drawable drawable = null;
		
		if (DrawableDic.containsKey(imgUrl))
			drawable = DrawableDic.get(imgUrl);	// 从缓存读取图像
		else
		{
			Bitmap bmp = DownloadBitmap(imgUrl);						// 从服务器端下载图像
			if (bmp != null) drawable = Bitmap2Drawable(bmp);			// 转化为Drawable
			if (drawable != null) DrawableDic.put(imgUrl, drawable);		// 记录图像
		}
		
		return drawable;
	}
	
	/** Bitmap转化为Drawable */
	public static Drawable Bitmap2Drawable(Bitmap bitmap)
	{
		BitmapDrawable drawable = new BitmapDrawable(bitmap);
		return drawable;
	}
	
	/** Drawable转化为Bitmap */
	public static Bitmap Drawable2Bitmap(Drawable drawable)
	{
		BitmapDrawable bitDrawable = (BitmapDrawable) drawable;
		return bitDrawable.getBitmap();
	}
	
}
