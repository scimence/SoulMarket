
package sci.soulmarket.activity.market;

import org.json.JSONArray;
import org.json.JSONObject;

import sci.listview.ListAdapter;
import sci.listview.ListIteamData;
import sci.tool.function.ActivityComponent;
import sci.tool.function.ThreadTool;
import sci.tool.function.WebTool;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;


public class PageHome extends ActivityComponent
{
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_market_home");
		
		ShowList();
	}
	
	/* 设置View点击响应事件 */
	@Override
	public void Click(String viewId)
	{
		// TODO Auto-generated method stub
		String text = "点击了View -> " + viewId;
		Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
		
	}
	
	public void ShowList()
	{
		ThreadTool.getMainHandler().postDelayed(new Runnable()
		{
			@Override
			public void run()
			{
				// String dataUrl0 = "https://scimence.gitee.io/pages/https_img.html?http://avatar.csdn.net/0/F/1/1_ljinshuan.jpg";
				// String webData0 = WebTool.GetString(dataUrl0);
				
				// 获取网络数据， 列表项数据信息获取
				String dataUrl = "https://raw.githubusercontent.com/scimence/AndroidListview/master/files/listData";
				JSONObject webData = WebTool.GetJSONObject(dataUrl);
				
				if (webData != null)
				{
//					// 设置标题栏背景图
//					Drawable tittlePic = WebTool.GetDrawable(webData.optString("tittlePic"));
//					if (tittlePic != null) RelativeLayout("thumbsup_tittle_bg").setBackground(tittlePic);
//					
//					// 设置标题栏显示信息
//					TextView("thumbsup_tittle_note").setText(webData.optString("title"));
					
					// 生成列表项显示到ViewGroup中
					{
						JSONArray data = webData.optJSONArray("listData");		// 数据根据列表项所需数据，自行定义
						
						ListIteamData[] datas = ListIteamData.ToArray(data); 	// 从JSON数据中解析列表信息
						ListAdapter adapter = new ListAdapter(PageHome.this, "list_iteam_layout", datas/* , call */);
						
						LinearLayout content = LinearLayout("list_content");	// 获取页面的LinerLayout作为显示列表的ViewGroup
						adapter.ShowListViewIn(content);	// 显示列表
					}
				}
			}
		}, 1000);	// 在主线程中，延时进行列表信息的载入
	}
}
