﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoulMarket
{
    public class ScTool
    {
        public static string UserName = "sa";
        public static string Password = "Sa12345789";


        /// <summary>
        /// 获取请求参数信息
        /// </summary>
        public static String getParam(HttpRequest Request, Page pageObj)
        {
            String Url = Request.Url.ToString();
            String param = "";
            if (Url.Contains("?"))
            {
                param = Url.Substring(Url.IndexOf("?") + 1);                // 获取参数信息
                param = Encoder.Decode(param);                              // 解码数据

                LogTool log = new LogTool(pageObj.GetType().Name);          // 记录至log中
                log.WriteLine(param);
            }
            return param;
        }

        /// <summary>
        /// 为数据添加段落标签
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string P(string data, string label = "p")
        {
            return "<" + label + ">" + "\r\n" + data + "\r\n" + "</" + label + ">";
        }

        /// <summary>
        /// 以段落形式输出显示；
        /// Response.Write(string);输出现实
        /// </summary>
        /// <param name="data"></param>
        public static string Pre(string data)
        {
            //data = P(data, "code");
            data = P(data, "pre");

            return "\r\n" + data + "\r\n";
        }

        /// <summary>
        /// 消息弹窗；
        /// Response.Write(string);输出现实
        /// </summary>
        /// <param name="msg"></param>
        public static string Alert(string msg)
        {
            return "<script>alert('" + msg + "')</script>";
        }


        /// <summary>
        /// 消息弹窗
        /// </summary>
        public static string Reslut(string msg)
        {
            return "Result(" + msg + ")Result";
        }



        /// <summary>
        /// 查询数据表DB.TAB中的数据，以TAB表进行显示;
        /// 根据ID选取最后1000条，逆序显示
        /// </summary>
        /// <param name="DB">数据库</param>
        /// <param name="TAB">表名称</param>
        public static void showTable(ControlCollection root, DataBase DB, string TAB, string AppendCondition = "")
        {
            if (DB.ExistTab(TAB))
            {
                //string sql = "select * from [" + TAB + "]";
                string sql = "select top 1000 * from [" + TAB + "]";
                if (AppendCondition != null && !AppendCondition.Equals("")) sql += " " + AppendCondition;
                sql = sql + " order by ID desc";

                Table table = DB.Execute(sql).Table();

                Label label = new Label();
                label.ForeColor = Color.BlueViolet;

                label.Text = "\r\n数据表" + TAB + "：";
                root.Add(label);

                //print("数据表" + TAB +"：");
                root.Add(table);
            }
        }


        /// <summary>
        /// 将data按首个以sp分隔两个字符串
        /// </summary>
        public static string[] splitTwo(string data, string sp)
        {
            if (!data.Equals("") && data.Contains(sp))
            {
                int index = data.IndexOf(sp);
                string first = data.Substring(0, index);
                string second = data.Substring(index + sp.Length);

                return new string[] { first, second };
            }
            else return new string[] { data, "" };
        }

        /// <summary>
        /// 解析参数字符串为Dicnary数据；
        /// 如：machinCode=机器码1&soft=easyIcon软件&product=注册0.1元
        /// </summary>
        /// <param name="StaticParam">参数字符串信息</param>
        /// <returns></returns>
        public static Dictionary<string, string> ToParamsDic(string StaticParam)
        {
            Dictionary<string, string> pramsDic = new Dictionary<string, string>();

            if (StaticParam.Contains("&"))
            {

                string[] A = StaticParam.Split('&');
                foreach (string a in A)
                {
                    if (a.Contains("="))
                    {
                        string[] B = ScTool.splitTwo(a, "=");
                        pramsDic.Add(B[0], B[1]);
                    }
                }
            }

            return pramsDic;
        }

        /// <summary>
        /// 获取指定url的网页数据
        /// </summary>
        public static String getWebData(String url)
        {
            String data = "";

            WebClient client = new WebClient();
            client.Encoding = System.Text.Encoding.UTF8;
            data = client.DownloadString(url);

            return data;
        }



        //static bool isTest = false;
        //private static void TestLogic(String jsonData)
        //{
        //    isTest = true;
        //    String Id = getJsonValue(jsonData, "ID");
        //    String QrUrl = getJsonValue(jsonData, "QrUrl");
        //    String dateTime = getJsonValue(jsonData, "dateTime");
        //    String count = getJsonValue(jsonData, "count");
        //    String HbUrl = getJsonValue(jsonData, "HbUrl");
        //    String t = "";
        //}

        /// <summary>
        /// {"ID":100,"QrUrl":"https://qr.alipay.com/tsx031041ajtuiviwd978b6","HbUrl":"https://qr.alipay.com/c1x01990gbhjvuvwaxwkqa3","Tittle":"通用红包商","ext":"","dateTime":"2018-10-04_16:18:41","count":"14"}
        /// 
        /// 解析json数据中指定的key
        /// </summary>
        /// <param name="jsonData"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static String getJsonValue(String jsonData, String key)
        {
            //if (!isTest) TestLogic(jsonData);

            String value = "";
            if (jsonData.StartsWith("{") && jsonData.EndsWith("}"))
            {
                jsonData = jsonData.Substring(1, jsonData.Length - 2);

                key = "\"" + key + "\":";   // 引号包含的键名
                if (jsonData.Contains(key))
                {
                    if (jsonData.StartsWith(key)) jsonData = jsonData.Substring(key.Length);
                    else
                    {
                        int index = jsonData.IndexOf(/*"," + */key);
                        jsonData = jsonData.Substring(index + key.Length + 1);
                    }

                    if (jsonData.StartsWith("\""))
                    {
                        int index = 1;

                        String subValue = "";
                        do
                        {
                            index = jsonData.IndexOf("\"", index);
                            if (index != -1) subValue = jsonData.Substring(1, index - 1);
                        }
                        while (subValue.EndsWith("\\"));    // 若是以转义符号结尾的则继续向后解析
                        value = subValue;
                    }
                    else
                    {
                        int index = jsonData.IndexOf(",");
                        if (index != -1) value = jsonData.Substring(0, index);
                        else value = jsonData;
                    }
                }
            }

            return value;
        }

        /// <summary>
        /// 替换jsonData中的key对应数据为newValue
        /// </summary>
        /// <param name="jsonData"></param>
        /// <param name="key"></param>
        /// <param name="newValue"></param>
        /// <returns></returns>
        public static String ReplaceJsonValue(String jsonData, String key, String newValue)
        {
            String value = ScTool.getJsonValue(jsonData, key);
            String valueStr = "\"HbUrl\":\"" + value + "\"";
            String valueStr2 = "\"HbUrl\":" + value;

            if (jsonData.Contains(valueStr))
            {
                String valueStrNew = "\"HbUrl\":\"" + newValue + "\"";
                jsonData = jsonData.Replace(valueStr, valueStrNew);
            }
            else if (jsonData.Contains(valueStr2))
            {
                String valueStrNew = "\"HbUrl\":" + newValue;
                jsonData = jsonData.Replace(valueStr2, valueStrNew);
            }

            return jsonData;
        }

        /// <summary>
        /// 将参数信息转化为Json串
        /// </summary>
        public static String ToJson(string status, string msg, Dictionary<string, string> param = null)
        {
            StringBuilder Builder = new StringBuilder();
            int rows = 0;


            Builder.Append("{");

            Builder.Append("\"status\"" + ":" + "\"" + status + "\"");
            Builder.Append(",");
            Builder.Append("\"msg\"" + ":" + "\"" + msg + "\"");

            if (param != null)
            {
                foreach (string key in param.Keys)
                {
                    Builder.Append(",");

                    string strKey = "\"" + key + "\"";
                    string strValue = "\"" + param[key] + "\"";
                    Builder.Append(strKey + ":" + strValue);
                }
            }

            Builder.Append("}");

            //if (rows > 1) return "[" + Builder.ToString() + "]";
            return Builder.ToString();
        }

        // 从自定义格式的数据data中，获取key对应的节点数据
        // scimence(NeedToRegister(false)NeedToRegister;RegisterPrice(1)RegisterPrice;)scimence
        // NeedToRegister(false)   finalNode的数据格式
        public static string getNodeData(string data, string key, bool finalNode)
        {
            try
            {
                string S = key + "(", E = ")" + (finalNode ? "" : key);
                int indexS = data.IndexOf(S) + S.Length;
                int indexE = data.IndexOf(E, indexS);

                return data.Substring(indexS, indexE - indexS);
            }
            catch (Exception) { return data; }
        }
    }
}