﻿package com.joymeng.demo;

import java.util.HashMap;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.joymeng.payment.Payment;
import com.joymeng.payment.R;
import com.joymeng.payment.RealnameActivity;
import com.joymeng.payment.core.PaymentKey;


public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.jmapy_demo_main);
		Payment.getInstance().init(this, true);
		// pay();
	}
	
	public void onClick(View view)
	{
		if (view.getId() == R.id.payment) pay();		// 支付
		else if (view.getId() == R.id.realname) RealnameActivity.Show(this, "1001", "100000003", null);	// 实名认证
	}
	
	private void pay()
	{
		// {MoneyAmount=1000, LtInstantId=780,
		// ProductIcon=lt_netgame_item_yuanbao, ProductDescript=10元/100元宝,
		// LtReserve=12214,6,588668, RoleLevel=12, ProductId=6, LtAppId=6,
		// RoleId=12214, RoleName=卓攀哲, LtInstantAlias=西游内网全渠道, RoleVipLevel=3,
		// RoleBalance=910, RolePartyName=无帮派, ProductName=100元宝,
		// AppName=大话西游之月光宝盒（电影正版）}
		
		HashMap<String, String> payInfo = new HashMap<String, String>();
		payInfo.put(PaymentKey.LtJoyId, "20048");
		payInfo.put(PaymentKey.LtAppId, "906");
		// payInfo.put(PaymentKey.LtAppId, "1009");
		payInfo.put(PaymentKey.LtInstantId, "780");
		payInfo.put(PaymentKey.LtReserve, "12214,6,588668");
		payInfo.put(PaymentKey.MoneyAmount, "1");
		payInfo.put(PaymentKey.ProductName, "0.1元宝");
		payInfo.put(PaymentKey.ProductDescript, "100元宝/10元");
		
		Payment.getInstance().pay(payInfo);
	}
	
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		Payment.getInstance().destroy();
	}
	
	public void onBackPressed()
	{
		this.finish();
	}
}
