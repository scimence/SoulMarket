﻿
package com.joymeng.payment;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.fxlib.util.FAApk;
import com.fxlib.util.FJHttp;
import com.fxlib.util.FJThread;
import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;


// 检测是否已实名 ->> http://netuser.joymeng.com/XXX?uid=100000001&appId=1001
// 上传用户实名信息 ->> http://netuser.joymeng.com/XXX?uid=100000001&uname=%E6%9D%8E&IdNumber=121313324234x&appId=1001

// 检测是否已实名 ->>http://netuser.joymeng.com/valid/check?uid=100000001&appId=1001
// 上传用户实名信息 ->>http://netuser.joymeng.com/valid/comit?uid=100000001&uname=%E6%9D%8E&IdNumber=121313324234x&appId=1001

/** RealnameRegister.java: 游戏用户实名注册界面 ----- 2018-5-4 下午5:45:45 wangzhongyuan */
public class RealnameActivity extends Activity
{
	EditText userName;		// 用户名
	EditText IdNumber;		// 身份证号
	TextView SubmitBtn;		// 提交按钮
	ImageView CloseBtn;		// 关闭按钮
	
	static String TAG = "ltsdk";
	static RealnameActivity Instance;
	public static String appId;			// 乐堂应用id
	public static String uid;			// 乐堂用户id
	static CallBack RealNameCall;		
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		this.setContentView(ResUtil.getId(this, "jmpay_dialog_realname_register", "layout"));
		
		userName = (EditText) this.findViewById(ResUtil.getId(this, "realname_et_name", "id"));
		IdNumber = (EditText) this.findViewById(ResUtil.getId(this, "realname_et_idnumber", "id"));
		
		SubmitBtn = (TextView) this.findViewById(ResUtil.getId(this, "realname_btn_submit", "id"));
		CloseBtn = (ImageView) this.findViewById(ResUtil.getId(this, "relative_iv_close", "id"));
		
		SubmitBtn.setOnClickListener(clickListener);
		CloseBtn.setOnClickListener(clickListener);
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == SubmitBtn)		// 提交用户角色信息
			{
				String name = userName.getText().toString().trim();
				String idNum = IdNumber.getText().toString().trim();
				
				if (name.equals(""))
					showToast("姓名不可为空");
				else if (idNum.equals("") || idNum.length() != 18)
					showToast("请输入有效的身份证信息");
				else
				{
					CallBack uploadCall = new CallBack()
					{
						@Override
						public void Onfail()
						{
							
						}
						
						@Override
						public void OnSuccess()
						{
							Instance.finish();						// 实名认证完成，结束当前Activity
						}
					};
					
					upload_RealNameInfo(name, idNum, uploadCall);	// 上传用户实名信息
				}
			}
			else if (v == CloseBtn) // 关闭
			{
				Instance.finish();
			}
		}
	};
	
	public void finish()
	{
		super.finish();
		if(RealNameCall != null) RealNameCall.OnSuccess();			// 实名认证逻辑执行完成
	}
	
	/** 检测是否已实名，未实名则显示实名注册界面 */
	public static void Show(final Context context, String appId, String uid, final CallBack RealNameCall)
	{
		RealnameActivity.appId = appId;
		RealnameActivity.uid = uid;
		RealnameActivity.RealNameCall = RealNameCall;
		
		CallBack call = new CallBack()
		{
			@Override
			public void Onfail()
			{
				showRealNameActivity(context);	// 若未实名认证，则显示实名认证界面
			}
			
			@Override
			public void OnSuccess()
			{	
				if(RealNameCall != null) RealNameCall.OnSuccess();	// 实名认证逻辑执行完成
			}
		};
		
		checkRealName(appId, uid, call);		// 检测用户是否已实名
	}
	
	/** 显示实名注册界面 */
	static void showRealNameActivity(final Context context)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				Intent intent = new Intent(context, RealnameActivity.class);
				context.startActivity(intent);
			}
		});
	}
	
	static void showToast(final String info)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				Log.d(TAG, info);
				Toast.makeText(Instance, info, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	/** 检测是否已实名 */
	static void checkRealName(final String appId, final String uid, final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String loginUrl = "http://netuser.joymeng.com/valid/check";
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("appId", appId);
					map.put("uid", uid);
					Log.d(TAG, "检测是否已实名 ->> " + loginUrl + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					
					String rdata = FJHttp.request(loginUrl, map, "get");
					Log.d(TAG, "服务器返回信息 ->> " + rdata);// 服务器返回信息 ->> {"status":0,"msg":"fail"}
					
					
					JSONObject userJson = new JSONObject(rdata);
					String msg = userJson.optString("msg", "");
					
					if(msg.equals("fail"))
					{
						if (call != null) call.Onfail();
					}
					else
					{
						if (call != null) call.OnSuccess();
					}
					
				}
				catch (Exception ex)
				{
					showToast("是否已实名，检测异常！");
					ex.printStackTrace();
					
					if (call != null) call.OnSuccess();
				}
			}
		});
	}
	
	/** 上传用户实名信息 */
	void upload_RealNameInfo(final String name, final String IdNumber, final CallBack uploadCall)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String loginUrl = "http://netuser.joymeng.com/valid/comit";
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("appId", appId);
					map.put("uid", uid);
					map.put("uname", name);
					map.put("IdNumber", IdNumber);
					Log.d(TAG, "上传用户实名信息 ->> " + loginUrl + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					
					String rdata = FJHttp.request(loginUrl, map, "get");
					Log.d(TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					String msg = userJson.optString("msg", "");
					
					if(msg.equals("fail"))
					{
						showToast("实名认证失败。\r\n请输入有效的姓名、身份证信息！");
					}
					else if(msg.equals("success")) 
					{
						Log.d(TAG, "实名认证完成！");
						uploadCall.OnSuccess();
					}
				}
				catch (Exception ex)
				{
					showToast("上传用户实名信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}
}
