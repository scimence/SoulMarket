﻿package com.joymeng.payment.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Locale;

import android.util.Log;

public class HttpUtil {

	private static final int connectTimeout = 5000;
	private static final int readTimeout = 15000;
	private static String CHARSET = "UTF-8";

	public static String request(String url, HashMap<String, String> map, String method) {
		return request(url, praseMap(map), method);
	}

	public static String request(String url, String data, String method) {
//		 Log.e("Ltsdk", url + "?" + data);
		StringBuffer sb = null;
		HttpURLConnection conn = null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		try {
			data = (data == null) ? "" : data;
			method = method.toUpperCase(Locale.getDefault());
			if ("GET".equals(method) && !"".equals(data)) {
				url += "?" + data;
				data = "";
			}
			URL u = new URL(url);
			conn = (HttpURLConnection) u.openConnection();
			conn.setRequestMethod(method);
			conn.setConnectTimeout(connectTimeout);
			conn.setReadTimeout(readTimeout);
			if ("POST".equals(method))
				conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.connect();
			// 传送数据
			if (!"".equals(data)) {
				bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream(), CHARSET));
				bw.write(data);
				bw.flush();
			}
			// 接收数据
			if (conn.getResponseCode() == 200) {
				sb = new StringBuffer();
				br = new BufferedReader(new InputStreamReader(conn.getInputStream(), CHARSET));
				String line;
				while ((line = br.readLine()) != null)
					sb.append(line).append(System.getProperty("line.separator"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
			} catch (Exception e) {
			}
			try {
				if (br != null)
					br.close();
			} catch (Exception e) {
			}
			try {
				conn.disconnect();
			} catch (Exception e) {
			}
		}
		return (sb == null) ? null : sb.toString();
	}

	/**
	 * 解析map
	 */
	private static String praseMap(HashMap<String, String> map) {
		StringBuffer sb = null;
		if (map != null && !map.isEmpty()) {
			sb = new StringBuffer();
			try {
				for (String k : map.keySet()) {
					if (k != null && !"".equals(k)) {
						String v = map.get(k);
						sb.append("&").append(k).append("=").append(URLEncoder.encode(v, CHARSET));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return (sb == null) ? null : sb.toString().substring(1);
	}
}
