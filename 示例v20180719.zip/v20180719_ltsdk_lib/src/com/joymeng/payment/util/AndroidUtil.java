﻿
package com.joymeng.payment.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;


public class AndroidUtil
{
	private static ExecutorService mThreadPool;
	
	/** 打印Toast信息 */
	public static void printToast(final Context context, final String toast)
	{
		if (Thread.currentThread() != Looper.getMainLooper().getThread())
		{
			Handler handler = new Handler(Looper.getMainLooper());
			handler.post(new Runnable()
			{
				@Override
				public void run()
				{
					printToast(context, toast);
				}
			});
			return;
		}
		Toast.makeText(context, toast, Toast.LENGTH_SHORT).show();
	}
	
	/** 获取线程池 */
	public static ExecutorService getThreadPool()
	{
		if (mThreadPool == null) mThreadPool = Executors.newCachedThreadPool();
		return mThreadPool;
	}
	
	/** 检查网络是否可用 */
	public static boolean isNetworkAvaliable(Context context)
	{
		// 获取所有连接管理对象
		ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (null != cm)
		{
			// 获取网络连接管理的对象
			NetworkInfo info = cm.getActiveNetworkInfo();
			if (null != info && info.isConnected())
			{
				// 判断当前网络是否已经连接
				if (NetworkInfo.State.CONNECTED == info.getState()) { return true; }
			}
		}
		return false;
	}
}
