﻿package com.joymeng.payment.util;

import android.content.Context;

public class ResUtil {
	/**
	 * 获取资源id
	 */
	public static int getId(Context context, String name, String defType) {
		return context.getResources().getIdentifier(name, defType, context.getPackageName());
	}

	public static String getString(Context context, String name, String defval) {
		int id = getId(context, name, "string");
		if (id != 0) {
			return context.getResources().getString(id);
		}
		return defval;
	}
}
