﻿
package com.joymeng.payment.core;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.fxlib.util.FJHttp;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.joymeng.payment.util.ResUtil;
import com.joymeng.payment.util.alipay.PayResult;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;


public class WeChatDialog extends Dialog
{
	private static final int SDK_PAY_FLAG = 1;
	private Spinner mSpinner;
	private Button mSubmit;
	private ImageButton mHeaderGoback;
	private HashMap<String, String> mPayInfo;
	
	private Activity mActivity;
	private Context mAppContext;
	
	public WeChatDialog(Activity activity, HashMap<String, String> payInfo, DialogCallback callback)
	{
		super(activity, android.R.style.Theme_Light_NoTitleBar_Fullscreen);
		mActivity = activity;
		mAppContext = mActivity.getApplicationContext();
		mPayInfo = payInfo;
		
		setContentView(ResUtil.getId(mAppContext, "jmpay_dialog_wechat", "layout"));
		initUI();
		initAction();
	}
	
	private void initUI()
	{
		// 金额列表
		mSpinner = (Spinner) findViewById(ResUtil.getId(mAppContext, "jmpay_choose_topup_spinner", "id"));
		int money = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount)) / 100;
		if (money > 0)
		{
			SpinnerAdapter adapter = mSpinner.getAdapter();
			int count = adapter.getCount(), index = count;
			String item;
			for (int i = 0; i < count; i++)
			{
				item = (String) adapter.getItem(i);
				item = item.substring(0, item.length() - 1);
				if (money <= Integer.parseInt(item))
				{
					index = i;
					break;
				}
			}
			mSpinner.setSelection(index);
		}
		
		// 提交按钮
		mSubmit = (Button) findViewById(ResUtil.getId(mAppContext, "jmpay_button_pay", "id"));
		mSubmit.setEnabled(true);
		// 返回按钮
		mHeaderGoback = (ImageButton) findViewById(ResUtil.getId(mAppContext, "jmpay_header_goback", "id"));
	}
	
	private void initAction()
	{
		// 添加返回按钮事件
		mHeaderGoback.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				WeChatDialog.this.dismiss();
			}
		});
		
		// 支付按钮
		mSubmit.setOnClickListener(new View.OnClickListener()
		{
			
			@Override
			public void onClick(View v)
			{
				mSubmit.setEnabled(false);
				
				String selectMoney = (String) mSpinner.getSelectedItem();
				selectMoney = selectMoney.substring(0, selectMoney.length() - 1);
				int money0 = Integer.parseInt(selectMoney) * 100;
				
				// 若为调试模式，则使用传入金额
				if (PaymentActivity.isDebugMode) money0 = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount));
				final int money = money0;
				
				AlertDialog.Builder tip = new AlertDialog.Builder(mActivity);
				tip.setCancelable(false);
				tip.setMessage("处理中...");
				final AlertDialog ad = tip.create();
				ad.show();
				AndroidUtil.getThreadPool().execute(new Runnable()
				{
					@Override
					public void run()
					{
						if (AndroidUtil.isNetworkAvaliable(mAppContext))
						{
							try
							{
								// 从计费服务器获取微信支付订单信息
								
								// HashMap<String, String> request = new
								// HashMap<String, String>();
								// request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
								// request.put("appId",
								// mPayInfo.get(PaymentKey.LtAppId));
								// request.put("instantid",
								// mPayInfo.get(PaymentKey.LtInstantId));
								// request.put("reserve",
								// mPayInfo.get(PaymentKey.LtReserve));
								// request.put("plat_type", "weichat");
								// request.put("plat_version", "2");
								// request.put("money", money + ""); // 单位：分
								// // request.put("money", "1"); // 单位：分
								//
								// String PRIV_ORDER_URL =
								// mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
								// String rval =
								// HttpUtil.request(PRIV_ORDER_URL, request,
								// "post");
								//
								// Log.e("Ltsdk", "createLtOrder() ->> request:"
								// + request.toString()); // 创建订单请求信息
								// Log.e("Ltsdk", "createLtOrder() ->> rdata:" +
								// rval); // 请求返回值
								// Log.e("Ltsdk", "创建订单请求 ->> " + PRIV_ORDER_URL
								// + "?" + FJHttp.praseMap(request,
								// FJHttp.DEFAULT_CHARSET)); // 请求参数信息
								//
								// JSONObject json = new JSONObject(rval);
								// JSONObject platData =
								// json.getJSONObject("plat_data");
								//
								// // 根据订单信息开始进行支付
								// String orderInfo =
								// platData.getString("content");
								// String sign = platData.getString("sign");
								// String info = orderInfo + "&sign=" + "\"" +
								// sign + "\"" + "&sign_type=\"RSA\"";
								// Log.e("Ltsdk", "调用支付包接口支付参数: " + info);
								
								String url = "http://wxpay.wxutil.com/pub_v2/app/app_pay.php";
								
								String data = HttpUtil.request(url, "", "post");
								JSONObject json = new JSONObject(data);
								Log.d("Ltsdk", "请求地址 ->> " + url); // 请求参数信息
								Log.d("Ltsdk", "获取微信支付订单信息 ->> " + data); // 请求参数信息
								
								PayReq req = new PayReq();
								// req.appId = "wxf8b4f85f3a794e77"; // 测试用appId
								req.appId = json.getString("appid");
								req.partnerId = json.getString("partnerid");
								req.prepayId = json.getString("prepayid");
								req.nonceStr = json.getString("noncestr");
								req.timeStamp = json.getString("timestamp");
								req.packageValue = json.getString("package");
								req.sign = json.getString("sign");
								req.extData = "app data"; // optional
								
								WeChatPay(req);
								
							}
							catch (Exception e)
							{
								e.printStackTrace();
							}
						}
						else
						{
							AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
							mActivity.runOnUiThread(new Runnable()
							{
								@Override
								public void run()
								{
									mSubmit.setEnabled(true);
								}
							});
						}
						ad.dismiss();
					}
				});
			}
		});
	}
	
	IWXAPI api = null;
	
	private void WeChatPay(final PayReq req)
	{
		mActivity.runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				if (api == null) api = WXAPIFactory.createWXAPI(mActivity, "wxb4ba3c02aa476ea1"); // 微信应用接口
				// msgApi.registerApp("wxd930ea5d5a258f4f"); //
				// 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
				
				Toast.makeText(mActivity, "正常调起支付", Toast.LENGTH_SHORT).show();
				api.sendReq(req);
				WeChatDialog.this.dismiss();
			}
		});
	}
	
}
