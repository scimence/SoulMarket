﻿
package com.joymeng.payment.core;

public interface DialogCallback
{
	public void onCallback(String type, Object data);
}
