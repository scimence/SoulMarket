﻿
package com.joymeng.payment.core;

import java.util.HashMap;
import org.json.JSONObject;

import com.fxlib.util.FJHttp;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.activity.PayPage;
import com.ltpay.activity.PaySuccess;
import com.ltpay.function.Tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;


public class YeepayDialog extends Dialog
{
	protected static final String TAG = "Joypay";
	
	protected static final int MSG_PAY_RESULT = 100;
	private Activity mActivity;
	private Context mAppContext;
	
	private Spinner mSpinnerMoney;		// 金额选择列表
	private Spinner mSpinner;
	private Button mSubmit;
	private ImageButton mHeaderGoback;
	private HashMap<String, String> mPayInfo;
	private EditText mCardNo;
	private EditText mCardPw;
	// 支持点卡类型
	private static final HashMap<String, String> mCardType = new HashMap<String, String>();
	static
	{
		mCardType.put("骏网一卡通", "JUNNET");
		mCardType.put("盛大卡", "SNDACARD");
		mCardType.put("征途卡", "ZHENGTU");
		mCardType.put("Q币卡", "QQCARD");
		mCardType.put("久游卡", "JIUYOU");
		mCardType.put("易宝e卡通", "YPCARD");
		mCardType.put("网易卡", "NETEASE");
		mCardType.put("完美卡", "WANMEI");
		mCardType.put("搜狐卡", "SOHU");
		mCardType.put("纵游一卡通", "ZONGYOU");
		mCardType.put("天下一卡通", "TIANXIA");
		mCardType.put("天宏一卡通", "TIANHONG");
	}
	
	public YeepayDialog(Activity activity, HashMap<String, String> payInfo, DialogCallback callback)
	{
		super(activity, android.R.style.Theme_Light_NoTitleBar_Fullscreen);
		mActivity = activity;
		mAppContext = mActivity.getApplicationContext();
		mPayInfo = payInfo;
		
		setContentView(ResUtil.getId(mAppContext, "jmpay_dialog_yeepay", "layout"));
		initUI();
		initAction();
	}
	
	private void initUI()
	{
		// 金额列表
		mSpinnerMoney = (Spinner) findViewById(ResUtil.getId(mAppContext, "jmpay_choose_topup_spinner", "id"));
		int money = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount)) / 100;
		if (money > 0)
		{
			SpinnerAdapter adapter = mSpinnerMoney.getAdapter();
			int count = adapter.getCount(), index = count;
			String item;
			for (int i = 0; i < count; i++)
			{
				item = (String) adapter.getItem(i);
				item = item.substring(0, item.length() - 1);
				if (money <= Integer.parseInt(item))
				{
					index = i;
					break;
				}
			}
			mSpinnerMoney.setSelection(index);
		}
		
		// 点卡类型
		mSpinner = (Spinner) findViewById(ResUtil.getId(mAppContext, "jmpay_yeepay_card_type", "id"));
		// 提交按钮
		mSubmit = (Button) findViewById(ResUtil.getId(mAppContext, "jmpay_button_pay", "id"));
		mSubmit.setEnabled(true);
		// 返回按钮
		mHeaderGoback = (ImageButton) findViewById(ResUtil.getId(mAppContext, "jmpay_header_goback", "id"));
		// 卡号和卡密
		mCardNo = (EditText) findViewById(ResUtil.getId(mAppContext, "jmpay_yeepay_cardno", "id"));
		mCardPw = (EditText) findViewById(ResUtil.getId(mAppContext, "jmpay_yeepay_cardpw", "id"));
	}
	
	private void initAction()
	{
		// 添加返回按钮事件
		mHeaderGoback.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				YeepayDialog.this.dismiss();
			}
		});
		
		// 支付按钮
		mSubmit.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				String selectMoney = (String) mSpinnerMoney.getSelectedItem();
				selectMoney = selectMoney.substring(0, selectMoney.length() - 1);
				final int money = Integer.parseInt(selectMoney) * 100;
				
				// 点卡类型
				String cardName = mSpinner.getSelectedItem().toString();
				final String cardType = mCardType.get(cardName);
				if (cardType == null || "".equals(cardType))
				{
					AndroidUtil.printToast(mAppContext, "请选择点卡类型");
					return;
				}
				// 卡号和卡密
				final String no = mCardNo.getText().toString();
				final String pw = mCardPw.getText().toString();
				if ("".equals(no) || "".equals(pw))
				{
					AndroidUtil.printToast(mAppContext, "序列号或卡密不能为空");
					return;
				}
				
				mSubmit.setEnabled(false);
				
				final AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
				builder.setTitle("确认支付");
				// builder.setMessage("您确定使用" + cardName + "进行充值？");
				builder.setMessage("您确定使用" + cardName + "，充值" + selectMoney + "元？");
				builder.setPositiveButton("确认", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int whichButton)
					{
						AlertDialog.Builder tip = new AlertDialog.Builder(mActivity);
						tip.setCancelable(false);
						tip.setMessage("处理中...");
						final AlertDialog ad = tip.create();
						ad.show();
						AndroidUtil.getThreadPool().execute(new Runnable()
						{
							@Override
							public void run()
							{
								try
								{
									if (AndroidUtil.isNetworkAvaliable(mAppContext))
									{
										HashMap<String, String> request = new HashMap<String, String>();
										PayPage.AppendPayParams(request);
										
										request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
										request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
										request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
										request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
										request.put("plat_type", "yeepay");
										// request.put("money", mPayInfo.get(PaymentKey.MoneyAmount)); // 单位：分
										request.put("money", money + ""); // 单位：分
										request.put("product_name", mPayInfo.get(PaymentKey.ProductName));
										request.put("product_descript", mPayInfo.get(PaymentKey.ProductDescript));
										request.put("card_type", cardType);
										request.put("card_no", no);
										request.put("card_pw", pw);
										
										// 新增参数用于消费记录信息
										request.put("couponId", mPayInfo.get(PaymentKey.CouponId)); 			// 优惠券id
										request.put("productId", mPayInfo.get(PaymentKey.ProductId)); 			// 商品id
										request.put("productMoney", mPayInfo.get(PaymentKey.ProductMoney)); 	// 商品金额
										request.put("productName", mPayInfo.get(PaymentKey.ProductName)); 		// 商品名称
										
										request.put("balance_consume", mPayInfo.get(PaymentKey.BalanceCounsume));	// 消费余额数
										request.put("password", mPayInfo.get(PaymentKey.UserPassword));			// 用户密码
										
										String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
										String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
										
										Log.d(Tools.TAG, "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
										Log.d(Tools.TAG, "createLtOrder() ->> rdata:" + rval); // 请求返回值
										Log.d(Tools.TAG, "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
										
										JSONObject json = new JSONObject(rval);
										PayPage.LtOrderId = json.optString("orderId", "");
										Log.d(Tools.TAG, "LtOrderId:" + PayPage.LtOrderId);
										
										if (mPayInfo.get(PaymentKey.MoneyAmount).equals("0"))	// 通过优惠券支付成功
										{
											String plat_data = json.optString("plat_data", "");
											if (!plat_data.equals(""))
											{
												PayPage.PaySuccess(mActivity);
											}
											else
											{
												String msg = json.optString("msg", "");			// 显示支付失败信息
												Tools.showToast(mActivity, msg);
												
												PayPage.PayFail(mActivity);
											}
											return;
										}
										
										JSONObject platData = json.getJSONObject("plat_data");
										// 根据订单信息开始进行支付
										AndroidUtil.printToast(mAppContext, platData.getString("msg"));
										
										// {
										// "gold_name": "金币",
										// "gold_rate": 20,
										// "orderId": "1332425",
										// "plat_data": {
										// "status": 0,
										// "msg": "错误，8002"
										// }
										// }
										
										String status = json.getJSONObject("plat_data").optString("status", "");
										String msg = json.getJSONObject("plat_data").optString("msg", "");
										
										if (status.equals("0") || msg.contains("错误"))
											PayPage.PayFail(mActivity);			// 支付失败
										else PayPage.PaySuccess(mActivity);		// 支付成功
									}
									else
									{
										AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
									}
								}
								catch (Exception e)
								{
									e.printStackTrace();
									PayPage.PayFail(mActivity);			// 支付失败
								}
								ad.dismiss();
								YeepayDialog.this.dismiss();
							}
						});
					}
				});
				
				builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int whichButton)
					{
						mSubmit.setEnabled(true);
						PayPage.PayFail(mActivity);
					}
				});
				builder.show();
			}
		});
	}
}
