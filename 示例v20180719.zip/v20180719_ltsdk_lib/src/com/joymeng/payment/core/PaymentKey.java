﻿
package com.joymeng.payment.core;

public class PaymentKey
{
	// 乐堂用户ID
	public static final String LtJoyId = "LtJoyId";
	// 乐堂定义的AppId
	public static final String LtAppId = "LtAppId";
//	// 乐堂定义的AppId
//	public static final String SubChannelId = "SubChannelId";
	// 乐堂服务器ID
	public static final String LtInstantId = "LtInstantId";
	// 乐堂计费需要的一些参数
	public static final String LtReserve = "LtReserve";
	// 所购买商品金额，单位：分
	public static final String MoneyAmount = "MoneyAmount";

	// 所购商品Id
	public static final String ProductId = "ProductId";
	// 所购商品名称
	public static final String ProductName = "ProductName";
	// 所购商品名称
	public static final String ProductMoney = "ProductMoney";
	// 优惠券id
	public static final String CouponId = "CouponId";

	// 消费余额数
	public static final String BalanceCounsume = "BalanceCounsume";
	// 乐堂游戏用户登录密码
	public static final String UserPassword = "UserPassword";
	
	// 所购商品名描述
	public static final String ProductDescript = "ProductDescript";
	
	// *** 私有名称 ***
	// 订单请求地址
	public static final String PRIV_ORDER_URL = "PrivOrderUrl";
	// 订单回调地址
	public static final String PRIV_CALLBACK_URL = "PrivCallbackUrl";
	
}
