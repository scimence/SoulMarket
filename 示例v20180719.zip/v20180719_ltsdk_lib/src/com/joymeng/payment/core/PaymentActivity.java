﻿
package com.joymeng.payment.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.joymeng.payment.util.ResUtil;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;


public class PaymentActivity extends Activity
{
	public static boolean isDebugMode = false;		// 记录当前是否为调试模式
	
	private Context mAppContext;
	private boolean isLandscape;
	private HashMap<String, String> mPayInfo;
	
	// public static boolean islandscape = true; // 是否为横屏显示支付界面
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		mAppContext = getApplicationContext();
		Intent intent = getIntent();
		isLandscape = intent.getBooleanExtra("landscape", false/* islandscape */);
		mPayInfo = (HashMap<String, String>) getIntent().getSerializableExtra("payInfo");
		
		setTheme(android.R.style.Theme_Light_NoTitleBar_Fullscreen);
		setRequestedOrientation(isLandscape ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		setContentView(ResUtil.getId(mAppContext, "jmpay_dialog_main", "layout"));
		
		initUI();
		initAction();
	}
	
	private void initUI()
	{
		// 添加支付平台选择
		int itemLayout = ResUtil.getId(mAppContext, "jmpay_list_dialog_item", "layout");
		int itemImg = ResUtil.getId(mAppContext, "jmpay_list_dialog_item_img", "id");
		int itemTitle = ResUtil.getId(mAppContext, "jmpay_list_dialog_item_title", "id");
		
		ListAdapter adapter = new SimpleAdapter(mAppContext, getData(), itemLayout, new String[] { "img", "title" }, new int[] { itemImg, itemTitle });
		ListView list = (ListView) findViewById(ResUtil.getId(mAppContext, "jmpay_list_dialog_item", "id"));
		list.setAdapter(adapter);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				switch (position)
				{
					case 0:
						platAlipay();
						break;
					case 1:
						platTenpay();
						break;
					case 2:
						platUnionpay();
						break;
					case 3:
						platShenzhoufu("YD");
						break;
					case 4:
						platShenzhoufu("LT");
						break;
					case 5:
						platGamecard();
						break;
					case 6:
						platWeChatpay();
						break;
					
					default:
						break;
				}
			}
		});
	}
	
	private List<Map<String, Object>> getData()
	{
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> map;
		
		// 支付宝，位置：0
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_alipay", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_alipay_title", "Empty Title"));
		list.add(map);
		// 腾讯通，位置：1
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_tenpay", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_tenpay_title", "Empty Title"));
		list.add(map);
		// 银联，位置：2
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_unionpay", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_unionpay_title", "Empty Title"));
		list.add(map);
		// 移动卡，位置：3
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_yidong", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_shenzhoufu_title_yd", "Empty Title"));
		list.add(map);
		// 联通卡，位置：4
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_liantong", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_shenzhoufu_title_lt", "Empty Title"));
		list.add(map);
		// 易宝支付，位置：5
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_yeepay", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_yeepay_title", "Empty Title"));
		list.add(map);
		// 微信支付，位置：6
		map = new HashMap<String, Object>();
		map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_wechat", "drawable"));
		map.put("title", ResUtil.getString(mAppContext, "jmpay_wechat_title", "Empty Title"));
		list.add(map);
		return list;
	}
	
	private void initAction()
	{
		// 添加返回按钮事件
		ImageButton headerGoback = (ImageButton) findViewById(ResUtil.getId(mAppContext, "jmpay_header_goback", "id"));
		headerGoback.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				PaymentActivity.this.finish();
			}
		});
	}
	
	/** 支付宝支付 */
	private void platAlipay()
	{
		Dialog dialog = new AlipayDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		});
		dialog.show();
	}
	
	/** 微信支付 */
	private void platWeChatpay()
	{
		Dialog dialog = new WeChatDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		});
		dialog.show();
	}
	
	private void platTenpay()
	{
		Dialog dialog = new TenpayDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		});
		dialog.show();
	}
	
	private void platUnionpay()
	{
		Dialog dialog = new UnionpayDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		});
		dialog.show();
	}
	
	private void platShenzhoufu(String type)
	{
		Dialog dialog = new ShenzhoufuDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		}, type);
		dialog.show();
	}
	
	private void platGamecard()
	{
		Dialog dialog = new YeepayDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		});
		dialog.show();
	}
}
