﻿
package com.joymeng.payment.core;

import java.util.HashMap;
import org.json.JSONObject;
import com.alipay.sdk.app.PayTask;
import com.fxlib.util.FJHttp;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.joymeng.payment.util.ResUtil;
import com.joymeng.payment.util.alipay.PayResult;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;


public class AlipayDialog extends Dialog
{
	private static final int SDK_PAY_FLAG = 1;
	private Spinner mSpinner;
	private Button mSubmit;
	private ImageButton mHeaderGoback;
	private HashMap<String, String> mPayInfo;
	
	private Activity mActivity;
	private Context mAppContext;
	
	public AlipayDialog(Activity activity, HashMap<String, String> payInfo, DialogCallback callback)
	{
		super(activity, android.R.style.Theme_Light_NoTitleBar_Fullscreen);
		mActivity = activity;
		mAppContext = mActivity.getApplicationContext();
		mPayInfo = payInfo;
		
		setContentView(ResUtil.getId(mAppContext, "jmpay_dialog_alipay", "layout"));
		initUI();
		initAction();
	}
	
	private void initUI()
	{
		// 金额列表
		mSpinner = (Spinner) findViewById(ResUtil.getId(mAppContext, "jmpay_choose_topup_spinner", "id"));
		int money = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount)) / 100;
		if (money > 0)
		{
			SpinnerAdapter adapter = mSpinner.getAdapter();
			int count = adapter.getCount(), index = count;
			String item;
			for (int i = 0; i < count; i++)
			{
				item = (String) adapter.getItem(i);
				item = item.substring(0, item.length() - 1);
				if (money <= Integer.parseInt(item))
				{
					index = i;
					break;
				}
			}
			mSpinner.setSelection(index);
		}
		
		// 提交按钮
		mSubmit = (Button) findViewById(ResUtil.getId(mAppContext, "jmpay_button_pay", "id"));
		mSubmit.setEnabled(true);
		// 返回按钮
		mHeaderGoback = (ImageButton) findViewById(ResUtil.getId(mAppContext, "jmpay_header_goback", "id"));
	}
	
	private void initAction()
	{
		// 添加返回按钮事件
		mHeaderGoback.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				AlipayDialog.this.dismiss();
			}
		});
		
		// 支付按钮
		mSubmit.setOnClickListener(new View.OnClickListener()
		{
			
			@Override
			public void onClick(View v)
			{
				mSubmit.setEnabled(false);
				
				String selectMoney = (String) mSpinner.getSelectedItem();
				selectMoney = selectMoney.substring(0, selectMoney.length() - 1);
				int money0 = Integer.parseInt(selectMoney) * 100;
				
				// 若为调试模式，则使用传入金额
				if (PaymentActivity.isDebugMode) money0 = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount));
				final int money = money0;
				
				AlertDialog.Builder tip = new AlertDialog.Builder(mActivity);
				tip.setCancelable(false);
				tip.setMessage("处理中...");
				final AlertDialog ad = tip.create();
				ad.show();
				AndroidUtil.getThreadPool().execute(new Runnable()
				{
					@Override
					public void run()
					{
						if (AndroidUtil.isNetworkAvaliable(mAppContext))
						{
							try
							{
								HashMap<String, String> request = new HashMap<String, String>();
								request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
								request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
								request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
								request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
								request.put("plat_type", "alipay");
								request.put("plat_version", "2");
								request.put("money", money + ""); // 单位：分
								// request.put("money", "1"); // 单位：分
								
								String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
								String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
								
								Log.e("Ltsdk", "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
								Log.e("Ltsdk", "createLtOrder() ->> rdata:" + rval); // 请求返回值
								Log.e("Ltsdk", "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
								
								JSONObject json = new JSONObject(rval);
								JSONObject platData = json.getJSONObject("plat_data");
								
								// 根据订单信息开始进行支付
								String orderInfo = platData.getString("content");
								String sign = platData.getString("sign");
								String info = orderInfo + "&sign=" + "\"" + sign + "\"" + "&sign_type=\"RSA\"";
								
								Log.e("Ltsdk", "调用支付包接口支付参数: " + info);
								
								// 构造PayTask 对象
								PayTask alipay = new PayTask(mActivity);
								
								// 调用支付接口，获取支付结果
								String result = alipay.pay(info);
								
								Message msg = new Message();
								msg.what = SDK_PAY_FLAG;
								msg.obj = result;
								mHandler.sendMessage(msg);
							}
							catch (Exception e)
							{
								e.printStackTrace();
							}
						}
						else
						{
							AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
							mActivity.runOnUiThread(new Runnable()
							{
								@Override
								public void run()
								{
									mSubmit.setEnabled(true);
								}
							});
						}
						ad.dismiss();
					}
				});
			}
		});
	}
	
	private Handler mHandler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			switch (msg.what)
			{
				case SDK_PAY_FLAG:
				{
					PayResult payResult = new PayResult((String) msg.obj);
					// 支付宝返回此次支付结果及加签，建议对支付宝签名信息拿签约时支付宝提供的公钥做验签
					String resultStatus = payResult.getResultStatus();
					// 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
					if (TextUtils.equals(resultStatus, "9000"))
					{
						AndroidUtil.printToast(mAppContext, "提交成功，处理中");
					}
					AlipayDialog.this.dismiss();
					break;
				}
				default:
					break;
			}
		};
	};
	
}
