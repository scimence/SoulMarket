﻿
package com.joymeng.payment.core;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import com.fxlib.util.FJHttp;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.activity.PayPage;
import com.ltpay.function.Tools;


public class ShenzhoufuDialog extends Dialog
{
	private Activity mActivity;
	private Context mAppContext;
	private String mTitle;
	private String mCardType;
	private String mCardType2;
	private Spinner mSpinner;
	private EditText mCardNo;
	private EditText mCardPw;
	private Button mSubmit;
	private ImageButton mHeaderGoback;
	private HashMap<String, String> mPayInfo;
	
	public ShenzhoufuDialog(Activity activity, HashMap<String, String> payInfo, DialogCallback callback, String type)
	{
		super(activity, android.R.style.Theme_Light_NoTitleBar_Fullscreen);
		mActivity = activity;
		mAppContext = mActivity.getApplicationContext();
		mCardType = type;
		mPayInfo = payInfo;
		setContentView(ResUtil.getId(mAppContext, "jmpay_dialog_shenzhoufu", "layout"));
		
		initUI();
		initAction();
	}
	
	private void initUI()
	{
		String icon = null;
		if ("YD".equals(mCardType))
		{
			mTitle = ResUtil.getString(mAppContext, "jmpay_shenzhoufu_title_yd", "神州付（移动）");
			icon = "jmpay_icon_yidong";
			mCardType2 = "0";
		}
		else if ("LT".equals(mCardType))
		{
			mTitle = ResUtil.getString(mAppContext, "jmpay_shenzhoufu_title_lt", "神州付（联通）");
			icon = "jmpay_icon_liantong";
			mCardType2 = "1";
		}
		
		// 标题
		TextView textView = (TextView) findViewById(ResUtil.getId(mAppContext, "jmpay_shenzhoufu_title", "id"));
		textView.setText(mTitle);
		
		// ICON
		ImageView imageView = (ImageView) findViewById(ResUtil.getId(mAppContext, "jmpay_shenzhoufu_icon", "id"));
		imageView.setImageResource(ResUtil.getId(mAppContext, icon, "drawable"));
		
		// 金额列表
		mSpinner = (Spinner) findViewById(ResUtil.getId(mAppContext, "jmpay_choose_topup_spinner", "id"));
		int money = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount)) / 100;
		if (money > 0)
		{
			SpinnerAdapter adapter = mSpinner.getAdapter();
			int count = adapter.getCount(), index = count;
			String item;
			for (int i = 0; i < count; i++)
			{
				item = (String) adapter.getItem(i);
				item = item.substring(0, item.length() - 1);
				if (money <= Integer.parseInt(item))
				{
					index = i;
					break;
				}
			}
			mSpinner.setSelection(index);
		}
		
		// 卡号和卡密
		mCardNo = (EditText) findViewById(ResUtil.getId(mAppContext, "jmpay_shenzhoufu_cardno", "id"));
		mCardPw = (EditText) findViewById(ResUtil.getId(mAppContext, "jmpay_shenzhoufu_cardpw", "id"));
		// 提交按钮
		mSubmit = (Button) findViewById(ResUtil.getId(mAppContext, "jmpay_button_pay", "id"));
		mSubmit.setEnabled(true);
		// 返回按钮
		mHeaderGoback = (ImageButton) findViewById(ResUtil.getId(mAppContext, "jmpay_header_goback", "id"));
	}
	
	private void initAction()
	{
		// 添加返回按钮事件
		mHeaderGoback.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				ShenzhoufuDialog.this.dismiss();
				PayPage.PayFail(mActivity);
			}
		});
		
		// 支付按钮
		mSubmit.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				String selectMoney = (String) mSpinner.getSelectedItem();
				selectMoney = selectMoney.substring(0, selectMoney.length() - 1);
				final int money = Integer.parseInt(selectMoney) * 100;
				
				// int money0 = Integer.parseInt(selectMoney) * 100;
				// // 若为调试模式，则使用传入金额
				// if (PaymentActivity.isDebugMode) money0 = Integer.parseInt(mPayInfo.get(PaymentKey.MoneyAmount));
				// final int money = money0;
				
				final String no = mCardNo.getText().toString();
				final String pw = mCardPw.getText().toString();
				if ("".equals(no) || "".equals(pw))
				{
					AndroidUtil.printToast(mAppContext, "序列号或卡密不能为空");
					return;
				}
				
				mSubmit.setEnabled(false);
				
				final AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
				builder.setTitle("确认支付");
				builder.setMessage("您将使用" + mTitle + "充值卡充值" + selectMoney + "元");
				builder.setPositiveButton("确认", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int whichButton)
					{
						AlertDialog.Builder tip = new AlertDialog.Builder(mActivity);
						tip.setCancelable(false);
						tip.setMessage("处理中...");
						final AlertDialog ad = tip.create();
						ad.show();
						AndroidUtil.getThreadPool().execute(new Runnable()
						{
							
							@Override
							public void run()
							{
								if (AndroidUtil.isNetworkAvaliable(mAppContext))
								{
									
									Looper.prepare();
									try
									{
										HashMap<String, String> request = new HashMap<String, String>();
										PayPage.AppendPayParams(request);
										
										request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
										request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
										request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
										request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
										request.put("plat_type", "shenzhoufu");
										request.put("money", money + ""); // 单位：分
										request.put("card_no", no);
										request.put("card_pw", pw);
										request.put("card_type", mCardType2);
										
										// 新增参数用于消费记录信息
										request.put("couponId", mPayInfo.get(PaymentKey.CouponId)); 			// 优惠券id
										request.put("productId", mPayInfo.get(PaymentKey.ProductId)); 			// 商品id
										request.put("productMoney", mPayInfo.get(PaymentKey.ProductMoney)); 	// 商品金额
										request.put("productName", mPayInfo.get(PaymentKey.ProductName)); 		// 商品名称
										
										request.put("balance_consume", mPayInfo.get(PaymentKey.BalanceCounsume));	// 消费余额数
										request.put("password", mPayInfo.get(PaymentKey.UserPassword));			// 用户密码
										
										String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
										String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
										
										Log.d(Tools.TAG, "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
										Log.d(Tools.TAG, "createLtOrder() ->> rdata:" + rval); // 请求返回值
										Log.d(Tools.TAG, "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
										
										JSONObject json = new JSONObject(rval);
										PayPage.LtOrderId = json.optString("orderId", "");
										Log.d(Tools.TAG, "LtOrderId:" + PayPage.LtOrderId);
										
										if (mPayInfo.get(PaymentKey.MoneyAmount).equals("0"))	// 通过优惠券支付成功
										{
											String plat_data = json.optString("plat_data", "");
											if (!plat_data.equals(""))
											{
												PayPage.PaySuccess(mActivity);
											}
											else
											{
												String msg = json.optString("msg", "");			// 显示支付失败信息
												Tools.showToast(mActivity, msg);
												
												PayPage.PayFail(mActivity);
											}
											return;
										}
										
										String msg = json.optString("msg", "");
										AndroidUtil.printToast(mAppContext, msg);
										
										// {
										// "status": "104",
										// "msg": "序列号，密码简单验证失败"
										// }
										
										String status = json.optString("status", "");
										if (status.equals("104") || msg.contains("失败"))
											PayPage.PayFail(mActivity);		// 支付失败
										else PayPage.PaySuccess(mActivity);	// 支付成功
									}
									catch (Exception e)
									{
										e.printStackTrace();
										PayPage.PayFail(mActivity);
									}
								}
								else
								{
									AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
								}
								ad.dismiss();
								ShenzhoufuDialog.this.dismiss();
							}
						});
					}
				});
				builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int whichButton)
					{
						mSubmit.setEnabled(true);
						
						PayPage.PayFail(mActivity);
					}
				});
				builder.show();
			}
		});
	}
}
