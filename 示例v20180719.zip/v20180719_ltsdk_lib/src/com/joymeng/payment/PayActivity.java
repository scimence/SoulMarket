﻿
package com.joymeng.payment;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.joymeng.payment.channel.Alipay;
import com.joymeng.payment.channel.Iapppay;
import com.joymeng.payment.channel.Tenpay;
import com.joymeng.payment.channel.Unionpay;
import com.joymeng.payment.core.DialogCallback;
import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.core.ShenzhoufuDialog;
import com.joymeng.payment.core.YeepayDialog;
import com.joymeng.payment.util.AssetProperty;
import com.joymeng.payment.util.ResUtil;


/** PayActivity.java:乐盟支付Activity ----- 2017-11-3 下午4:00:29 wangzhongyuan */
public class PayActivity extends Activity
{
	
	public static boolean isDebugMode = false; // 记录当前是否为调试模式
	
	private Context mAppContext;
	private boolean isLandscape;
	private HashMap<String, String> mPayInfo;
	
	float MoneyAmount = 0; 					// 商品价格
	String productName = "商品XXX"; 			// 商品名称
	String payType = "";					// 当前选择的支付类型
	
	boolean ShowAlipay = true;
	boolean ShowWeChat = true;
	boolean ShowUnionpay = true;
	boolean ShowYidong = true;
	boolean ShowLiantong = true;
	boolean ShowYeepay = true;
	boolean ShowTenpay = true;
	
	// 获取支付类型配置信息
	private void getPayTypeConfig(Context context)
	{
		AssetProperty config = new AssetProperty(context, "payconfig.txt");
		
		ShowAlipay = config.getConfig("ShowAlipay", "true").equals("true");
		ShowWeChat = config.getConfig("ShowWeChat", "true").equals("true");
		ShowUnionpay = config.getConfig("ShowUnionpay", "true").equals("true");
		ShowYidong = config.getConfig("ShowYidong", "true").equals("true");
		ShowLiantong = config.getConfig("ShowLiantong", "true").equals("true");
		ShowYeepay = config.getConfig("ShowYeepay", "true").equals("true");
		ShowTenpay = config.getConfig("ShowTenpay", "fasle").equals("true");
	}
	
	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		mAppContext = getApplicationContext();
		isLandscape = isLandscape(mAppContext);
		
		getPayTypeConfig(this);
		
		Intent intent = getIntent();
		mPayInfo = (HashMap<String, String>) intent.getSerializableExtra("payInfo");
		
		setTheme(android.R.style.Theme_Light_NoTitleBar_Fullscreen);
		setRequestedOrientation(isLandscape ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		setContentView(ResUtil.getId(mAppContext, "jmpay_dialog_main", "layout"));
		
		setProductInfo(); // 设置商品信息
		
		initUI();
		initAction();
	}
	
	/** 获取activity对应的横竖屏属性 */
	public static boolean isLandscape(Context context)
	{
		if (context == null) { return true; }
		boolean landscape = (context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE);
		return landscape;
	}
	
	/** 设置商品信息 */
	private void setProductInfo()
	{
		TextView tv_Name = (TextView) findViewById(ResUtil.getId(mAppContext, "jmpay_pay_goods_tv", "id"));
		TextView tv_Price = (TextView) findViewById(ResUtil.getId(mAppContext, "jmpay_pay_price_tv", "id"));
		
		if (mPayInfo.containsKey(PaymentKey.ProductName)) productName = mPayInfo.get(PaymentKey.ProductName);
		
		if (mPayInfo.containsKey(PaymentKey.MoneyAmount)) MoneyAmount = Float.parseFloat(mPayInfo.get(PaymentKey.MoneyAmount)) / 100;
		DecimalFormat fnum = new DecimalFormat("##0.00");
		String moneyStr = fnum.format(MoneyAmount) + "\t元";
		
		tv_Name.setText(productName);
		tv_Price.setText(moneyStr);
	}
	
	private void initUI()
	{
		// 添加支付平台选择
		int itemLayout = ResUtil.getId(mAppContext, "jmpay_list_dialog_item", "layout");
		int itemImg = ResUtil.getId(mAppContext, "jmpay_list_dialog_item_img", "id");
		int itemTitle = ResUtil.getId(mAppContext, "jmpay_list_dialog_item_title", "id");
		
		ListAdapter adapter = new SimpleAdapter(mAppContext, getData(), itemLayout, new String[] { "img", "title" }, new int[] { itemImg, itemTitle });
		ListView list = (ListView) findViewById(ResUtil.getId(mAppContext, "jmpay_list_dialog_item", "id"));
		list.setAdapter(adapter);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				
				payType = "";
				int index = -1;
				
				if (ShowAlipay) index++;
				if (position == index)
				{
					Alipay.Pay(PayActivity.this, mPayInfo);
					// platAlipay();
					return;
				}
				
				if (ShowWeChat) index++;
				if (position == index)
				{
					// WeChat.Pay(PayActivity.this, mPayInfo);
					// platWeChatpay();
					payType = "WeChat";
					// JFTpay.Pay(PayActivity.this, mPayInfo);
					
					Iapppay.Pay(PayActivity.this, mPayInfo);
					return;
				}
				
				if (ShowUnionpay) index++;
				if (position == index)
				{
					Unionpay.Pay(PayActivity.this, mPayInfo);
					// platUnionpay();
					return;
				}
				
				if (ShowTenpay) index++;
				if (position == index)
				{
					Tenpay.Pay(PayActivity.this, mPayInfo);
					// platTenpay();
					return;
				}
				
				if (ShowYidong) index++;
				if (position == index)
				{
					platShenzhoufu("YD");
					return;
				}
				
				if (ShowLiantong) index++;
				if (position == index)
				{
					platShenzhoufu("LT");
					return;
				}
				
				if (ShowYeepay) index++;
				if (position == index)
				{
					platGamecard();
					return;
				}
				
			}
		});
	}
	
	private List<Map<String, Object>> getData()
	{
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> map;
		
		if (ShowAlipay)
		{
			// 支付宝
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_alipay", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_alipay_title", "Empty Title"));
			list.add(map);
		}
		
		if (ShowWeChat)
		{
			// 微信支付
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_wechat", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_wechat_title", "Empty Title"));
			list.add(map);
		}
		
		if (ShowUnionpay)
		{
			// 银联
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_unionpay", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_unionpay_title", "Empty Title"));
			list.add(map);
		}
		
		if (ShowTenpay)
		{
			// 财付通
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_tenpay", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_tenpay_title", "Empty Title"));
			list.add(map);
		}
		
		if (ShowYidong)
		{
			// 移动卡
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_yidong", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_shenzhoufu_title_yd", "Empty Title"));
			list.add(map);
		}
		
		if (ShowLiantong)
		{
			// 联通卡
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_liantong", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_shenzhoufu_title_lt", "Empty Title"));
			list.add(map);
		}
		
		if (ShowYeepay)
		{
			// 易宝支付
			map = new HashMap<String, Object>();
			map.put("img", ResUtil.getId(mAppContext, "jmpay_icon_yeepay", "drawable"));
			map.put("title", ResUtil.getString(mAppContext, "jmpay_yeepay_title", "Empty Title"));
			list.add(map);
		}
		
		return list;
	}
	
	private void initAction()
	{
		// 添加返回按钮事件
		ImageButton headerGoback = (ImageButton) findViewById(ResUtil.getId(mAppContext, "jmpay_header_goback", "id"));
		headerGoback.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				PayActivity.this.finish();
			}
		});
	}
	
	//
	// /** 支付宝支付 */
	// private void platAlipay()
	// {
	// Dialog dialog = new AlipayDialog(this, mPayInfo, new DialogCallback()
	// {
	// @Override
	// public void onCallback(String type, Object data)
	// {}
	// });
	// dialog.show();
	// }
	//
	// /** 微信支付 */
	// private void platWeChatpay()
	// {
	// Dialog dialog = new WeChatDialog(this, mPayInfo, new DialogCallback()
	// {
	// @Override
	// public void onCallback(String type, Object data)
	// {}
	// });
	// dialog.show();
	// }
	//
	// private void platTenpay()
	// {
	// Dialog dialog = new TenpayDialog(this, mPayInfo, new DialogCallback()
	// {
	// @Override
	// public void onCallback(String type, Object data)
	// {}
	// });
	// dialog.show();
	// }
	//
	// private void platUnionpay()
	// {
	// Dialog dialog = new UnionpayDialog(this, mPayInfo, new DialogCallback()
	// {
	// @Override
	// public void onCallback(String type, Object data)
	// {}
	// });
	// dialog.show();
	// }
	
	private void platShenzhoufu(String type)
	{
		Dialog dialog = new ShenzhoufuDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		}, type);
		dialog.show();
	}
	
	private void platGamecard()
	{
		Dialog dialog = new YeepayDialog(this, mPayInfo, new DialogCallback()
		{
			@Override
			public void onCallback(String type, Object data)
			{}
		});
		dialog.show();
	}
	
	@Override
	protected void onResume()
	{
		super.onResume();
		// if (payType.equals("WeChat"))
		// {
		// JFTpay.onResume(PayActivity.this);
		// }
	}
	
	protected void onDestroy()
	{
		// if (payType.equals("WeChat"))
		// {
		// JFTpay.onDestroy();
		// Log.i("PayActivity", "onDestroy()");
		// }
		super.onDestroy();
	}
}
