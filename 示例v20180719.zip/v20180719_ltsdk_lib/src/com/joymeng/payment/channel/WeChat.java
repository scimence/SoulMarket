﻿
package com.joymeng.payment.channel;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.tencent.mm.opensdk.modelpay.PayReq;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;


/** WeChat.java:微信支付 ----- 2017-11-3 下午4:29:23 wangzhongyuan */
public class WeChat
{
	public static void Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		AndroidUtil.getThreadPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				if (AndroidUtil.isNetworkAvaliable(mActivity.getApplicationContext()))
				{
					try
					{
						// 从计费服务器获取微信支付订单信息
						
						// HashMap<String, String> request = new
						// HashMap<String, String>();
						// request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
						// request.put("appId",
						// mPayInfo.get(PaymentKey.LtAppId));
						// request.put("instantid",
						// mPayInfo.get(PaymentKey.LtInstantId));
						// request.put("reserve",
						// mPayInfo.get(PaymentKey.LtReserve));
						// request.put("plat_type", "weichat");
						// request.put("plat_version", "2");
						// request.put("money", money + ""); // 单位：分
						// // request.put("money", "1"); // 单位：分
						//
						// String PRIV_ORDER_URL =
						// mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
						// String rval =
						// HttpUtil.request(PRIV_ORDER_URL, request,
						// "post");
						//
						// Log.e("Ltsdk", "createLtOrder() ->> request:"
						// + request.toString()); // 创建订单请求信息
						// Log.e("Ltsdk", "createLtOrder() ->> rdata:" +
						// rval); // 请求返回值
						// Log.e("Ltsdk", "创建订单请求 ->> " + PRIV_ORDER_URL
						// + "?" + FJHttp.praseMap(request,
						// FJHttp.DEFAULT_CHARSET)); // 请求参数信息
						//
						// JSONObject json = new JSONObject(rval);
						// JSONObject platData =
						// json.getJSONObject("plat_data");
						//
						// // 根据订单信息开始进行支付
						// String orderInfo =
						// platData.getString("content");
						// String sign = platData.getString("sign");
						// String info = orderInfo + "&sign=" + "\"" +
						// sign + "\"" + "&sign_type=\"RSA\"";
						// Log.e("Ltsdk", "调用支付包接口支付参数: " + info);
						
						String url = "http://wxpay.wxutil.com/pub_v2/app/app_pay.php";
						
						String data = HttpUtil.request(url, "", "post");
						JSONObject json = new JSONObject(data);
						Log.d("Ltsdk", "请求地址 ->> " + url); // 请求参数信息
						Log.d("Ltsdk", "获取微信支付订单信息 ->> " + data); // 请求参数信息
						
						PayReq req = new PayReq();
						// req.appId = "wxf8b4f85f3a794e77"; // 测试用appId
						req.appId = json.getString("appid");
						req.partnerId = json.getString("partnerid");
						req.prepayId = json.getString("prepayid");
						req.nonceStr = json.getString("noncestr");
						req.timeStamp = json.getString("timestamp");
						req.packageValue = json.getString("package");
						req.sign = json.getString("sign");
						req.extData = "app data"; // optional
						
						WeChatPay(mActivity, req);
						
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
				}
			}
		});
	}
	
	private static IWXAPI api = null;
	private static void WeChatPay(final Activity mActivity, final PayReq req)
	{
		mActivity.runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				if (api == null) api = WXAPIFactory.createWXAPI(mActivity, "wxb4ba3c02aa476ea1"); // 微信应用接口
				// msgApi.registerApp("wxd930ea5d5a258f4f"); //
				// 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
				
				Toast.makeText(mActivity, "正常调起支付", Toast.LENGTH_SHORT).show();
				api.sendReq(req);
			}
		});
	}
	
}
