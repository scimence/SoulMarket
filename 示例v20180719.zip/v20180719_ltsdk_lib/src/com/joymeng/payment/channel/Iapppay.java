﻿
package com.joymeng.payment.channel;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.util.Log;

import com.fxlib.util.FJHttp;
import com.iapppay.interfaces.callback.IPayResultCallback;
import com.iapppay.sdk.main.IAppPay;
import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.ltpay.LtSDK;
import com.ltpay.activity.PayPage;
import com.ltpay.function.Tools;


/** Iapppay.java:爱贝支付 ----- 2018-4-12 上午11:06:51 wangzhongyuan */
public class Iapppay
{
	/** appid -- 应用appid privateKey -- 应用私钥 publicKey -- 平台公钥(platKey) */
	
	/** 线上环境 */
	// public static final String appid = "3001259821";
	// public static final String privateKey =
	// "MIICXgIBAAKBgQCOqWFTCsTglunf036QBof9EnKo4g6EaZ+IYa+u3jMf3p4YeHmOZjvE8jTxJ+tLvVfroRJNIRQX81uJKhTbtfkBxQjOiC8y9pyfQXz02WTl6DFIM9Kgjjx51bGnEKP8ploW2ieqKCDBzYCwkVEQfr7ayOPx0WWD0Cw3J6nb3EDUKQIDAQABAoGBAI440BzQdJuN99Q67Ua6LCIgnQw+aMia3/8/m7xSKleQQL4WhOBwjQ93g04TROC5/4eZiTw5SOXjp5Kj0C2FSZp5lmIggAg/KRgFhcdQ28jxmGzBD9+2cshTucYoa7YxtaeuljODT21nh7m5XF9HEngU7Ty8nnW8Byumpxa5bYCBAkEA1d3sSsjR7Y5wV6a9VgZsOKvExoCeUSjSaC6/KAZmJHExZB2Mb4yh+3LSV4Pi9xnz4umk/JFWRMJ7oQs7JsOVUQJBAKrEUf9Dbtm1qzvUy474e83N6+3iUsX8p5giRSahaOSsl7jCnnwqwF8nhh2I40XliH106nC4YV2c3f7cS8BEe1kCQQCY319OPapBgrWvEdL5MPIeuDmaIsoH/YQZUID3nUtZ9Ud25uBBxGbtFDBiujV8qCJ7KsPyffkKgXJZtWt81AVhAkEAnoiHvz0xKfiYMYGKQP66oQOtJjlYsumuBXS7UfPDV5hLeoFjdM6TrUMaJU0yAW/oWOAzzdW+vpOlHLgTszlgcQJAPSHsnZBSlKPJUHt3D7tGedgi6f8ayrbqxlsbvMQEFVzgUr0x1OV4ni+5oZOsP6jfoRLeWbiS8GMZlp2t326fgA==";
	// public static final String
	// publicKey="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDPJmrO2n5qNNfiXM1hAUJlcOL95J2MZ8FJI9HYmD+GuFn9K75KFNEjdc3ZaRRmjSW6GA1ZLJ2Ddgf8XWjXZ5g1sO5y6zQWrq9OZpk6plKjAKF8LEfJyS7zClOG/ziUNj164GShMWOTmJ0xdLX6wTG/QYQ4DLu43gi1Y+RZbwkSGQIDAQAB";
	
	public static final String appid = "3018962574";
	// public static final String privateKey =
	// "MIICXQIBAAKBgQCuvcabgHTLfLl4RQluMiSy3HS1al1KG7i3fPCsx+IWPlexCCV0im9h8W7Q7jYNeYHewQETmRhkYQW2F3jIkxeEkgUdqWPNpDZcPPPiVpMdohufyVk0ZfglS+kw2xcG7S8gluoFlK3ZWgc9j2hCflOLufItuoRd+KdfoydblBFytwIDAQABAoGAfuDpLsvtAjvD5+Io4Myj/QM58ugSaNcMHp8nmi1gqkoGHlMN7zr9eR53Gll9AfeyJu35PCOzpF8WaItOdkTnk3BvyZvqyHOh9H49Davbc3ApN1w7qDhOkhkvtemUxLNwEAYKODuAb1IDQhT+GFyP1ISilJ+NCOsmZ/XMtag9FuECQQD/Cu1TNfrwQV/eJB/+Rp0CRi9U5dlmJa49bzJ2D0Fuxy85CGsS3DQM852mUWAIj1fXANmGrXnTgzWBfWBdbJN/AkEAr2WvuDTWFEYGg/dohR3irW4hI5k3MSZogtSX4dun9/vgraEOWFOrYLWmpQNnFqQUceBVPBVAIzVMZjg+8zBcyQJBAOm3gL5lVD1BG3I9Vpg064L/ADbjnzKtSxv/P5XS6xpyK8MvBLg21Pgdc5XLMp8FhPCBVdXGOULsFWdBlsJmUk8CQBKmtIXZEH69Z4n28CVfpTAeCuYXL9hJJknrQ29gBT+IiD7OZpEb7JhvGJZpgzfUINxvJ4EpHVXhIAuqpX8EwIkCQQDKojcPBzg+4YjYwb90OOhiylgncsSihQRJeeGqDyT+l7Ybtiz7paYVg34LUZ7gU2/1joa5zw3QqI3sViTDlyDI";
	public static final String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCyfUcTRwO+1NamzQB6TW2qs+j8EFP5O28EQOwJ2+6ubz5dv8DJGIja6TKSQQ70UCo8J2k4AUPeozLnidI5Fej6VIQBN1NCrzG+mXJcImcZtHnISUOQc0/XaFQLZxDuml1UzWEew3CXaIx4a5dwyrPo5qFTRfLhzRWuz4b/1jSEcwIDAQAB";
	
	public static void Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		AndroidUtil.getThreadPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				if (AndroidUtil.isNetworkAvaliable(mActivity.getApplicationContext()))
				{
					try
					{
						String LtAppId = mPayInfo.get(PaymentKey.LtAppId);
						
						HashMap<String, String> request = new HashMap<String, String>();
						PayPage.AppendPayParams(request);
						
						request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
						request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
						request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
						request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
						request.put("plat_type", "aibei");
						request.put("money", mPayInfo.get(PaymentKey.MoneyAmount)); // 单位：分
						request.put("product_name", mPayInfo.get(PaymentKey.ProductName));
						request.put("product_descript", mPayInfo.get(PaymentKey.ProductDescript));
						

						// 新增参数用于消费记录信息
						request.put("couponId", mPayInfo.get(PaymentKey.CouponId)); 			// 优惠券id
						request.put("productId", mPayInfo.get(PaymentKey.ProductId)); 			// 商品id
						request.put("productMoney", mPayInfo.get(PaymentKey.ProductMoney)); 	// 商品金额
						request.put("productName", mPayInfo.get(PaymentKey.ProductName)); 		// 商品名称
						
						request.put("balance_consume", mPayInfo.get(PaymentKey.BalanceCounsume));	// 消费余额数
						request.put("password", mPayInfo.get(PaymentKey.UserPassword));			// 用户密码
						
						JSONObject payInfo = new JSONObject();
						payInfo.put("appid", appid);
						payInfo.put("ltPid", 1);
						payInfo.put("currency", "RMB");
						payInfo.put("appuserid", mPayInfo.get(PaymentKey.LtJoyId));
						payInfo.put("waresid", ""); 	// 服务器判断
						payInfo.put("cporderid", "");	// 服务器判断
						payInfo.put("notifyurl", "");	// 服务器判断
						
						request.put("pay_info", payInfo.toString());
						
						String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
						String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
						
						Log.d(Tools.TAG, "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
						Log.d(Tools.TAG, "createLtOrder() ->> rdata:" + rval); // 请求返回值
						Log.d(Tools.TAG, "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
						
						
						JSONObject json = new JSONObject(rval);
						PayPage.LtOrderId = json.optString("orderId", "");
						Log.d(Tools.TAG, "LtOrderId:" + PayPage.LtOrderId);
						
						if (mPayInfo.get(PaymentKey.MoneyAmount).equals("0"))	// 通过优惠券支付成功
						{
							String plat_data = json.optString("plat_data", "");
							if (!plat_data.equals(""))
							{
								PayPage.PaySuccess(mActivity);
							}
							else
							{
								String msg = json.optString("msg", "");			// 显示支付失败信息
								Tools.showToast(mActivity, msg);
								
								PayPage.PayFail(mActivity);
							}
							return;
						}
						
						JSONObject platData = json.getJSONObject("plat_data");
						// 根据订单信息开始进行支付
						if (platData.has("transid"))
						{
							String mTransid = platData.optString("transid", ""); // {"errmsg":"请求参数错误","code":1002}
							IappPay(mActivity, mTransid, LtAppId);
						}
						else
						{
							AndroidUtil.printToast(mActivity, platData.getString("msg"));
						}
						
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
				}
			}
		});
	}
	
	public static boolean isIappPayInit = false;
	
	// 调用爱贝支付
	private static void IappPay(final Activity mActivity, final String mTransid, final String acid)
	{
		mActivity.runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				// 爱贝计费初始化
				if (!isIappPayInit)
				{
					// String acid = "";
					boolean isLandscape = Tools.isLandscape(mActivity.getApplicationContext());	// 是否为横屏
					int orgntation = isLandscape ? IAppPay.LANDSCAPE : IAppPay.PORTRAIT;
					IAppPay.init(mActivity, orgntation, appid, acid); // 需要渠道分包功能，请传入对应渠道标识ACID, 可以为空
					isIappPayInit = true;
				}
				
				// 支付回调
				IPayResultCallback iPayResultCallback = new IPayResultCallback()
				{
					@Override
					public void onPayResult(int resultCode, String signValue, String resultInfo)
					{
						Log.d("IappPay", "requestCode:" + resultCode + ",signvalue:" + signValue + ",resultInfo:" + resultInfo);
						switch (resultCode)
						{
							case IAppPay.PAY_SUCCESS:
								AndroidUtil.printToast(mActivity, "支付成功，处理中");
								
								PayPage.PaySuccess(mActivity);
								
								// // 调用 IAppPayOrderUtils 的验签方法进行支付结果验证
								// // 请尽量采用服务端验签方式 ，以下验签方法不建议
								// boolean payState = IAppPayOrderUtils.checkPayResult(signValue, PayConfig.publicKey);
								// if (payState)
								// {
								// AndroidUtil.printToast(context, "提交成功，处理中");
								//
								// Toast.makeText(MainDemoActivity.this, "支付成功", Toast.LENGTH_LONG).show();
								// }
								// else
								// {
								// Toast.makeText(MainDemoActivity.this, "支付成功但验签失败", Toast.LENGTH_LONG).show();
								// }
								break;
								
							default:
								AndroidUtil.printToast(mActivity, "支付失败 " + resultInfo);
								
								PayPage.PayFail(mActivity);
								break;
						}
					}
				};
				
				// 调用爱贝支付
				String param = "transid=" + mTransid + "&appid=" + appid;
				// String param = getTransdata("userid001", "cpprivateinfo123456", 1, 0.01, cporderid);//
				// transdata=%7B%22cporderid%22%3A%221523501129149%22%2C%22price%22%3A0.01%2C%22appuserid%22%3A%22userid001%22%2C%22waresname%22%3A%22%E8%87%AA%E5%AE%9A%E4%B9%89%E5%90%8D%E7%A7%B0%22%2C%22waresid%22%3A1%2C%22appid%22%3A%223018962574%22%2C%22cpprivateinfo%22%3A%22cpprivateinfo123456%22%2C%22currency%22%3A%22RMB%22%7D&sign=AG671nbrYCAC4HFISBbVP%2FuUJdNq4DYLqT3p%2F%2FfT59sWBLQUrdIvW3QE4zxCgaQjb5FCMEJbAkBBcx3zV8dQPWTewAOZ0SN418m9p7T1mzQ3fYQJLYxYSUbhkJ3W71JSjBo2nbd0EAAIoqmFLoN0aw1gta%2FsywkwYxQ4VPNv%2B1c%3D&signtype=RSA
				IAppPay.startPay(mActivity, param, iPayResultCallback);
			}
		});
	}
	
}
