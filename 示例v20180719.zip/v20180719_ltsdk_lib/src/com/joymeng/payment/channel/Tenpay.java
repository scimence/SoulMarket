﻿
package com.joymeng.payment.channel;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.fxlib.util.FAApk;
import com.fxlib.util.FJHttp;
import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.tenpay.android.service.TenpayServiceHelper;


/** Tenpay.java:财付通支付 ----- 2017-11-3 下午4:43:25 wangzhongyuan */
public class Tenpay
{
	
	protected static final int MSG_PAY_RESULT = 100;
	
	public static void Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		final TenpayServiceHelper tenpayHelper = new TenpayServiceHelper(mActivity);
		// 打开log 方便debug, 发布时不需要打开。
		tenpayHelper.setLogEnabled(false);
		// 判断并安装财付通安全支付服务应用
		if (!tenpayHelper.isTenpayServiceInstalled(9))
		{
			tenpayHelper.installTenpayService();
			return;
		}
		
		AndroidUtil.getThreadPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				if (AndroidUtil.isNetworkAvaliable(mActivity.getApplicationContext()))
				{
					try
					{
						HashMap<String, String> request = new HashMap<String, String>();
						request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
						request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
						request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
						request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
						request.put("plat_type", "tenpay");
						request.put("money", mPayInfo.get(PaymentKey.MoneyAmount)); // 单位：分
						// request.put("money", "1"); // 单位：分
						
						request.put("product_name", mPayInfo.get(PaymentKey.ProductName));
						request.put("product_descript", mPayInfo.get(PaymentKey.ProductDescript));
						// {"gold_name":"\u5143\u5b9d","gold_rate":"10","orderId":"12951","plat_data":{"status":1,"token_id":"bb184649330e9ad44e57d1d72df6f1cc"}}
						
						String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
						String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
						
						Log.e("Ltsdk", "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
						Log.e("Ltsdk", "createLtOrder() ->> rdata:" + rval); // 请求返回值
						Log.e("Ltsdk", "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
						
						JSONObject json = new JSONObject(rval);
						JSONObject platData = json.getJSONObject("plat_data");
						// 根据订单信息开始进行支付
						if (platData.getInt("status") == 1)
						{
							String tokenId = platData.getString("token_id");
							String bargainorId = platData.getString("bargainor_id");
							
							// 构造支付参数
							final HashMap<String, String> payInfo = new HashMap<String, String>();
							payInfo.put("token_id", tokenId); // 财付通订单号token_id
							payInfo.put("bargainor_id", bargainorId); // 财付通合作商户ID
							

							FAApk.getMainHandler().post(new Runnable()
							{
								@Override
								public void run()
								{
									// 去支付
									tenpayHelper.pay(payInfo, getHandler(mActivity), MSG_PAY_RESULT);
									
								}
							});
						}
						
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
				}
			}
		});
	}
	
	// 接收支付返回值的Handler
	private static Handler getHandler(final Context context)
	{
		Handler mHandler = new Handler()
		{
			public void handleMessage(Message msg)
			{
				if (msg.what == MSG_PAY_RESULT)
				{
					try
					{
						JSONObject json = new JSONObject((String) msg.obj);
						if ("0".equals(json.getString("statusCode")))
						{
							AndroidUtil.printToast(context, "提交成功，处理中");
						}
						else
						{
							AndroidUtil.printToast(context, "财富通，支付失败！");
						}
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			}
		};
		
		return mHandler;
	}
	
}
