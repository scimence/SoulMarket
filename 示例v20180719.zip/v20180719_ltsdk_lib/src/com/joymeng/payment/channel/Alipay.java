﻿
package com.joymeng.payment.channel;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.alipay.sdk.app.PayTask;
import com.fxlib.util.FAApk;
import com.fxlib.util.FJHttp;
import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.joymeng.payment.util.alipay.PayResult;
import com.ltpay.LtSDK;
import com.ltpay.activity.PayPage;
import com.ltpay.function.Tools;


/** Pay_Alipay.java:支付宝支付 ----- 2017-11-3 下午3:49:23 wangzhongyuan */
public class Alipay
{
	private static final int SDK_PAY_FLAG = 1;
	
	public static void Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		AndroidUtil.getThreadPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				if (AndroidUtil.isNetworkAvaliable(mActivity.getApplicationContext()))
				{
					try
					{
						HashMap<String, String> request = new HashMap<String, String>();
						PayPage.AppendPayParams(request);
						
						request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
						request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
						request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
						request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
						request.put("plat_type", "alipay");
						request.put("plat_version", "2");
						request.put("money", mPayInfo.get(PaymentKey.MoneyAmount)); // 单位：分
						
						// 新增参数用于消费记录信息
						request.put("couponId", mPayInfo.get(PaymentKey.CouponId)); 			// 优惠券id
						request.put("productId", mPayInfo.get(PaymentKey.ProductId)); 			// 商品id
						request.put("productMoney", mPayInfo.get(PaymentKey.ProductMoney)); 	// 商品金额
						request.put("productName", mPayInfo.get(PaymentKey.ProductName)); 		// 商品名称
						
						request.put("balance_consume", mPayInfo.get(PaymentKey.BalanceCounsume));	// 消费余额数
						request.put("password", mPayInfo.get(PaymentKey.UserPassword));			// 用户密码
						
						// request.put("money", "1"); // 单位：分
						
						String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
						String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
						
						Log.d(Tools.TAG, "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
						Log.d(Tools.TAG, "createLtOrder() ->> rdata:" + rval); // 请求返回值
						Log.d(Tools.TAG, "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
						
						JSONObject json = new JSONObject(rval);
						PayPage.LtOrderId = json.optString("orderId", "");
						Log.d(Tools.TAG, "LtOrderId:" + PayPage.LtOrderId);
						
						if (mPayInfo.get(PaymentKey.MoneyAmount).equals("0"))	// 通过优惠券支付成功
						{
							String plat_data = json.optString("plat_data", "");
							if (!plat_data.equals(""))
							{
								PayPage.PaySuccess(mActivity);
							}
							else
							{
								String msg = json.optString("msg", "");			// 显示支付失败信息
								Tools.showToast(mActivity, msg);
								
								PayPage.PayFail(mActivity);
							}
							return;
						}
						
						JSONObject platData = json.getJSONObject("plat_data");
						
						// 根据订单信息开始进行支付
						String orderInfo = platData.getString("content");
						String sign = platData.getString("sign");
						String info = orderInfo + "&sign=" + "\"" + sign + "\"" + "&sign_type=\"RSA\"";
						
						Log.d(Tools.TAG, "调用支付包接口支付参数: " + info);
						
						// 构造PayTask 对象
						PayTask alipay = new PayTask(mActivity);
						
						// 调用支付接口，获取支付结果
						final String result = alipay.pay(info);
						
						FAApk.getMainHandler().post(new Runnable()
						{
							@Override
							public void run()
							{
								Message msg = new Message();
								msg.what = SDK_PAY_FLAG;
								msg.obj = result;
								// mHandler.sendMessage(msg);
								getHandler(mActivity).sendMessage(msg);
							}
						});
						
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
				}
			}
		});
	}
	
	private static Handler getHandler(final Context context)
	{
		
		Handler mHandler = new Handler()
		{
			public void handleMessage(Message msg)
			{
				if (msg.what == SDK_PAY_FLAG)
				{
					PayResult payResult = new PayResult((String) msg.obj);
					// 支付宝返回此次支付结果及加签，建议对支付宝签名信息拿签约时支付宝提供的公钥做验签
					
					String resultStatus = payResult.getResultStatus();
					// 判断resultStatus 为“9000”则代表支付成功，具体状态码代表含义可参考接口文档
					if (TextUtils.equals(resultStatus, "9000"))
					{
						AndroidUtil.printToast(context, "提交成功，处理中");
						
						PayPage.PaySuccess(context);
					}
					else
					{
						AndroidUtil.printToast(context, "支付宝，支付失败");
						PayPage.PayFail(context);
					}
				}
			}
		};
		
		return mHandler;
	}
}
