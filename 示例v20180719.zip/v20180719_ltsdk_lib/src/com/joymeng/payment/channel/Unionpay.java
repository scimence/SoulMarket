﻿
package com.joymeng.payment.channel;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.util.Log;

import com.fxlib.util.FJHttp;
import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.HttpUtil;
import com.ltpay.activity.PayPage;
import com.ltpay.function.Tools;
import com.unionpay.UPPayAssistEx;
import com.unionpay.uppay.PayActivity;


/** Unionpay.java:银联支付 ----- 2017-11-3 下午4:22:07 wangzhongyuan */
public class Unionpay
{
	public static void Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		AndroidUtil.getThreadPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				if (AndroidUtil.isNetworkAvaliable(mActivity.getApplicationContext()))
				{
					try
					{
						HashMap<String, String> request = new HashMap<String, String>();
						PayPage.AppendPayParams(request);
						
						request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
						request.put("appId", mPayInfo.get(PaymentKey.LtAppId));
						request.put("instantid", mPayInfo.get(PaymentKey.LtInstantId));
						request.put("reserve", mPayInfo.get(PaymentKey.LtReserve));
						request.put("plat_type", "unionpay");
						request.put("money", mPayInfo.get(PaymentKey.MoneyAmount)); // 单位：分
						request.put("product_name", mPayInfo.get(PaymentKey.ProductName));
						request.put("product_descript", mPayInfo.get(PaymentKey.ProductDescript));
						

						// 新增参数用于消费记录信息
						request.put("couponId", mPayInfo.get(PaymentKey.CouponId)); 			// 优惠券id
						request.put("productId", mPayInfo.get(PaymentKey.ProductId)); 			// 商品id
						request.put("productMoney", mPayInfo.get(PaymentKey.ProductMoney)); 	// 商品金额
						request.put("productName", mPayInfo.get(PaymentKey.ProductName)); 		// 商品名称

						request.put("balance_consume", mPayInfo.get(PaymentKey.BalanceCounsume));	// 消费余额数
						request.put("password", mPayInfo.get(PaymentKey.UserPassword));			// 用户密码
						
						String PRIV_ORDER_URL = mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
						String rval = HttpUtil.request(PRIV_ORDER_URL, request, "post");
						
						Log.d(Tools.TAG, "createLtOrder() ->> request:" + request.toString()); // 创建订单请求信息
						Log.d(Tools.TAG, "createLtOrder() ->> rdata:" + rval); // 请求返回值
						Log.d(Tools.TAG, "创建订单请求 ->> " + PRIV_ORDER_URL + "?" + FJHttp.praseMap(request, FJHttp.DEFAULT_CHARSET)); // 请求参数信息
						
						JSONObject json = new JSONObject(rval);
						PayPage.LtOrderId = json.optString("orderId", "");
						Log.d(Tools.TAG, "LtOrderId:" + PayPage.LtOrderId);
						
						if (mPayInfo.get(PaymentKey.MoneyAmount).equals("0"))	// 通过优惠券支付成功
						{
							String plat_data = json.optString("plat_data", "");
							if (!plat_data.equals(""))
							{
								PayPage.PaySuccess(mActivity);
							}
							else
							{
								String msg = json.optString("msg", "");			// 显示支付失败信息
								Tools.showToast(mActivity, msg);
								
								PayPage.PayFail(mActivity);
							}
							return;
						}
						
						JSONObject platData = json.getJSONObject("plat_data");
						// 根据订单信息开始进行支付
						if (platData.getInt("status") == 1)
						{
							String tn = platData.getString("tn");
							UPPayAssistEx.startPayByJAR(mActivity, PayActivity.class, null, null, tn, "00");
						}
						else
						{
							AndroidUtil.printToast(mActivity, platData.getString("msg"));
						}
						
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
				}
			}
		});
	}
}
