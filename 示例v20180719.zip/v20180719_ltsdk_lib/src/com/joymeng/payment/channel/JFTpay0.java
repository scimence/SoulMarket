﻿
package com.joymeng.payment.channel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import sdk.pay.PayUtil;
import sdk.pay.listener.PayGetPayStatusListener;
import sdk.pay.listener.PayUtilCallBack;
import sdk.pay.model.TokenParam;
import sdk.pay.utils.PayMD5Util;
import android.app.Activity;
import android.util.Log;

import com.fxlib.util.FAApk;
import com.joymeng.payment.util.AndroidUtil;


/** JFTpay.java: 竣付通支付2.4.0.1 ----- 2017-11-17 下午3:26:03 wangzhongyuan */
public class JFTpay0
{
	public static final String SYSTEM_NAME = "jft";
	public static final String CODE = "10208331";
	public static final String APPID = "20161111102907658374";
	public static final String COM_KEY = "40F4A509B7459D667B68C9A51A4E14DA";
	public static final String KEY = "1b4f2dd8a284638cf325122bcc69af31";
	public static final String VECTOR = "2995d86414449a62";
	
	public static final String RETURN_URL = "http://shangjia.jtpay.com/Form/TestReturn";
	public static final String NOTICE_URL = "http://shangjia.jtpay.com/Form/TestNotice";
	
	private static PayUtil mPayUtil = null;
	
	public static void Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		AndroidUtil.getThreadPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				if (AndroidUtil.isNetworkAvaliable(mActivity.getApplicationContext()))
				{
					try
					{
						// 从计费服务器获取微信支付订单信息
						
						// HashMap<String, String> request = new
						// HashMap<String, String>();
						// request.put("userid", mPayInfo.get(PaymentKey.LtJoyId));
						// request.put("appId",
						// mPayInfo.get(PaymentKey.LtAppId));
						// request.put("instantid",
						// mPayInfo.get(PaymentKey.LtInstantId));
						// request.put("reserve",
						// mPayInfo.get(PaymentKey.LtReserve));
						// request.put("plat_type", "weichat");
						// request.put("plat_version", "2");
						// request.put("money", money + ""); // 单位：分
						// // request.put("money", "1"); // 单位：分
						//
						// String PRIV_ORDER_URL =
						// mPayInfo.get(PaymentKey.PRIV_ORDER_URL);
						// String rval =
						// HttpUtil.request(PRIV_ORDER_URL, request,
						// "post");
						//
						// Log.d(Tools.TAG, "createLtOrder() ->> request:"
						// + request.toString()); // 创建订单请求信息
						// Log.d(Tools.TAG, "createLtOrder() ->> rdata:" +
						// rval); // 请求返回值
						// Log.d(Tools.TAG, "创建订单请求 ->> " + PRIV_ORDER_URL
						// + "?" + FJHttp.praseMap(request,
						// FJHttp.DEFAULT_CHARSET)); // 请求参数信息
						//
						// JSONObject json = new JSONObject(rval);
						// JSONObject platData =
						// json.getJSONObject("plat_data");
						//
						// // 根据订单信息开始进行支付
						// String orderInfo =
						// platData.getString("content");
						// String sign = platData.getString("sign");
						// String info = orderInfo + "&sign=" + "\"" +
						// sign + "\"" + "&sign_type=\"RSA\"";
						// Log.d(Tools.TAG, "调用支付包接口支付参数: " + info);
						
						// String url = "http://wxpay.wxutil.com/pub_v2/app/app_pay.php";
						//
						// String data = HttpUtil.request(url, "", "post");
						// JSONObject json = new JSONObject(data);
						// Log.d("Ltsdk", "请求地址 ->> " + url); // 请求参数信息
						// Log.d("Ltsdk", "获取微信支付订单信息 ->> " + data); // 请求参数信息
						//
						// PayReq req = new PayReq();
						// // req.appId = "wxf8b4f85f3a794e77"; // 测试用appId
						// req.appId = json.getString("appid");
						// req.partnerId = json.getString("partnerid");
						// req.prepayId = json.getString("prepayid");
						// req.nonceStr = json.getString("noncestr");
						// req.timeStamp = json.getString("timestamp");
						// req.packageValue = json.getString("package");
						// req.sign = json.getString("sign");
						// req.extData = "app data"; // optional
						//
						// WeChatPay(mActivity, req);
						
						FAApk.getMainHandler().post(new Runnable()
						{
							@Override
							public void run()
							{
								
								if (mPayUtil == null)
								{
									PayUtilCallBack callBack = new PayUtilCallBack()
									{
										@Override
										public void onPayException(String arg0)
										{
											Log.d("Ltsdk", "竣付通支付返回信息：" + arg0); // 支付返回信息
										}
									};
									
									mPayUtil = new PayUtil(mActivity, APPID, KEY, VECTOR, SYSTEM_NAME, callBack, true);	// 设置支付参数
								}
								
								int payType = 3;  // 3为微信，4为支付宝，11 为QQ支付，12为京东
								mPayUtil.getToken(getTokenParam(), payType);
								
							}
						});
						
						// mPayUtil.getToken(getTokenParam(), new PayGetPayTypeListener()
						// {
						// @Override
						// public void onPayDataResult()
						// {
						// runOnUiThread(mRunnable);
						// }
						// });
						
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				else
				{
					AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
				}
			}
		});
	}
	
	//
	private static TokenParam getTokenParam()
	{
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		String CompKey = COM_KEY;
		
		String p1_usercode = CODE;
		String p2_order = dateFormat.format(date);
		String p3_money = "0.01";
		String p4_returnurl = RETURN_URL; // user define
		String p5_notifyurl = NOTICE_URL; // user define
		String p6_ordertime = dateFormat.format(date);
		String p7_sign = PayMD5Util.getMD5(
				p1_usercode + "&" + p2_order + "&" + p3_money + "&" + p4_returnurl + "&" + p5_notifyurl + "&" + p6_ordertime + CompKey).toUpperCase();
		
		TokenParam tokenParam = new TokenParam();
		tokenParam.setP1_usercode(p1_usercode);
		tokenParam.setP2_order(p2_order);
		tokenParam.setP3_money(p3_money);
		tokenParam.setP4_returnurl(p4_returnurl);
		tokenParam.setP5_notifyurl(p5_notifyurl);
		tokenParam.setP6_ordertime(p6_ordertime);
		tokenParam.setP7_sign(p7_sign);
		return tokenParam;
	}
	
	// 获取支付结果
	public static void onResume(final Activity mActivity)
	{
		if (mPayUtil != null)
		{
			mPayUtil.getPayStatus(new PayGetPayStatusListener()
			{
				@Override
				public void onPayStatus(int payStatus)
				{
					if (payStatus == SUCCESS)
					{
						AndroidUtil.printToast(mActivity, "微信，支付成功");
					}
					else
					{
						AndroidUtil.printToast(mActivity, "微信，支付失败！");
					}
				}
			});
			
		}
	}
	
	public static void onDestroy()
	{
		if (mPayUtil != null)
		{
			mPayUtil.destroy();
			mPayUtil = null;
		}
	}
	
}
