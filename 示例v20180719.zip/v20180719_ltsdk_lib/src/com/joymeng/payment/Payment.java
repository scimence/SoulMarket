﻿
package com.joymeng.payment;

import java.util.HashMap;

import android.app.Activity;
import android.content.Intent;

import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.util.AndroidUtil;


public class Payment
{
	private static final String ORDER_URL = "http://netuser.joymeng.com/order/jmpay";
//	private static final String ORDER_URL = "http://10.80.5.71:88/Order/jmpay";
	private static Payment mInstance = new Payment();
	private Activity mActivity = null;
	private boolean isLandscape;
	
	public static Payment getInstance()
	{
		return mInstance;
	}
	
	public void init(Activity activity)
	{
		mActivity = activity;
		isLandscape = PayActivity.isLandscape(activity);	// 支付界面随主界面的横竖屏属性
	}
	
	public void init(Activity activity, boolean landscape)
	{
		mActivity = activity;
		isLandscape = landscape;
	}
	
	public void pay(HashMap<String, String> payInfo)
	{
		// 创建订单地址
		payInfo.put(PaymentKey.PRIV_ORDER_URL, ORDER_URL);
		
		if (!AndroidUtil.isNetworkAvaliable(mActivity))
		{
			AndroidUtil.printToast(mActivity, "网络不可用，请检查网络");
			return;
		}
		
		// Intent intent = new Intent(mActivity, PaymentActivity.class);// 1.0版本支付逻辑
		Intent intent = new Intent(mActivity, PayActivity.class); // 新的支付调用逻辑
		intent.putExtra("payInfo", payInfo);
		intent.putExtra("landscape", isLandscape);
		mActivity.startActivity(intent);
	}
	
	public void destroy()
	{	
		
	}
}
