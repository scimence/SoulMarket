﻿
package com.ltpay.tackePhoto;

import java.io.ByteArrayOutputStream;
import java.lang.ref.WeakReference;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Base64;


/** BitmapTool.java: ----- 2018-6-14 下午3:59:35 wangzhongyuan */
public class BitmapTool
{
	/** 图片转string */
	public static String ToString(Bitmap bitmap)
	{
		ByteArrayOutputStream outStream = new ByteArrayOutputStream();	// outputstream
		bitmap.compress(CompressFormat.PNG, 100, outStream);			// 保存图像到输出流中
		byte[] bytes = outStream.toByteArray();							// 转为byte数组
		return Base64.encodeToString(bytes, Base64.DEFAULT);			// Base64编码数组
	}
	
	/** string数据转bitmap */
	public static Bitmap ToBitmap(String bitmapData)
	{
		Bitmap bitmap = null;
		try
		{
			// out = new FileOutputStream("/sdcard/aa.jpg");
			byte[] bitmapArray = Base64.decode(bitmapData, Base64.DEFAULT);
			bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
			// bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
			return bitmap;
		}
		catch (Exception e)
		{
			return null;
		}
	}
	
	/** Drawable数据转Bitmap */
	public static Bitmap ToBitmap(Drawable drawable)
	{
		// 取 drawable 的长宽
		int w = drawable.getIntrinsicWidth();
		int h = drawable.getIntrinsicHeight();
		
		// 取 drawable 的颜色格式
		Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
		
		// 建立对应 bitmap
		Bitmap bitmap = Bitmap.createBitmap(w, h, config);
		
		// 建立对应 bitmap 的画布
		Canvas canvas = new Canvas(bitmap);
		drawable.setBounds(0, 0, w, h);
		
		// 把 drawable 内容画到画布中
		drawable.draw(canvas);
		
		return bitmap;
	}
	
	/** Bitmap数据转Drawable */
	public static Drawable ToDrawable(Bitmap bitmap)
	{
		Drawable drawable = new BitmapDrawable(bitmap);
		return drawable;
	}
	
	/** 按指定大小载入bitmap */
	public static Bitmap ReSizeBitmap(String path, int w, int h)
	{
		BitmapFactory.Options opts = new BitmapFactory.Options();
		
		// 设置为ture只获取图片大小
		opts.inJustDecodeBounds = true;
		opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
		BitmapFactory.decodeFile(path, opts);
		
		int width = opts.outWidth;
		int height = opts.outHeight;
		float scaleWidth = 0.f, scaleHeight = 0.f;
		if (width > w || height > h)
		{
			// 缩放
			scaleWidth = ((float) width) / w;
			scaleHeight = ((float) height) / h;
		}
		opts.inJustDecodeBounds = false;
		float scale = Math.max(scaleWidth, scaleHeight);
		opts.inSampleSize = (int) scale;
		WeakReference<Bitmap> weak = new WeakReference<Bitmap>(BitmapFactory.decodeFile(path, opts));
		return Bitmap.createScaledBitmap(weak.get(), w, h, true);
	}
	
	/** bitmap转化为圆形，剔除圆圈外像素 */
	public static Bitmap CircleProcess(Bitmap pic)
	{
		int W = pic.getWidth();
		int H = pic.getWidth();
		int R = ((W < H) ? W : H) / 2;
		
		int x0 = W / 2;
		int y0 = H / 2;
		
		Bitmap tmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
		
		int colorTrans = Color.parseColor("#00ffffff");
		for (int h = 0; h < pic.getHeight(); h++)
		{
			for (int w = 0; w < pic.getWidth(); w++)
			{
				int pix = pic.getPixel(w, h);
				
				int N = (w - x0) * (w - x0) + (h - y0) * (h - y0);
				if (N > R * R)
					tmp.setPixel(w, h, colorTrans);				// 超出半径范围，清空像素
				else tmp.setPixel(w, h, pix);					// 复制像素
			}
		}
		
		return tmp;
	}
	
	// /** 获取原图bitmap */
	// public static Bitmap convertToBitmap2(String path)
	// {
	// BitmapFactory.Options opts = new BitmapFactory.Options();
	// // 设置为ture只获取图片大小
	// opts.inJustDecodeBounds = true;
	// opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
	// // 返回为空
	// BitmapFactory.decodeFile(path, opts);
	// return BitmapFactory.decodeFile(path, opts);
	// }
}
