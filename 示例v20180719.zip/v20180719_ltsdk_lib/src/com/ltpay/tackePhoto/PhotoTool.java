﻿
package com.ltpay.tackePhoto;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;


public class PhotoTool
{
	public static final int NONE = 0;
	public static final String IMAGE_UNSPECIFIED = "image/*";// 任意图片类型
	
	public static final int RES_TakePhoto = 1;		// 拍照
	public static final int RES_ProccessPhoto = 2; 	// 缩放
	public static final int RES_Photo = 3;			// 最终图像
	
	/** 从系统相册中选取照片上传 */
	public static void SelectPicture(Activity activity)
	{
		// 调用系统的相册
		Intent intent = new Intent(Intent.ACTION_PICK, null);
		intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, IMAGE_UNSPECIFIED);
		
		// 选择图像后调用activity.onActivityResult:RES_ProccessPhoto逻辑
		activity.startActivityForResult(intent, RES_ProccessPhoto);
	}
	
	// /** 从系统相册中选取照片上传 */
	// public static void selectPictureFromAlbum(Fragment fragment)
	// {
	// // 调用系统的相册
	// Intent intent = new Intent(Intent.ACTION_PICK, null);
	// intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, IMAGE_UNSPECIFIED);
	//
	// // 调用剪切功能
	// fragment.startActivityForResult(intent, PHOTOZOOM);
	// }
	
	/** 拍照 */
	public static String TakePhoto(Activity activity)
	{
		String outPicPath = getPath(activity);
		
		// 调用系统的拍照功能
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(outPicPath)));
		
		// 拍照后调用activity.onActivityResult:RES_TakePhoto逻辑
		activity.startActivityForResult(intent, RES_TakePhoto);
		
		return outPicPath;
	}
	
	// /** 拍照 */
	// public static void photograph(Fragment fragment)
	// {
	// imageName = "/" + getStringToday() + ".jpg";
	//
	// // 调用系统的拍照功能
	// Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	// String status = Environment.getExternalStorageState();
	// if (status.equals(Environment.MEDIA_MOUNTED))
	// {
	// intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(Environment.getExternalStorageDirectory(), imageName)));
	// }
	// else
	// {
	// intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(fragment.getActivity().getFilesDir(), imageName)));
	// }
	// fragment.startActivityForResult(intent, PHOTOGRAPH);
	// }
	
	// /** 图片裁剪 */
	// public static void startPhotoZoom(Activity activity, Uri uri, int height, int width)
	// {
	// Intent intent = new Intent("com.android.camera.action.CROP");
	// intent.setDataAndType(uri, IMAGE_UNSPECIFIED);
	// intent.putExtra("crop", "true");
	// // aspectX aspectY 是宽高的比例
	// intent.putExtra("aspectX", 1);
	// intent.putExtra("aspectY", 1);
	// // outputX outputY 是裁剪图片宽高
	// intent.putExtra("outputX", height);
	// intent.putExtra("outputY", width);
	// intent.putExtra("noFaceDetection", true); // 关闭人脸检测
	// intent.putExtra("return-data", true);// 如果设为true则返回bitmap
	// intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);// 输出文件
	// intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
	// activity.startActivityForResult(intent, PHOTORESOULT);
	// }
	
	/** 图片裁剪
	 * 
	 * @param activity
	 * @param uri 原图的地址
	 * @param height 指定的剪辑图片的高
	 * @param width 指定的剪辑图片的宽
	 * @param 返回 剪辑后的图片路径 */
	public static String startPhotoZoom(Activity activity, Uri uri, int height, int width)
	{
		String outPicPath = getPath(activity);
		Uri destUri = Uri.fromFile(new File(outPicPath));
		
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, IMAGE_UNSPECIFIED);
		intent.putExtra("crop", "true");
		// aspectX aspectY 是宽高的比例
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		// outputX outputY 是裁剪图片宽高
		intent.putExtra("outputX", height);
		intent.putExtra("outputY", width);
		intent.putExtra("noFaceDetection", true); // 关闭人脸检测
		intent.putExtra("return-data", false);// 如果设为true则返回bitmap
		intent.putExtra(MediaStore.EXTRA_OUTPUT, destUri);// 输出文件
		intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
		
		// 图像裁切后调用activity.onActivityResult:RES_Photo逻辑
		activity.startActivityForResult(intent, RES_Photo);
		
		return outPicPath;
	}
	
	// /** 图片裁剪 */
	// public static void startPhotoZoom(Fragment fragment, Uri uri, int height, int width)
	// {
	// Intent intent = new Intent("com.android.camera.action.CROP");
	// intent.setDataAndType(uri, IMAGE_UNSPECIFIED);
	// intent.putExtra("crop", "true");
	// // aspectX aspectY 是宽高的比例
	// intent.putExtra("aspectX", 1);
	// intent.putExtra("aspectY", 1);
	// // outputX outputY 是裁剪图片宽高
	// intent.putExtra("outputX", height);
	// intent.putExtra("outputY", width);
	// intent.putExtra("return-data", true);
	// fragment.startActivityForResult(intent, PHOTORESOULT);
	// }
	
	// ----------------------------------------
	// 相关功能函数
	// ----------------------------------------
	
	/** 获取当前系统时间并格式化 */
	@SuppressLint("SimpleDateFormat")
	public static String getStringToday()
	{
		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		String dateString = formatter.format(currentTime);
		return dateString;
	}
	
	/** 制作图片的路径地址 */
	public static String getPath(Context context)
	{
		// 获取系统路径
		String RootDir = context.getFilesDir().toString();
		if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()))
		{
			RootDir = Environment.getExternalStorageDirectory().toString();
		}
		
		// 创建文件夹
		String path = RootDir + File.separator + "takePhoto/";
		File file = new File(path);
		if (!file.exists()) file.mkdirs();
		
		// 生成新的文件名
		String filePath = path + getStringToday() + ".jpg";
		
		return filePath;
	}
	
	/** 文件路径转化为Uri */
	public static Uri ToUri(String filePath)
	{
		return Uri.fromFile(new File(filePath));
	}
}
