﻿
package com.ltpay.tackePhoto;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.view.View;
import android.widget.Toast;


/** Photo.java: 实现图像的选择裁切，重写onActivityResult(RES_Photo,,)逻辑进行服务器上传. ----- 2018-6-14 上午8:54:55 wangzhongyuan */
public class PhotoActivity extends Activity /* AppCompatActivity */
{
	// ImageView image;
	
	// protected void onCreate(Bundle savedInstanceState)
	// {
	// super.onCreate(savedInstanceState);
	//
	// // setContentView(R.layout.photo_layout);
	// // image = (ImageView) this.findViewById(R.id.imageView);
	// }
	
	// 选择图像
	public void SelectPhoto(View view)
	{
		try
		{
			PhotoTool.SelectPicture(this);
		}
		catch (Exception ex)
		{	
			
		}
	}
	
	// 拍照
	public void TakePhoto(View view)
	{
		try
		{
			photoPath = PhotoTool.TakePhoto(this); // 获取拍照图像路径
		}
		catch (Exception ex)
		{
			Toast.makeText(this, "不支持拍照", Toast.LENGTH_SHORT).show();
		}
	}
	
	// 最终获取的图像
	public void PhotoResult(Bitmap bitmap)
	{
		// String picData = BitmapTool.ToString(bitmap); // 转化为字符串形式，存储至服务器端
		// bitmap = BitmapTool.ToBitmap(picData); // 从字符串数据，还原为Bitmap
		
		// if (bitmap != null) image.setImageBitmap(bitmap); // 显示图像
	}
	
	// // 选择图像
	// public void SelectPhoto(View view)
	// {
	// String[] permissions = new String[] { Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE };
	//
	// if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
	// || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
	// {
	// ActivityCompat.requestPermissions(this, permissions, MY_PERMISSIONS_REQUEST_SELECT_PHOTO);
	// }
	// else
	// {
	// PhotoUtil.selectPictureFromAlbum(this); // 从手机中选择图像
	// }
	// }
	
	// // 拍照
	// public void TakePhoto(View view)
	// {
	// String[] permissions = new String[] { Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA
	// };
	//
	// if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
	// || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
	// || ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
	// {
	// ActivityCompat.requestPermissions(this, permissions, MY_PERMISSIONS_REQUEST_TAKE_PHOTO);
	// }
	// else
	// {
	// photoPath = PhotoUtil.photograph(this); // 获取拍照图像路径
	// }
	// }
	
	String photoPath = "";	// 拍照获得的图像路径
	String outPath = "";
	
	int Height = 300;
	int Width = 300;
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent)
	{
		// 对拍照获得的图像进行裁切处理
		if (requestCode == PhotoTool.RES_TakePhoto)
		{
			if (!photoPath.equals(""))
			{
				// 对拍照获得的图像进行裁切
				Uri sourceImage = Uri.fromFile(new File(photoPath));
				outPath = PhotoTool.startPhotoZoom(this, sourceImage, Height, Width);
			}
		}
		
		// 对选取的图像进行裁切处理
		if (requestCode == PhotoTool.RES_ProccessPhoto)
		{
			if (intent == null) return;
			outPath = PhotoTool.startPhotoZoom(this, intent.getData(), Height, Width);
		}
		
		// 显示/上传 最终图像 处理逻辑
		if (requestCode == PhotoTool.RES_Photo)
		{
			// 缩放图像
			if (new File(outPath).exists())
			{
				Bitmap bitmap = BitmapTool.ReSizeBitmap(outPath, Height, Width);
				bitmap = BitmapTool.CircleProcess(bitmap);			// 转化为圆形图像
				
				PhotoResult(bitmap);
				
				// String picData = BitmapTool.ToString(bitmap); // 转化为字符串形式，存储至服务器端
				// bitmap = BitmapTool.ToBitmap(picData); // 从字符串数据，还原为Bitmap
				
				// if (bitmap != null) image.setImageBitmap(bitmap); // 显示图像
			}
		}
		
		super.onActivityResult(requestCode, resultCode, intent);
	}
	
	// private static final int MY_PERMISSIONS_REQUEST_SELECT_PHOTO = 1;
	// private static final int MY_PERMISSIONS_REQUEST_TAKE_PHOTO = 2;
	//
	// @Override
	// public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	// {
	// if (requestCode == MY_PERMISSIONS_REQUEST_SELECT_PHOTO)
	// {
	// if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED)
	// {
	// PhotoUtil.selectPictureFromAlbum(this);
	// }
	// else
	// {
	// Toast.makeText(this, "无存储权限，无法选择图像", Toast.LENGTH_SHORT).show();
	// }
	// }
	//
	// if (requestCode == MY_PERMISSIONS_REQUEST_TAKE_PHOTO)
	// {
	// if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED
	// && grantResults[2] == PackageManager.PERMISSION_GRANTED)
	// {
	// photoPath = PhotoUtil.photograph(this); // 拍照,获取图像路径
	// }
	// else
	// {
	// Toast.makeText(this, "需要要相机和存储权限，才能拍照", Toast.LENGTH_SHORT).show();
	// }
	// }
	//
	// super.onRequestPermissionsResult(requestCode, permissions, grantResults);
	// }
}
