﻿
package com.ltpay;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.joymeng.payment.R;
import com.ltpay.LtSDK;
import com.ltpay.function.CallBack;


/** MainActivity.java: ----- 2018-5-16 上午8:58:34 wangzhongyuan */
public class MainActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ltpay_layout_main);
		
		// 设置计费sdk名称信息
		TextView text = (TextView) this.findViewById(R.id.ltsdk_version);
		text.setText(LtSDK.sdkVersion);
		
		// 初始化
		LtSDK.Init(this, "1001");
		
		// 设置登出回调，计费sdk退出登录，游戏返回主界面
		LtSDK.SetLoginOut(loginOutCall);
		
		// 设置界面“是否接官方优惠信息”，选择开关回调——可不处理
		// LtSDK.isAcceptMessage() // 获取当前状态
		LtSDK.SetAcceptMessage(new CallBack()
		{
			@Override
			public void Onfail()
			{
				// TODO Auto-generated method stub
				// 不接收处理逻辑
			}
			
			@Override
			public void OnSuccess()
			{
				// TODO Auto-generated method stub
				// 接收处理逻辑
			}
		});
	}
	
	// 设置界面“退出当前帐号”回调逻辑
	CallBack loginOutCall = new CallBack()
	{
		@Override
		public void Onfail()
		{
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void OnSuccess()
		{
			// TODO Auto-generated method stub
			// 游戏需退出至游戏开始界面
		}
	};
	
	// 登录回调
	CallBack loginCall = new CallBack()
	{
		@Override
		public void Onfail()
		{
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void OnSuccess()
		{
			// TODO Auto-generated method stub
			
			// 登录后的用户参数，用于登录校验
			// Login.uid
			// Login.uname
			// Login.token
			
		}
	};
	
	// 支付回调
	CallBack payCall = new CallBack()
	{
		@Override
		public void Onfail()
		{
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void OnSuccess()
		{
			// TODO Auto-generated method stub
			// 支付逻辑完成，是否支付成功以服务器端校验结果为准
			// 根据支付时传递的Reserve判定对应的订单是否支付成功，可传游戏方的订单号，也可自行定义，但需保持唯一。
		}
	};
	
	public void onClick(View view)
	{
		if (view.getId() == R.id.login)
		{
			// 登录
			LtSDK.Login(loginCall);
		}
		else if (view.getId() == R.id.pay)
		{
			// 支付
			LtSDK.Pay("001", "商品名称1", 10, "8001", "支付透传字段", payCall);
		}
		else if (view.getId() == R.id.user_center)
		{
			// 显示用户中心
			LtSDK.ShowActivityCenter();
		}
	}
	
	public void onPause()
	{
		LtSDK.HideFloat();		// 关闭悬浮窗
		super.onPause();
	}
	
	public void onResume()
	{
		super.onResume();
		LtSDK.ShowFloat(this);	// 显示悬浮窗
	}
	
	public void onBackPressed()
	{
		// LtSDK.HideFloat(); // 若游戏已退出，悬浮窗未退出，请在游戏退出逻辑中调用此接口
		LtSDK.QuitCustom(this, new CallBack()	// 计费sdk退出逻辑，可使用游戏自己的退出
		{
			@Override
			public void Onfail()
			{
			}
			
			@Override
			public void OnSuccess()
			{
				LtSDK.HideFloat();
			}
		});	
	}
	
	protected void onDestroy()
	{
		LtSDK.HideFloat();		// 关闭悬浮窗
		super.onDestroy();
	}
}
