﻿
package com.ltpay;

import java.util.HashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.joymeng.payment.core.PaymentKey;
import com.ltpay.activity.Loading;
import com.ltpay.activity.Login;
import com.ltpay.activity.PayPage;
import com.ltpay.activity.SettingPage;
import com.ltpay.activity.UserCenter;
import com.ltpay.floatView.FloatService;
import com.ltpay.function.CallBack;
import com.ltpay.function.LtpayConfig;
import com.ltpay.function.Tools;


/** LtSDK.java: 乐堂计费sdk相关接口 ----- 2018-6-13 下午3:14:23 wangzhongyuan */
public class LtSDK
{
	public static String AppId = "";		// 乐堂应用Id
	public static String SubChannelId = "";	// 预留字段子渠道号
	public static Activity context;
	
	static boolean isInit = false;			// 记录是否已初始化
	
	public static CallBack LoginCallBack;	// 登录成功回调
	public static CallBack LoginOutCallBack;// 登出成功回调
	public static CallBack PayCallBack;		// 支付成功回调
	
	public static CallBack AcceptMessageCallBack;		// 是否接收官方信息回调接口
	public static String sdkVersion = "v20180719";
	
	/** 计费sdk初始化 */
	public static void Init(Activity context, String AppId/*, String SubChannelId*/)
	{
		if (!isInit)
		{
			LtSDK.context = context;
			LtSDK.AppId = AppId;
			LtSDK.SubChannelId = LtpayConfig.SubChannelId(context);
			
			Tools.ShowActivity(context, Loading.class);
			
			isInit = true;
		}
	}
	
	/** 计费sdk登录 */
	public static void Login(CallBack call)
	{
		if (isInit)
		{
			LoginCallBack = call;
			Tools.ShowActivity(context, Login.class);
		}
		else Tools.showText("调用登录前需先进行初始化Init()");
	}
	
	/** 计费sdk登出，返回游戏首页 */
	public static void SetLoginOut(CallBack call)
	{
		LoginOutCallBack = call;
	}
	
	/** 是否接收官方信息回调接口 */
	public static void SetAcceptMessage(CallBack call)
	{
		AcceptMessageCallBack = call;
	}
	
	/** 是否接收官方信息回调接口,当前状态 */
	public static boolean isAcceptMessage()
	{
		return SettingPage.acceptLtMessage;
	}
	
	/** 计费sdk支付: ServerId游戏服务器id、Reserve透传参数 */
	public static void Pay(String productId, String ProductName, int ProductMoneyFen, String ServerId, String Reserve, CallBack call)
	{
		if (isInit)
		{
			PayCallBack = call;
			
			HashMap<String, String> payInfo = new HashMap<String, String>();
			payInfo.put(PaymentKey.LtAppId, LtSDK.AppId);
			payInfo.put(PaymentKey.LtJoyId, Login.uid);
			
			payInfo.put(PaymentKey.LtInstantId, ServerId);
			payInfo.put(PaymentKey.LtReserve, Reserve);
			payInfo.put(PaymentKey.MoneyAmount, ProductMoneyFen + "");
			payInfo.put(PaymentKey.ProductId, productId);
			payInfo.put(PaymentKey.ProductName, ProductName);
			payInfo.put(PaymentKey.ProductDescript, ProductName);
			
			PayPage.ShowPay(context, payInfo);
		}
		else Tools.showText("调用支付前需先进行初始化Init()");
	}
	
	/** 显示用户中心 */
	public static void ShowActivityCenter()
	{
		if (isInit)
		{
			if (UserCenter.Instance == null)
				Tools.ShowActivity(context, UserCenter.class);
			else UserCenter.Instance.finish();
		}
		else Tools.showText("调用用户中心前需先进行初始化Init()");
	}
	
	/** 显示悬浮窗 */
	public static void ShowFloat(Context context)
	{
		if (Login.isLoginSuccess) FloatService.ShowFloat(context);	// 若已登录，则显示悬浮窗
	}
	
	/** 关闭悬浮窗 */
	public static void HideFloat()
	{
		FloatService.HideFloat();
	}
	
	/** demo自定义退出逻辑 */
	public static void QuitCustom(Context context, final CallBack call)
	{
		AlertDialog.Builder dialog = new AlertDialog.Builder(context);
		dialog.setTitle("确认退出？");
		dialog.setIcon(android.R.drawable.ic_dialog_info);
		dialog.setPositiveButton("确定", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				if (call != null) call.OnSuccess();
				System.exit(0);		// 退出运行
			}
		});
		
		dialog.setNegativeButton("取消", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				// 点击“返回”后的操作,这里不设置没有任何操作
				if (call != null) call.Onfail();
			}
		});
		
		dialog.show();
	}
	
}
