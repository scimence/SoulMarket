﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** ResetPassword_again.java: ----- 2018-6-5 下午2:41:06 wangzhongyuan */
public class ResetPassword_again extends Activity
{
	public static String password = "";		// 记录待找回密码的账号
	
	private Activity Instance;
	EditText Edit;
	Button Btn;
	
	boolean ResetByPassword = false;		// 是否通过登录密码重置密码
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_reset_password_again", "layout"));
		
		Bundle Extras = this.getIntent().getExtras();
		if (Extras != null && Extras.containsKey("ResetByPassword"))
		{
			ResetByPassword = Extras.getString("ResetByPassword", "false").equals("true");
		}
		
		Edit = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit", "id"));
		Btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		
		Btn.setOnClickListener(clickListener);
	}

	public void OnBack(View view)
	{
		this.finish();
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == Btn)
			{
				password = Edit.getText().toString();
				
				if (password.equals(ResetPassword.password))
				{
					CallBack call = new CallBack()
					{
						@Override
						public void Onfail()
						{	
							Tools.showToast(Instance, "服务器重置密码失败！");
							Instance.finish();
						}
						
						@Override
						public void OnSuccess()
						{
							Tools.ShowActivity(Instance, ResetPassword_finish.class);
							Login.password = password;
							
							Instance.finish();
						}
					};
					
					// 重置用户密码
					if(ResetByPassword) Server.resetPassword(Instance, Login.uname, password, "", Login.password, call);
					else Server.resetPassword(Instance, PasswordRecover_account.account, password, PasswordRecover_code.code, "", call);
				}
				else
				{
					Tools.showToast(Instance, "密码不一致，请重新设置！");
					Tools.ShowActivity(Instance, ResetPassword.class);
				}
			}
		}
	};
	
	
}
