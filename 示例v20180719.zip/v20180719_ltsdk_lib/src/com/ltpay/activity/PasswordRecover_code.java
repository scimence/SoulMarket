﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** PasswordRecover_code.java:找回密码验证码验证界面 ----- 2018-6-4 下午5:41:19 wangzhongyuan */
public class PasswordRecover_code extends Activity
{
	public static String code = "";	// 验证码信息
	
	private Activity Instance;
	
	EditText Edit;			// 验证码
	Button Btn;				// 确认
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_password_recovery_code", "layout"));
		
		Edit = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit", "id"));
		Btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		
		Btn.setOnClickListener(clickListener);
		
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == Btn)
			{
				code = Edit.getText().toString();
				
				CallBack call = new CallBack()
				{
					@Override
					public void Onfail()
					{	
						
					}
					
					@Override
					public void OnSuccess()
					{
						Tools.ShowActivity(Instance, ResetPassword.class);
						Instance.finish();
					}
				};
				
				Server.verifyCode(Instance, PasswordRecover_account.account, code, "2", call);	// 验证码验证
			}
		}
	};
	
}
