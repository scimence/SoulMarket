﻿
package com.ltpay.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack2;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** Announcement.java: 游戏公告信息 ----- 2018-6-6 下午4:44:31 wangzhongyuan */
public class Announcement extends Activity
{
	/** 显示公告信息界面 */
	public static void Show(Context context, String appId/* , String channelId */)
	{
		Tools.ShowActivity(context, Announcement.class, "appId", appId/* , "channelId", channelId */);
	}
	
	// -------------------
	
	private Activity Instance;
	TextView tittle;
	TextView body;
	Button btn;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_announcement", "layout"));
		
		tittle = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text_tittle", "id"));
		body = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text_body", "id"));
		btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		
		InitContent();
	}
	
	private void InitContent()
	{
		// String appId = "1001";
		// String channelId = "9999999";
		
		Bundle extras = Instance.getIntent().getExtras();
		if (extras == null)
		{
			Tools.showToast(Instance, "无公告相关参数！");
			return;
		}
		
		String appId = extras.getString("appId", "");
		// String channelId = extras.getString("channelId", "");
		
		CallBack2 call = new CallBack2()
		{
			
			@Override
			public void Onfail(Object... param)
			{
				Instance.finish();	// 无公告信息，关闭当前界面
			}
			
			@Override
			public void OnSuccess(final Object... param)
			{
				runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						
						tittle.setText((String) param[1]);
						body.setText((String) param[2]);
						
						// String content = "【I】 联网获取游戏列表信息..." + "\r\n" + "http://netunion.joymeng.com/index.php?m=Api&c=PackTool&a=gameList" + "\r\n" +
						// "【I】 获取游戏列表信息完成"
						// + "\r\n" + "【I】 载入游戏裸包 1001_1.0.7_1.11-17.24_sign.apk" + "\r\n" + "【I】 联网获取渠道列表信息..." + "\r\n"
						// + "http://netunion.joymeng.com/index.php?m=Api&c=PackTool&a=channelList" + "\r\n" + "【I】 获取渠道列表信息完成" + "\r\n"
						// + "【I】 载入所有选择渠道的计费文件信息..." + "\r\n" + "【I】 渠道0000002_乐堂动漫南区 ,存在计费文件:" + "\r\n"
						// + "E:\\joymeng\\apkTool\\files\\APK_Base\\渠道计费包\\0000002\\ltsdk_30_jmpay_v2.5.apk" + "\r\n" + "【I】 渠道0000020_手游天下 ,存在计费文件:" + "\r\n"
						// + "E:\\joymeng\\apkToo\\files\\APK_Base\\渠道计费包\\0000020\\ltsdk_30_jmpay_v2.5.apk" + "\r\n" + "【I】 渠道0000033_3533 ,存在计费文件:" + "\r\n"
						// + "E:\\joymeng\\apkTool\\files\\APK_Base\\渠道计费包\\0000033\\ltsdk_30_jmpay_v2.5.apk" + "\r\n" + "【I】 载入选择渠道的计费文件信息完成" + "\r\n";
						
						// body.setText(content);
						
					}
				});
				
			}
		};
		
		Server.GetAnnounceMent(Instance, appId, call);
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
}
