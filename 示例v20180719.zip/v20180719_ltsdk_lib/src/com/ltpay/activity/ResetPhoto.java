﻿
package com.ltpay.activity;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.Component;
import com.ltpay.function.Component.ClickListener;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;
import com.ltpay.tackePhoto.BitmapTool;
import com.ltpay.tackePhoto.PhotoActivity;


/** ResetPhoto.java:修改头像 ----- 2018-6-8 下午4:57:15 wangzhongyuan */
public class ResetPhoto extends PhotoActivity
{
	/** 记录用户头像信息 */
	public static class Photo_T
	{
		String id = "-1";
		String head_img = "";
		
		Photo_T()
		{};
		
		public Photo_T(String... data)
		{
			this.id = data[0];
			this.head_img = data[1];
		}
		
		public Photo_T(JSONObject J)
		{
			try
			{
				this.id = J.optString("id", "");
				this.head_img = J.optString("head_img", "");
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		/** 获取head_img对应的图像 */
		public Bitmap getBitmap()
		{
			Bitmap bitmap = null;
			
			if (!head_img.equals(""))
			{
				bitmap = BitmapTool.ToBitmap(head_img);
			}
			
			return bitmap;
		}
		
		/** 解析JSONArray中的数据 */
		public static ArrayList<Photo_T> Array(JSONArray pics)
		{
			ArrayList<Photo_T> photos = new ArrayList<ResetPhoto.Photo_T>();
			
			if (pics != null && pics.length() > 0)
			{
				for (int i = 0; i < pics.length(); i++)
				{
					try
					{
						JSONObject J = pics.getJSONObject(i);
						photos.add(new Photo_T(J));
					}
					catch (JSONException e)
					{
						e.printStackTrace();
					}
					
				}
			}
			
			return photos;
		}
	}
	
	// ---------------------------
	
	private ResetPhoto Instance;
	Component com;
	
	public static String picData = "";				// 用户头像信息
	public static ArrayList<Photo_T> heads = null;	// 用户默认头像信息
	public static String headIndex = "-1";			// 用户头像索引值
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_reset_photo", "layout"));
		
		com = new Component(Instance, listener, "ltpay_liner1", "ltpay_liner_m", "ltpay_liner_f", "ltpay_liner_c", "ltpay_btn", "ltpay_image", "ltpay_photo_m",
				"ltpay_photo_f");
		SetMode(1);
		
		//
		showPhotos();
	}
	
	// 显示用户头像信息、系统默认头像
	private void showPhotos()
	{
		// 设置头像
		if (!ResetPhoto.picData.equals(""))
		{
			Bitmap bitmap = BitmapTool.ToBitmap(ResetPhoto.picData); // 从字符串数据，还原为Bitmap
			if (bitmap != null) com.ImageView("ltpay_image").setImageBitmap(bitmap);
		}
		
		// 系统默认头像
		if (heads != null)
		{
			if (heads.size() > 0)
			{
				Bitmap bitmap = BitmapTool.ToBitmap(heads.get(0).head_img); // 从字符串数据，还原为Bitmap
				if (bitmap != null) com.ImageView("ltpay_photo_m").setImageBitmap(bitmap);
			}
			
			if (heads.size() > 1)
			{
				Bitmap bitmap2 = BitmapTool.ToBitmap(heads.get(1).head_img); // 从字符串数据，还原为Bitmap
				if (bitmap2 != null) com.ImageView("ltpay_photo_f").setImageBitmap(bitmap2);
			}
		}
	}
	
	public void OnBack(View view)
	{
		this.finish();
		Tools.ShowActivity(Instance, SettingPage.class);
	}
	
	ClickListener listener = new ClickListener()
	{
		@Override
		public void Click(String viewId)
		{
			if (viewId.equals("ltpay_liner1") || viewId.equals("ltpay_image"))		// 选择头像
			{
				Instance.SelectPhoto(null);
				headIndex = "-1";
			}
			else if (viewId.equals("ltpay_liner_m") || viewId.equals("ltpay_photo_m"))	// male
			{
				SetMode(1);
				
				if (heads.size() > 0)
				{
					Photo_T pic = heads.get(0);
					PhotoResult(pic.getBitmap());
					headIndex = pic.id;
				}
			}
			else if (viewId.equals("ltpay_liner_f")|| viewId.equals("ltpay_photo_f")) // female
			{
				SetMode(2);
				
				if (heads.size() > 1)
				{
					Photo_T pic = heads.get(1);
					PhotoResult(pic.getBitmap());
					headIndex = pic.id;
				}
			}
			else if (viewId.equals("ltpay_liner_c")) // 上传/拍照
			{
				SetMode(3);
				Instance.TakePhoto(null);
				headIndex = "-1";
			}
			else if (viewId.equals("ltpay_btn"))	// 确认修改
			{
				CallBack call = new CallBack()
				{
					@Override
					public void Onfail()
					{
						Tools.showToast(Instance, "头像修改失败");
					}
					
					@Override
					public void OnSuccess()
					{
						Tools.showToast(Instance, "头像已修改");
						ResetPhoto.picData = curPicData;
						
						OnBack(null);
					}
				};
				
				Server.UploadPhoto(Instance, Login.uid, curPicData, headIndex, call);
			}
		}
	};
	
	private void SetMode(int mode)
	{
		com.GetView("ltpay_circle_m").setVisibility(mode == 1 ? View.VISIBLE : View.INVISIBLE);
		com.GetView("ltpay_circle_f").setVisibility(mode == 2 ? View.VISIBLE : View.INVISIBLE);
		com.GetView("ltpay_circle_c").setVisibility(mode == 3 ? View.VISIBLE : View.INVISIBLE);
	}
	
	String curPicData = "";
	
	// 最终获取的图像
	public void PhotoResult(Bitmap bitmap)
	{
		if (bitmap != null)
		{
			com.ImageView("ltpay_image").setImageBitmap(bitmap); 	// 显示图像
			curPicData = BitmapTool.ToString(bitmap); 					// 转化为字符串形式，存储至服务器端
			
			// ResetPhoto.picData = curPicData;
		}
		
		// bitmap = BitmapTool.ToBitmap(picData); // 从字符串数据，还原为Bitmap
		// if (bitmap != null) image.setImageBitmap(bitmap); // 显示图像
	}
}
