﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.Tools;


/** PaySuccess.java: ----- 2018-5-24 下午4:05:16 wangzhongyuan */
public class PaySuccess extends Activity
{
	private static Activity Instance;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_pay_success", "layout"));
		Tools.AutoHide(Instance, 2000, null);
	}
	
}
