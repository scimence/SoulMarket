﻿package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.Tools;

/**  
 * ResetPassword_finish.java:
 * -----
 * 2018-6-5 下午2:42:47
 * wangzhongyuan 
 */
public class ResetPassword_finish extends Activity
{
	public static String password = "";		// 记录待找回密码的账号
	
	private Activity Instance;
	Button Btn;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_reset_password_finish", "layout"));
		
		Btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		
		Btn.setOnClickListener(clickListener);
	}

	public void OnBack(View view)
	{
		this.finish();
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == Btn)
			{
				Tools.ShowActivity(Instance, Login.class);
				Instance.finish();
			}
		}
	};
	
	
}

