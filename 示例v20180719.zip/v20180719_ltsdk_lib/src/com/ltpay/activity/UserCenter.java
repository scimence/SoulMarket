﻿
package com.ltpay.activity;

import org.json.JSONArray;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.activity.ResetPhoto.Photo_T;
import com.ltpay.function.CallBack2;
import com.ltpay.function.Component;
import com.ltpay.function.Component.ClickListener;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;
import com.ltpay.tackePhoto.BitmapTool;


/** UserCenter.java: ----- 2018-6-4 上午9:56:53 wangzhongyuan */
public class UserCenter extends Activity
{
	public static UserCenter Instance;
	
	Component com;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		if (!Login.isLoginSuccess)	// 若未登录，则先跳转登录
		{
			Tools.ShowActivity(Instance, Login.class);
			Instance.finish();
			return;
		}
		
		setContentView(ResUtil.getId(this, "ltpay_layout_user_center", "layout"));
		
		com = new Component(this, listener, "ltpay_usercenter1", "ltpay_usercenter2", "ltpay_usercenter3", "ltpay_usercenter4", "ltpay_usercenter5",
				"ltpay_usercenter6");
		com.AddView("ltpay_username", "ltpay_userid", "ltpay_btn", "ltpay_text_version");
		
		com.TextView("ltpay_username").setText(Login.uname);
		com.TextView("ltpay_userid").setText("UID: " + Login.uid);
		com.TextView("ltpay_text_version").setText("SDK版本: " + LtSDK.sdkVersion);
		
		
		Server.getPhoto(Instance, Login.uid, photoCall);			// 获取用户头像
		Server.getBalance(Instance, Login.uid, balanceCall);		// 获取余额信息
	}
	
	// 显示用户余额信息
	CallBack2 balanceCall = new CallBack2()
	{
		
		@Override
		public void Onfail(Object... data)
		{	
			
		}
		
		@Override
		public void OnSuccess(Object... data)
		{
			Double balance = Double.parseDouble(data[0].toString());
			Log.d("ltpay", "balance:" + balance + "");
			
			showUserBalance(balance + "");
		}
	};
	
	// 显示用户余额
	private void showUserBalance(final String balanceStr)
	{
		runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				com.TextView("ltpay_userbalance").setText("用户余额:￥ " + balanceStr);
			}
		});
	}
	
	// 获取用户头像回调
	CallBack2 photoCall = new CallBack2()
	{
		@Override
		public void Onfail(Object... data)
		{}
		
		@Override
		public void OnSuccess(Object... data)
		{
			// Tools.showToast(Instance, data[0].toString());
			
			String picData = data[0].toString();
			if (data.length > 0 && !picData.equals(""))		// 解析用户头像信息
			{
				ResetPhoto.picData = data[0].toString();	
				showUserPhoto(ResetPhoto.picData);
			}
			
			if (data.length > 1 && data[1] != null)			// 解析服务器默认头像数据
			{
				JSONArray pics = (JSONArray) data[1];
				ResetPhoto.heads = Photo_T.Array(pics);
			}
			
		}
	};
	
	// 显示用户头像
	private void showUserPhoto(final String picData)
	{
		runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				Bitmap bitmap = BitmapTool.ToBitmap(picData); // 从字符串数据，还原为Bitmap
				
				if (bitmap != null)
				{
					Drawable drawable = BitmapTool.ToDrawable(bitmap);
					com.ImageView("ltpay_userphoto").setBackground(drawable);
				}
			}
		});
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	public void finish()
	{
		Instance = null;
		super.finish();
	}
	
	public void onClick(String viewId)
	{	
		
	}
	
	ClickListener listener = new ClickListener()
	{
		@Override
		public void Click(String viewId)
		{
			if (viewId.equals("ltpay_usercenter1"))
			{
				Tools.ShowActivity(Instance, ActivityCenter.class);
			}
			else if (viewId.equals("ltpay_usercenter2"))
			{
				// Tools.showToast(Instance, "暂无系统消息");
				Tools.ShowActivity(Instance, SystemMessage.class);
			}
			else if (viewId.equals("ltpay_usercenter3"))
			{
				// Tools.showToast(Instance, "暂无优惠券");
				Coupon.Show(Instance, LtSDK.AppId, Login.uid, "", "", "");
			}
			else if (viewId.equals("ltpay_usercenter4"))
			{
				Tools.ShowActivity(Instance, SettingPage.class);
				Instance.finish();
			}
			else if (viewId.equals("ltpay_usercenter5"))
			{
				Tools.showToast(Instance, "暂无客服");
			}
			else if (viewId.equals("ltpay_usercenter6"))
			{
				Tools.ShowActivity(Instance, ChargeRecord.class);
			}
			else if (viewId.equals("ltpay_btn"))
			{
				Instance.finish();
			}
		}
	};
	
}
