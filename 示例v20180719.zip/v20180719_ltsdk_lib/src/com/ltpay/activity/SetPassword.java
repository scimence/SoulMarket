﻿package com.ltpay.activity;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.Tools;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

/**  
 * SetPassword.java:
 * -----
 * 2018-6-6 上午11:54:28
 * wangzhongyuan 
 */
public class SetPassword extends Activity
{
	public static String password = "";		// 记录待找回密码的账号
	
	private Activity Instance;
	EditText Edit;
	Button Btn;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_set_password", "layout"));
		
		Edit = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit", "id"));
		
		Btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		Btn.setOnClickListener(clickListener);
	}

	public void OnBack(View view)
	{
		this.finish();
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == Btn)
			{
				password = Edit.getText().toString();
				
				Tools.ShowActivity(Instance, SetPassword_again.class);
				Instance.finish();
			}
		}
	};
	
}
