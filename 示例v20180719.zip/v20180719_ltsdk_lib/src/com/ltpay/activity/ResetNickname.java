﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.Component;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;
import com.ltpay.function.Component.ClickListener;


/** ResetNickname.java:修改昵称界面 ----- 2018-6-8 上午8:55:07 wangzhongyuan */
public class ResetNickname extends Activity
{
	private Activity Instance;
	Component com;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_reset_nickname", "layout"));
		com = new Component(Instance, listener, "ltpay_edit", "ltpay_btn");
	}
	
	public void OnBack(View view)
	{
		Tools.ShowActivity(Instance, SettingPage.class);
		this.finish();
	}
	
	ClickListener listener = new ClickListener()
	{
		@Override
		public void Click(String viewId)
		{
			if (viewId.equals("ltpay_btn"))
			{
				final String nickName = com.EditText("ltpay_edit").getText().toString();
				
				CallBack call = new CallBack()
				{
					@Override
					public void Onfail()
					{
						// TODO Auto-generated method stub
					}
					
					@Override
					public void OnSuccess()
					{
						Login.nname = nickName;
						Tools.ShowActivity(Instance, SettingPage.class);
						
						Instance.finish();
					}
				};
				
				Server.ResetNickname(Instance, Login.uid, nickName, call);
			}
		}
	};
}
