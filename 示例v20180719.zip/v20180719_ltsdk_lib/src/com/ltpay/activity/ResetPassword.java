﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.Tools;


/** ResetPassword.java: ----- 2018-6-5 下午2:31:10 wangzhongyuan */
public class ResetPassword extends Activity
{
	public static String password = "";		// 记录待找回密码的账号
	
	private Activity Instance;
	EditText Edit;
	Button Btn;
	
	boolean ResetByPassword = false;		// 是否通过登录密码重置密码
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_reset_password", "layout"));
		
		Bundle Extras = this.getIntent().getExtras();
		if (Extras != null && Extras.containsKey("ResetByPassword"))
		{
			ResetByPassword = Extras.getString("ResetByPassword", "false").equals("true");
		}
		
		Edit = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit", "id"));
		
		Btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		Btn.setOnClickListener(clickListener);
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == Btn)
			{
				password = Edit.getText().toString();
				
				if (ResetByPassword)
					Tools.ShowActivity(Instance, ResetPassword_again.class, "ResetByPassword", "true");
				else Tools.ShowActivity(Instance, ResetPassword_again.class);
				
				Instance.finish();
			}
		}
	};
	
}
