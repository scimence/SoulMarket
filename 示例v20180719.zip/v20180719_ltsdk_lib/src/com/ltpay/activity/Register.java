﻿
package com.ltpay.activity;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.Preference;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** Register.java: ----- 2018-5-16 上午10:22:40 wangzhongyuan */
public class Register extends Activity
{
	private Activity Instance;
	
	TextView TabPhone;
	TextView TabEmail;
	View TabLine1;
	View TabLine2;
	
	LinearLayout LinePhone;
	EditText EditEmail;
	
	Spinner SpinnerZone;
	EditText EditPhone;
	EditText EditCode;
	
	TextView GetCode;
	CheckBox AllowProtocal;
	TextView UserProtocal;
	Button Register;
	
	Preference localInfo;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		localInfo = new Preference(this, "LtAccountInfo");
		
		setContentView(ResUtil.getId(this, "ltpay_layout_register", "layout"));
		
		initViews();
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	private void initViews()
	{
		// 获取对应控件
		TabPhone = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text_phone", "id"));
		TabEmail = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text_email", "id"));
		TabLine1 = (View) this.findViewById(ResUtil.getId(this, "ltpay_line1", "id"));
		TabLine2 = (View) this.findViewById(ResUtil.getId(this, "ltpay_line2", "id"));
		
		LinePhone = (LinearLayout) this.findViewById(ResUtil.getId(this, "ltpay_liner_phone", "id"));
		EditEmail = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit_email", "id"));
		
		SpinnerZone = (Spinner) this.findViewById(ResUtil.getId(this, "ltpay_spinner_zone", "id"));
		EditPhone = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit_phone", "id"));
		EditCode = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit_verifycode", "id"));
		
		GetCode = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text_getcode", "id"));
		AllowProtocal = (CheckBox) this.findViewById(ResUtil.getId(this, "ltpay_check_allowprotocal", "id"));
		UserProtocal = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text_getuserprotocal", "id"));
		
		Register = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn_register", "id"));
		
		// 设置响应逻辑
		TabPhone.setOnClickListener(clickListener);
		TabEmail.setOnClickListener(clickListener);
		GetCode.setOnClickListener(clickListener);
		UserProtocal.setOnClickListener(clickListener);
		Register.setOnClickListener(clickListener);
		
		AllowProtocal.setOnClickListener(clickListener);
		
		// 获取验证码接口执行倒计时
		CountDown(90, true);
	}
	
	String mode = "phone";
	
	// 设置显示模式，phone、email
	private void setMode(String mode)
	{
		this.mode = mode;
		int green = Color.parseColor("#0cfed1");
		int gray = Color.parseColor("#b9b9b9");
		int black = Color.parseColor("#000000");
		if (mode.equals("phone"))
		{
			TabLine1.setBackgroundColor(green);
			TabLine2.setBackgroundColor(gray);
			
			TabPhone.setTextColor(black);
			TabEmail.setTextColor(gray);
			
			LinePhone.setVisibility(View.VISIBLE);
			EditEmail.setVisibility(View.INVISIBLE);
		}
		else if (mode.equals("email"))
		{
			TabLine1.setBackgroundColor(gray);
			TabLine2.setBackgroundColor(green);
			
			TabPhone.setTextColor(gray);
			TabEmail.setTextColor(black);
			
			LinePhone.setVisibility(View.INVISIBLE);
			EditEmail.setVisibility(View.VISIBLE);
		}
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == TabPhone)
			{
				setMode("phone");
			}
			else if (v == TabEmail)
			{
				setMode("email");
			}
			else if (v == GetCode)
			{
				SendCode();
			}
			else if (v == UserProtocal)
			{
				Tools.ShowActivity(Instance, UserProtocal.class);
			}
			else if (v == Register)
			{
				UserRegister();
			}
			else if (v == AllowProtocal)
			{
				int gray = Color.parseColor("#b9b9b9");
				int blue = Color.parseColor("#5677fc");
				
				if (AllowProtocal.isChecked())
				{
					Register.setEnabled(true);
					Register.setTextColor(blue);
				}
				else
				{
					Register.setEnabled(false);
					Register.setTextColor(gray);
				}
			}
		}
	};
	
	public static String account = "";	// 帐号
	public static String code = "";		// 验证码
	public static String zone = "";		// 手机号区域
	
	// 用户注册
	private void UserRegister()
	{
		code = EditCode.getText().toString().trim();	// 验证码
		if (code.equals(""))
			Tools.showToast(Instance, "请输入验证码");
		else
		{
			if (mode.equals("phone"))
			{
				zone = SpinnerZone.getSelectedItem().toString();
				if (zone.contains("+")) zone = zone.substring(zone.indexOf("+") + 1);
				
				account = EditPhone.getText().toString().trim();
				
				if (account.equals(""))
				{
					Tools.showToast(this, "请输入手机号");
					return;
				}
			}
			else if (mode.equals("email"))
			{
				zone = "";
				account = EditEmail.getText().toString().trim();
				
				if (account.equals(""))
				{
					Tools.showToast(this, "请输入邮箱");
					return;
				}
			}
			
			CallBack call = new CallBack()
			{
				@Override
				public void Onfail()
				{
					Tools.showToast(Instance, "验证码错误，请输入正确的验证码！");
				}
				
				@Override
				public void OnSuccess()
				{
					Tools.ShowActivity(Instance, SetPassword.class);
					Instance.finish();
				}
			};
			
			Server.verifyCode(Instance, account, code, "0", call);	// 验证码验证
		}
	}
	
	// 发送验证码接口
	private void SendCode()
	{
		CallBack call = new CallBack()
		{
			@Override
			public void Onfail()
			{
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void OnSuccess()
			{
				CountDownReset();		// 重置当前时间值
				CountDown(90, true);	// 执行倒计时逻辑
			}
		};
		
		if (mode.equals("phone"))
		{
			String zon = SpinnerZone.getSelectedItem().toString();
			if (zon.contains("+")) zon = zon.substring(zon.indexOf("+") + 1);
			
			String number = EditPhone.getText().toString().trim();
			
			if (number.equals(""))
				Tools.showToast(this, "请输入手机号");
			else Server.sendCode(this, number, call, zon);	// 发送验证码
		}
		else if (mode.equals("email"))
		{
			String email = EditEmail.getText().toString().trim();
			
			if (email.equals(""))
				Tools.showToast(this, "请输入邮箱");
			else Server.sendCode(this, email, call, "");	// 发送验证码
		}
	}
	
	// 限制点击倒计时时间
	private void GetCodeEanble(boolean enable)
	{
		if (enable)
		{
			GetCode.setEnabled(true);
			int color = Color.parseColor("#3f51b5");
			GetCode.setTextColor(color);
		}
		else
		{
			GetCode.setEnabled(false);
			int color = Color.parseColor("#b9b9b9");
			GetCode.setTextColor(color);
		}
	}
	
	// 记录当前时间
	private void CountDownReset()
	{
		localInfo.put("LastCodeTime", System.currentTimeMillis() + "");
	}
	
	// 倒计时剩余时间
	private int TimeLimit(int secondLimit)
	{
		String LastCodeTimeStr = localInfo.get("LastCodeTime");
		if (LastCodeTimeStr.equals(""))
			return 0;
		else
		{
			long LastCodeTime = Long.parseLong(LastCodeTimeStr);
			return (int) ((LastCodeTime + 1000 * secondLimit - System.currentTimeMillis()) / 1000);
		}
	}
	
	Handler handler = new Handler();
	
	private void CountDown(final int secondLimit, final boolean isFirst)
	{
		handler.postDelayed(new Runnable()
		{
			@Override
			public void run()
			{
				int limit = TimeLimit(secondLimit);
				if (limit <= 0)
				{
					GetCodeEanble(true);
					
					GetCode.setText("点击获取");
				}
				else
				{
					if (GetCode.isEnabled()) GetCodeEanble(false);
					
					GetCode.setText(limit + "");
					CountDown(secondLimit, false);
				}
			}
		}, isFirst ? 0 : 1000);
	}
	
}
