﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.Preference;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** SetPassword_again.java: ----- 2018-6-6 上午11:57:43 wangzhongyuan */
public class SetPassword_again extends Activity
{
	public static String password = "";		// 记录待找回密码的账号
	
	private Activity Instance;
	EditText Edit;
	Button Btn;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_set_password_again", "layout"));
		
		Edit = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit", "id"));
		Btn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn", "id"));
		
		Btn.setOnClickListener(clickListener);
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == Btn)
			{
				password = Edit.getText().toString();
				
				if (password.equals(SetPassword.password))
				{
					CallBack call = new CallBack()
					{
						@Override
						public void Onfail()
						{
							Tools.showToast(Instance, "服务器用户注册失败！");
						}
						
						@Override
						public void OnSuccess()
						{
							// 记录当前帐号密码信息
							Preference localInfo = new Preference(Instance, "LtAccountInfo");
							localInfo.put("isSaved", true + "");
							localInfo.put("uname", Register.account);
							localInfo.put("password", password);
							
							// 跳转登录界面
							Tools.ShowActivity(Instance, Login.class);
							Instance.finish();
						}
					};
					
					// 注册新用户
					Server.UserRegister(Instance, Register.account, password, Register.code, call, Register.zone);
				}
				else
				{
					Tools.showToast(Instance, "密码不一致，请重新设置！");
					Tools.ShowActivity(Instance, SetPassword.class);
				}
			}
		}
	};
	
}
