﻿
package com.ltpay.activity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.floatView.FloatService;
import com.ltpay.function.Component;
import com.ltpay.function.Preference;
import com.ltpay.function.Component.ClickListener;
import com.ltpay.function.Tools;
import com.ltpay.tackePhoto.BitmapTool;


/** SettingPage.java:设置界面 ----- 2018-6-6 下午4:30:09 wangzhongyuan */
public class SettingPage extends Activity
{
	private Activity Instance;
	Preference localInfo;
	Component com;
	public static boolean acceptLtMessage = false;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_setting_page", "layout"));
		com = new Component(Instance, listener, "ltpay_nickname", "ltpay_photo", "ltpay_password", "ltpay_phone", "ltpay_accept_msg",
				"ltpay_loginout", "ltpay_toggleButton");
		
		com.TextView("ltpay_nickname_text").setText("当前昵称：" + Login.nname);
		
		// 设置头像
		if (!ResetPhoto.picData.equals(""))
		{
			Bitmap bitmap = BitmapTool.ToBitmap(ResetPhoto.picData); // 从字符串数据，还原为Bitmap
			if (bitmap != null)
			{
				Drawable drawable = BitmapTool.ToDrawable(bitmap);
				com.ImageView("ltpay_userphoto").setBackground(drawable);
			}
		}
		
		localInfo = new Preference(this, "LtAccountInfo");
		loadAccountInfo();
	}
	
	// 载入本地帐号信息
	private void loadAccountInfo()
	{
		boolean checked = localInfo.get("acceptLtMessage").equals("true");
		acceptLtMessage = checked;
		com.ToggleButton("ltpay_toggleButton").setChecked(checked);
	}
	
	public void OnBack(View view)
	{
		this.finish();
		LtSDK.ShowActivityCenter();
	}
	
	ClickListener listener = new ClickListener()
	{
		@Override
		public void Click(String viewId)
		{
			if (viewId.equals("ltpay_nickname"))
			{
				Tools.ShowActivity(Instance, ResetNickname.class);
				Instance.finish();
			}
			else if (viewId.equals("ltpay_photo") || viewId.equals("ltpay_userphoto"))
			{
				Tools.ShowActivity(Instance, ResetPhoto.class);
				Instance.finish();
			}
			else if (viewId.equals("ltpay_password"))
			{
				Tools.ShowActivity(Instance, ResetPassword.class, "ResetByPassword", "true");
			}
			else if (viewId.equals("ltpay_phone"))
			{
				Tools.showToast(Instance, "暂不支持手机号修改");
			}
			else if (viewId.equals("ltpay_loginout"))
			{
				if (UserCenter.Instance != null) UserCenter.Instance.finish();
				if (LtSDK.LoginOutCallBack != null) LtSDK.LoginOutCallBack.OnSuccess();
				
				Instance.finish();
				FloatService.HideFloat();
				
				Tools.showToast(Instance, "已退出当前登录帐号");
			}
			else if (viewId.equals("ltpay_toggleButton"))
			{
				// 记录当前选中状态
				boolean isChecked = com.ToggleButton("ltpay_toggleButton").isChecked();
				acceptLtMessage = isChecked;
				localInfo.put("acceptLtMessage" , isChecked ? "true" : "false");
				
				if ( LtSDK.AcceptMessageCallBack != null) 
				{
					if(isChecked) LtSDK.AcceptMessageCallBack.OnSuccess();
					else LtSDK.AcceptMessageCallBack.Onfail();
				}
			}
		}
	};
}
