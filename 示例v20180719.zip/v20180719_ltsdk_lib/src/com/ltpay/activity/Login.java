﻿
package com.ltpay.activity;

import java.util.HashMap;

import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.fxlib.util.FJHttp;
import com.fxlib.util.FJThread;
import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.floatView.FloatService;
import com.ltpay.function.CallBack;
import com.ltpay.function.LtpayConfig;
import com.ltpay.function.Preference;
import com.ltpay.function.Tools;


/** Login.java: ----- 2018-5-15 下午5:23:18 wangzhongyuan */
public class Login extends Activity
{
	private Activity Instance;
	Preference localInfo;
	
	EditText userName;		// 用户名
	EditText passWord;		// 密码
	ImageView ShowPassword;	// 显示隐藏密码
	
	Button LoginBtn;		// 登录
	TextView RegisterBtn;	// 注册账号
	TextView ForgetBtn;		// 忘记密码
	
	boolean showPassword = false;		// 是否显示密码
	boolean saveAccountInfo = true;		// 是否保存帐号、密码信息
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(ResUtil.getId(this, "ltpay_layout_login", "layout"));
		
		Instance = this;
		
		userName = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit_account", "id"));
		passWord = (EditText) this.findViewById(ResUtil.getId(this, "ltpay_edit_password", "id"));
		ShowPassword = (ImageView) this.findViewById(ResUtil.getId(this, "ltpay_password_eye", "id"));
		
		LoginBtn = (Button) this.findViewById(ResUtil.getId(this, "ltpay_btn_login", "id"));
		RegisterBtn = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_btn_register", "id"));
		ForgetBtn = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_btn_foget", "id"));
		
		ShowPassword.setOnClickListener(clickListener);
		LoginBtn.setOnClickListener(clickListener);
		RegisterBtn.setOnClickListener(clickListener);
		ForgetBtn.setOnClickListener(clickListener);
		
		localInfo = new Preference(this, "LtAccountInfo");
		loadAccountInfo();
	}
	
	// /** 关闭Loading界面 */
	// public static void Hide()
	// {
	// if (Instance != null) Instance.finish();
	// }
	
	// public void onBackPressed()
	// {
	//
	// }
	
	// 设置是否记住帐号密码信息
	private void setSaveState(boolean save)
	{
		saveAccountInfo = save;
		// SaveBtn.setBackgroundResource(ResUtil.getId(this, saveAccountInfo ? "jmpay_mch_checkbox_pressed" : "jmpay_mch_checkbox_normal", "drawable"));
	}
	
	// 保存帐号信息
	private void SaveAccountInfo(/* String uname, String password */)
	{
		String uname = userName.getText().toString();
		String password = passWord.getText().toString();
		
		localInfo.put("isSaved", saveAccountInfo + "");
		if (saveAccountInfo)
		{
			localInfo.put("uname", uname);
			localInfo.put("password", password);
		}
		else
		{
			localInfo.put("uname", "");
			localInfo.put("password", "");
		}
	}
	
	// 载入本地帐号信息
	private void loadAccountInfo()
	{
		boolean isSaved = localInfo.get("isSaved").equals("true");
		setSaveState(isSaved);	// 显示是否保存帐号
		
		if (uname.equals(""))	// 若帐号为空则载入本地配置帐号信息
		{
			uname = localInfo.get("uname");
			password = localInfo.get("password");
		}
		
		userName.setText(uname);
		passWord.setText(password);
	}
	
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			if (v == ShowPassword)
			{
				showPassword = !showPassword;
				if (showPassword)
					passWord.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
				else passWord.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
			// else if (v == SaveBtn || v == SaveLabel)
			// {
			// setSaveState(!saveAccountInfo);
			// SaveAccountInfo(); // 记录帐号信息
			// }
			else if (v == LoginBtn)
			{
				uname = userName.getText().toString();
				password = passWord.getText().toString();
				
				// Payment.getInstance().UserLogin(name, password, call)
				loginCallBack = LtSDK.LoginCallBack;
				UserLogin(uname, password, loginCallBack);
				
				setSaveState(true);						// 记录用户账号信息
				SaveAccountInfo();						// 记录帐号信息
			}
			else if (v == RegisterBtn)
			{
				Tools.ShowActivity(Instance, Register.class); // 跳转注册界面
				Instance.finish();
			}
			else if (v == ForgetBtn)
			{
				Tools.ShowActivity(Instance, PasswordRecover_account.class);
				Instance.finish();
			}
		}
	};
	
	// -----------------------------------
	
	private CallBack loginCallBack;	// 登录回调逻辑
	
	// 乐堂登录，获取到用户信息
	public static String login_msg = "";	// 登录服务器返回信息
	public static String uid = "";			// 用户id
	public static String uname = "";		// 用户名称
	public static String nname = "";		// 名称
	public static String reg_date = "";		// 注册时间
	public static String token = "";		// token
	public static String ip = "";			// ip
	public static String password = "";		// 密码
	
	public static boolean isLoginSuccess = false;	// 记录当前是否登录成功
	
	/** 检测是否已登录成功，若未登录，则自动调出登录 */
	public static boolean checkLogin(Context context)
	{
		if (isLoginSuccess) Tools.ShowActivity(context, Login.class);
		return isLoginSuccess;
	}
	
	/** 乐堂用户登录 */
	public void UserLogin(final String name, final String password, final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(Instance, "/User/login");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uname", name);
					map.put("password", password);
					map.put("SubChannelId", LtSDK.SubChannelId);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "乐堂用户登录 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "登录返回信息 ->> " + rdata);
					// 登录返回信息 ->>
					// {"status":1,"msg":"\u767b\u5f55\u6210\u529f","content":{"uid":"5667094","uname":"6t1bxiyq","nname":"6t1bxiyq","reg_date":"2018-03-09 09:25:22","token":"0d6af827e1c6d786aea25692eb479f2e","ip":"218.104.71.178"}}
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					login_msg = userJson.getString("msg");
					
					switch (status)
					{
						case 200:		// 登录成功
							JSONObject contentJson = userJson.getJSONObject("data");
							
							uid = contentJson.getString("uid");			// 乐堂用户ID
							uname = contentJson.getString("uname");
							nname = contentJson.getString("nname");
							reg_date = contentJson.getString("reg_date");
							token = contentJson.getString("token");
							ip = contentJson.getString("ip");
							
							isLoginSuccess = true;
							if (call != null) call.OnSuccess();
							Tools.showText("乐堂用户登录成功" + "，用户名: " + uname + "，用户ID: " + uid);
							Tools.ShowActivity(Instance, LoginSuccess.class);
							FloatService.ShowFloat(Instance);
							
							Instance.finish();	// 登录成功，关闭当前Activity
							break;
						
						default:	// 登录失败
							// Log.d(TAG, "乐堂用户登录失败！" + login_msg);
							Tools.showToast(Instance, "乐堂用户登录失败！" + login_msg);
							
							isLoginSuccess = false;
							if (call != null) call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(Instance, "乐堂用户登录异常！");
					ex.printStackTrace();
					if (call != null) call.Onfail();
				}
			}
		});
	}
	
}
