﻿
package com.ltpay.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack2;
import com.ltpay.function.ListViewCommonAdapter;
import com.ltpay.function.Server;


/** ChargeRecord.java:充值记录界面 ----- 2018-6-8 上午11:47:18 wangzhongyuan */
public class ChargeRecord extends Activity
{
	private Activity Instance;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_activity_center", "layout"));
		TextView tittle = (TextView) Instance.findViewById(ResUtil.getId(Instance, "ltpay_text_tittle", "id"));
		tittle.setText("充值记录");
		
		// SetCenterContent();
		InitContent();
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	private void InitContent()
	{
		// String uid = "1024514841";
		String uid = Login.uid;
		Server.GetChargeRecodeList(this, uid, call);	// 获取活动中心数据
	}
	
	CallBack2 call = new CallBack2()
	{
		@Override
		public void Onfail(Object... data)
		{}
		
		@Override
		public void OnSuccess(Object... data)
		{
			ChargeRecord_T[] datas = (ChargeRecord_T[]) data;
			ShowInListView(datas);
		}
	};
	
	// 设置活动中心内容信息
	private void ShowInListView(final ChargeRecord_T[] datas)
	{
		runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				ChargeRecordAdapter adapter = new ChargeRecordAdapter(Instance, "ltpay_layout_activity_center_listiteam_charge", datas);
				ListView list = adapter.getListView();	 // 生成listView
				
				// 获取content
				int Id = ResUtil.getId(Instance, "ltpay_content", "id");
				LinearLayout content = (LinearLayout) Instance.findViewById(Id);
				
				content.addView(list);	// 添加listView为显示内容页
			}
		});
	}
	
}


class ChargeRecordAdapter extends ListViewCommonAdapter<ChargeRecord_T>
{
	/** 指定context、列表项布局、列表项数据 */
	public ChargeRecordAdapter(Context context, String layoutName, ChargeRecord_T[] IteamDatas)
	{
		super(context, layoutName, IteamDatas);
	}
	
	/** 设置list列表项内容 */
	@Override
	public void setIteamView(View iteamView, ChargeRecord_T iteamData)
	{
		TextView text1 = (TextView) getIteamView(iteamView, "ltpay_text1");
		text1.setText(iteamData.chargeTime);	// 充值时间
		
		TextView text2 = (TextView) getIteamView(iteamView, "ltpay_text2");
		text2.setText(iteamData.appName);		// 应用名称
		
		TextView text3 = (TextView) getIteamView(iteamView, "ltpay_text3");
		text3.setText("￥ " + iteamData.money);	// 金额
	}
	
	/** 设置list列表项点击响应处理逻辑 */
	@Override
	public void setIteamClick(Context iteamContext, ChargeRecord_T iteamData)
	{
		// Link.http(iteamContext, iteamData.url); // 打开该列表项对应的网址
		// Tools.ShowActivity(iteamContext, ActivityCenter_detail.class, "tittle", iteamData.Title, "url", iteamData.url);
	}
}
