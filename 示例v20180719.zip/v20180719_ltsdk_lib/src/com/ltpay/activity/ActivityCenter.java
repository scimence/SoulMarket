﻿
package com.ltpay.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.function.CallBack2;
import com.ltpay.function.ListViewCommonAdapter;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** ActivityCenter.java:用户活动中心 ----- 2018-5-29 下午4:40:49 wangzhongyuan */
public class ActivityCenter extends Activity
{
	
	private Activity Instance;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_activity_center", "layout"));
		
		// SetCenterContent();
		InitContent();
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	protected void InitContent()
	{
		// String appId = "1001";
		// String channelId = "9999999";
		
		Server.GetActivityList(this, LtSDK.AppId, /* channelId, */call);	// 获取活动中心数据
	}
	
	CallBack2 call = new CallBack2()
	{
		@Override
		public void Onfail(Object... data)
		{}
		
		@Override
		public void OnSuccess(Object... data)
		{
			ActivityCenter_T[] datas = (ActivityCenter_T[]) data;
			ShowInListView(datas);
		}
	};
	
	// 设置活动中心内容信息
	private void ShowInListView(final ActivityCenter_T[] datas)
	{
		runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				ActivityCenterAdapter adapter = new ActivityCenterAdapter(Instance, "ltpay_layout_activity_center_listiteam", datas);
				ListView list = adapter.getListView();	 // 生成listView
				
				// 获取content
				int Id = ResUtil.getId(Instance, "ltpay_content", "id");
				LinearLayout content = (LinearLayout) Instance.findViewById(Id);
				
				content.addView(list);	// 添加listView为显示内容页
			}
		});
	}
	
}


class ActivityCenterAdapter extends ListViewCommonAdapter<ActivityCenter_T>
{
	/** 指定context、列表项布局、列表项数据 */
	public ActivityCenterAdapter(Context context, String layoutName, ActivityCenter_T[] IteamDatas)
	{
		super(context, layoutName, IteamDatas);
	}
	
	/** 设置list列表项内容 */
	@Override
	public void setIteamView(View iteamView, ActivityCenter_T iteamData)
	{
		TextView text = (TextView) getIteamView(iteamView, "ltpay_text");
		text.setText(iteamData.Title);
	}
	
	/** 设置list列表项点击响应处理逻辑 */
	@Override
	public void setIteamClick(Context iteamContext, ActivityCenter_T iteamData)
	{
		// Link.http(iteamContext, iteamData.url); // 打开该列表项对应的网址
		Tools.ShowActivity(iteamContext, ActivityCenter_detail.class, "tittle", iteamData.Title, "url", iteamData.url, "content", iteamData.content);
	}
}


final class Link
{
	// 访问网页如： url = "http://google.com"
	public static void http(Context context, String url)
	{
		Uri uri = Uri.parse(url);
		Intent it = new Intent(Intent.ACTION_VIEW, uri);
		context.startActivity(it);
	}
}
