﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.function.CallBackF;
import com.ltpay.function.Tools;


/** Loading.java:载入界面 ----- 2018-5-15 上午11:39:25 wangzhongyuan */
public class Loading extends Activity
{
	private static Activity Instatnce;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instatnce = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_loading", "layout"));
		
		CallBackF call = new CallBackF()
		{
			@Override
			public void F()
			{
				Instatnce.finish();
				Tools.ShowActivity(Instatnce, Announcement.class, "appId", LtSDK.AppId);
			}
		};
		Tools.AutoHide(Instatnce, 3000, call);
	}
}
