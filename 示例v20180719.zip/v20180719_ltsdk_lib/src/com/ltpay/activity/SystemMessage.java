﻿
package com.ltpay.activity;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.function.Server;
import android.widget.TextView;


/** SystemMessage.java: ----- 2018-6-25 上午9:23:03 wangzhongyuan */
public class SystemMessage extends ActivityCenter
{
	
	protected void InitContent()
	{
		// String appId = "1001";
		// String channelId = "9999999";
		
		int id = ResUtil.getId(this, "ltpay_text_tittle", "id");
		TextView text = (TextView) (this.findViewById(id));
		text.setText("系统消息");
		
		Server.GetSystemMessageList(this, LtSDK.AppId, /* channelId, */call);	// 获取活动中心数据
	}
}
