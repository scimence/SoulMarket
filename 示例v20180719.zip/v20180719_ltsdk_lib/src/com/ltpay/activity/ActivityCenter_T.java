﻿
package com.ltpay.activity;



/** ActivityCenter_ListIteamData.java: ----- 2018-6-7 下午3:19:02 wangzhongyuan */
// 定义该结构用于表示列表项的数据结构
public class ActivityCenter_T
{
	public String id, Title, url, content;
	
	ActivityCenter_T()
	{};
	
	public ActivityCenter_T(String... data)
	{
		this.id = data[0];
		this.Title = data[1];
		this.url = data[2];
		this.content = data[3];
	}
}


