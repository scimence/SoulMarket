﻿
package com.ltpay.activity;

/** ChargeRecord_T.java: 充值记录数据格式 ----- 2018-6-8 上午11:48:36 wangzhongyuan */
public class ChargeRecord_T
{
	public String id, chargeTime, appName, money;
	
	ChargeRecord_T()
	{};
	
	public ChargeRecord_T(String... data)
	{
		this.id = data[0];
		this.chargeTime = data[1];
		this.appName = data[2];
		this.money = data[3];
	}
}
