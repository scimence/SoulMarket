﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBackF;
import com.ltpay.function.Tools;


/** LoginSuccess.java: ----- 2018-5-24 下午3:27:19 wangzhongyuan */
public class LoginSuccess extends Activity
{
	private Activity Instance;
	TextView text;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_login_success", "layout"));
		text = (TextView) this.findViewById(ResUtil.getId(this, "ltpay_text", "id"));
		
		text.setText(Login.uname);
		
		CallBackF call = new CallBackF()
		{
			@Override
			public void F()
			{
				// Tools.ShowActivity(Instance, Announcement.class);
				RealName.Show(Instance, "1001", Login.uid, null);
			}
		};
		
		Tools.AutoHide(Instance, 2000, call);
	}
	
}
