﻿
package com.ltpay.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.Component;
import com.ltpay.function.Component.ClickListener;


/** ActivityCenter_details.java: ----- 2018-6-7 下午5:13:21 wangzhongyuan */
public class ActivityCenter_detail extends Activity
{
	private static Activity Instance;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_activity_center_detail", "layout"));
		
		Component com = new Component(this, new ClickListener()
		{
			@Override
			public void Click(String viewId)
			{
				if (viewId.equals("ltpay_btn"))
				{
					Instance.finish();
				}
			}
		}, "ltpay_btn");
		
		Bundle extra = this.getIntent().getExtras();
		
		String tittle = extra.getString("tittle", "活动详情标题");
		String url = extra.getString("url", "");
		String content = extra.getString("content", "");
		
		// 设置标题
		com.TextView("ltpay_text_tittle").setText(tittle);
		
		// 设置活动显示内容
		TextView body = com.TextView("ltpay_text_body");
		WebView webview = (WebView) com.GetView("ltpay_webview");
		
		if(!content.equals(""))
		{
			body.setText(content);	// 设置显示内容
			webview.setVisibility(View.INVISIBLE);
		}
		else if(!url.equals(""))
		{
			body.setText("");
			body.setVisibility(View.INVISIBLE);
			
			webview.loadUrl(url);	// 载入web页信息
		}
		else
		{
			body.setVisibility(View.INVISIBLE);
			webview.setVisibility(View.INVISIBLE);
		}
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
}
