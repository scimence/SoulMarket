﻿
package com.ltpay.activity;

import java.util.HashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import com.fxlib.util.FAApk;
import com.joymeng.payment.channel.Alipay;
import com.joymeng.payment.channel.Iapppay;
import com.joymeng.payment.channel.Unionpay;
import com.joymeng.payment.core.DialogCallback;
import com.joymeng.payment.core.PaymentKey;
import com.joymeng.payment.core.ShenzhoufuDialog;
import com.joymeng.payment.core.YeepayDialog;
import com.joymeng.payment.util.AndroidUtil;
import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.function.CallBack;
import com.ltpay.function.CallBack2;
import com.ltpay.function.Component;
import com.ltpay.function.LtpayConfig;
import com.ltpay.function.Component.ClickListener;
import com.ltpay.function.Preference;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;


/** PayPage.java: ----- 2018-6-11 上午11:22:27 wangzhongyuan */
public class PayPage extends Activity
{
	// private static final String ORDER_URL = "http://netuser.joymeng.com/order/jmpay";
	private static final String ORDER_URL = "http://10.80.5.71:88/Order/jmpay";
	private static HashMap<String, String> payInfo;
	
	public static void ShowPay(Context context, HashMap<String, String> payInfo)
	{
		PayPage.payInfo = payInfo;
		
		String ORDER_URL = LtpayConfig.URL(context, "/Order/jmpay");
		
		// 创建订单地址
		payInfo.put(PaymentKey.PRIV_ORDER_URL, ORDER_URL);
		
		if (!AndroidUtil.isNetworkAvaliable(context))
		{
			AndroidUtil.printToast(context, "网络不可用，请检查网络");
			return;
		}
		
		Intent intent = new Intent(context, PayPage.class);		// 新的支付调用逻辑
		intent.putExtra("payInfo", payInfo);
		context.startActivity(intent);
	}
	
	// ------------------------------------------------
	
	private static Activity Instance;
	Component com;
	
	int payType = 1;	// 记录当前选中的方式
	Preference localInfo;
	
	private HashMap<String, String> mPayInfo;	// 支付参数信息
	
	Double MoneyAmount = 0.0; 				// 商品价格
	Double couponAmount = 0.0; 				// 优惠券金额
	
	Double RealPayMoneyFloat = 0.0;			// 实际需要支付支付的金额
	
	String appId = "";						// 应用id
	String productId = "001"; 				// 商品id
	String productName = "商品XXX"; 			// 商品名称
	
	@SuppressWarnings("unchecked")
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		if (!Login.isLoginSuccess)	// 若未登录，则先跳转登录
		{
			Instance.finish();
			Tools.ShowActivity(Instance, Login.class);
			return;
		}
		
		localInfo = new Preference(this, "LtAccountInfo");
		
		// 获取支付相关参数
		Intent intent = getIntent();
		mPayInfo = (HashMap<String, String>) intent.getSerializableExtra("payInfo");
		if (mPayInfo == null)
		{
			if (PayPage.payInfo != null)
				mPayInfo = PayPage.payInfo;
			else
			{
				Tools.showToast(Instance, "无支付相关参数，退出当前支付调用");
				return;
			}
		}
		
		if (mPayInfo.containsKey(PaymentKey.ProductId)) productId = mPayInfo.get(PaymentKey.ProductId);
		if (mPayInfo.containsKey(PaymentKey.ProductName)) productName = mPayInfo.get(PaymentKey.ProductName);
		if (mPayInfo.containsKey(PaymentKey.MoneyAmount)) MoneyAmount = Double.parseDouble(mPayInfo.get(PaymentKey.MoneyAmount)) / 100.0;
		if (mPayInfo.containsKey(PaymentKey.LtAppId)) appId = mPayInfo.get(PaymentKey.LtAppId);
		
		mPayInfo.put(PaymentKey.ProductMoney, Tools.FormatMoneyStr(MoneyAmount));	// 商品金额
		
		// 初始化界面显示
		// setTheme(android.R.style.Theme_Light_NoTitleBar_Fullscreen); // 设置Theme
		boolean isLandscape = Tools.isLandscape(getApplicationContext());	// 是否为横屏
		setRequestedOrientation(isLandscape ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		
		setContentView(ResUtil.getId(this, "ltpay_layout_pay", "layout"));
		
		// 初始化控件信息
		com = new Component(Instance, listener, "ltpay_more_paytype", "ltpay_btn", "ltpay_iteam_others");
		
		com.AddView("ltpay_product", "ltpay_money", "ltpay_coupon", "ltpay_money_need");
		com.AddView("ltpay_iteam1", "ltpay_iteam2", "ltpay_iteam3", "ltpay_iteam4", "ltpay_iteam5", "ltpay_iteam6");
		com.AddView("ltpay_radioButton1", "ltpay_radioButton2", "ltpay_radioButton3", "ltpay_radioButton4", "ltpay_radioButton5", "ltpay_radioButton6");
		
		loadPrePayType();	// 设置支付类型
		checkCoupon();		// 设置优惠券信息
		setProductInfo();	// 设置显示的商品信息
	}
	
	/** 设置商品信息 */
	private void setProductInfo()
	{
		com.TextView("ltpay_product").setText(productName);
		
		String ProductMoney = Tools.FormatMoneyStr(MoneyAmount);
		String RealPayMoney = Tools.FormatMoneyStr(MoneyAmount - couponAmount);
		RealPayMoneyFloat = Double.parseDouble(RealPayMoney);
		
		com.TextView("ltpay_money").setText("￥ " + ProductMoney);
		
		// String couponTip = (couponAmount > 0 ? ("￥ " + Tools.FormatMoneyStr(couponAmount) + "优惠券") : "有可用优惠券");
		// com.TextView("ltpay_coupon").setText(couponTip);
		
		com.TextView("ltpay_money_need").setText("￥ " + RealPayMoney);
	}
	
	/** 检测是否有可用的优惠券 */
	private void checkCoupon()
	{
		if (Coupon.SelectedCoupon != null)	// 若存在已选择的优惠券，则显示选择的优惠券信息
		{
			couponAmount = Coupon.SelectedCoupon.Deductible(MoneyAmount);	// 获取当前商品的抵扣金额
			SetCouponInfo(Coupon.SelectedCoupon.ToString());				// 显示抵扣券信息
			mPayInfo.put(PaymentKey.CouponId, Coupon.SelectedCoupon.id);	// 记录选择的优惠券
		}
		else
		{
			mPayInfo.put(PaymentKey.CouponId, "");		// 记录选择的优惠券
			
			CallBack call = new CallBack()
			{
				@Override
				public void Onfail()
				{
					SetCouponInfo("暂无可用优惠券");
				}
				
				@Override
				public void OnSuccess()
				{
					SetCouponInfo("有可用优惠券");
				}
			};
			
			Coupon.CheckCoupon(Instance, appId, Login.uid, productId, productName, MoneyAmount + "", call);	// 检测是否有可用的优惠券
		}
	}
	
	// 设置优惠券显示信息
	private void SetCouponInfo(final String info)
	{
		runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				com.TextView("ltpay_coupon").setText(info);
			}
		});
	}
	
	/** 载入之前的支付类型设置 */
	private void loadPrePayType()
	{
		String LastPayType = localInfo.get("LastPayType");
		if (!LastPayType.equals("")) payType = Integer.parseInt(LastPayType);
		
		setPayType(payType + "");	// 设置为对应的支付类型
		if (payType > 3) listener.Click("ltpay_more_paytype");	// 显示更多支付类型
	}
	
	public void OnBack(View view)
	{
		this.finish();
	}
	
	public void finish()
	{
		Coupon.SelectedCoupon = null;	// 清除选择的优惠券信息
		super.finish();
	}
	
	/** 设置当前选中的支付方式 */
	private void setPayType(String viewId)
	{
		for (int i = 1; i <= 6; i++)
		{
			boolean isSelect = (viewId.equals("ltpay_iteam" + i) || viewId.equals("ltpay_radioButton" + i) || viewId.equals(i + ""));
			
			com.RadioButton("ltpay_radioButton" + i).setChecked(isSelect);
			if (isSelect) payType = i;
		}
	}
	
	ClickListener listener = new ClickListener()
	{
		@Override
		public void Click(String viewId)
		{
			if (viewId.equals("ltpay_coupon"))				// 显示优惠券信息页
			{
				// Tools.showToast(Instance, "暂无优惠券");
				Coupon.Show(Instance, appId, Login.uid, productId, productName, MoneyAmount + "");
				Instance.finish();
			}
			else if (viewId.equals("ltpay_more_paytype"))	// 更多支付方式
			{
				com.TextView("ltpay_more_paytype").setVisibility(View.INVISIBLE);
				com.LinearLayout("ltpay_iteam_others").setVisibility(View.VISIBLE);	// 显示其他支付方式
			}
			else if (viewId.equals("ltpay_btn"))
			{
				localInfo.put("LastPayType", payType + "");	// 记录当前选中的支付方式
				// payLogic();
				
				payWithBalance();
				
			}
			else if (viewId.startsWith("ltpay_iteam") || viewId.startsWith("ltpay_radioButton"))
			{
				setPayType(viewId);
			}
		}
	};
	
	private void payWithBalance()
	{
		CallBack2 call = new CallBack2()
		{
			
			@Override
			public void Onfail(Object... data)
			{
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void OnSuccess(Object... data)
			{
				// float balance = Float.parseFloat(data[0].toString());
				final double balance = Double.parseDouble(data[0].toString());
				// float balance = 9999.99f;
				Log.d("ltpay", "balance double:" + balance + "");
				
				// final Double balanceD = Double.parseDouble(data[0].toString());
				// Log.d("ltpay", "balanceD 100:" + (balanceD * 100) + "");
				// Log.d("ltpay", "balanceD:" + balanceD + "");
				
				// final float balance = Float.parseFloat(data[0].toString());
				if (balance > 0)
				{
					FAApk.getMainHandler().post(new Runnable()
					{
						@Override
						public void run()
						{
							AlertDialog.Builder dialog = new AlertDialog.Builder(Instance);
							
							dialog.setTitle("是否使用余额进行支付？");
							dialog.setMessage("您当前可用余额为：" + "\r\n" + "￥ " + balance);
							dialog.setIcon(android.R.drawable.ic_dialog_info);
							dialog.setPositiveButton("使用", new DialogInterface.OnClickListener()
							{
								@Override
								public void onClick(DialogInterface dialog, int which)
								{
									payLogic(balance);
								}
							});
							
							dialog.setNegativeButton("不使用", new DialogInterface.OnClickListener()
							{
								
								@Override
								public void onClick(DialogInterface dialog, int which)
								{
									payLogic(0);
								}
							});
							
							dialog.show();
						}
					});
				}
				else
				{
					payLogic(0);
				}
				
			}
		};
		
		Server.getBalance(Instance, Login.uid, call);	// 获取余额信息
	}
	
	// 支付逻辑
	private void payLogic(double balance)
	{
		// 调用对应支付方式
		int NeedMoney = 0;
		double balanceCounsume = 0;
		
		if (RealPayMoneyFloat >= balance)
		{
			NeedMoney = (int) ((RealPayMoneyFloat - balance) * 100);
			balanceCounsume = balance;
		}
		else
		{
			NeedMoney = 0;
			balanceCounsume = RealPayMoneyFloat;
		}
		
		// ------------
		
		mPayInfo.put(PaymentKey.MoneyAmount, NeedMoney + "");
		
		mPayInfo.put(PaymentKey.BalanceCounsume, Tools.FormatMoneyStr(balanceCounsume));	// 消费余额数
		mPayInfo.put(PaymentKey.UserPassword, Login.password);			// 用户密码
		
		pay(payType, mPayInfo);
		
		Instance.finish();
	}
	
	// -----------------
	
	public static String LtOrderId = "";		// 记录创建订单时的乐堂订单号
	
	/** 返回支付成功，调用支付成功回调接口 */
	public static void PaySuccess(final Context context)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				Tools.ShowActivity(context, PaySuccess.class);
				if (LtSDK.PayCallBack != null) LtSDK.PayCallBack.OnSuccess();
			}
		});
	}
	
	/** 返回支付失败或取消，调用支付失败回调接口 */
	public static void PayFail(final Context context)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				if (!LtOrderId.equals(""))
				{
					Server.OrderFail(context, Login.uid, LtOrderId, null);	// 通知服务器指定的订单已取消
				}
				LtOrderId = "";
				
				// Tools.ShowActivity(context, PaySuccess.class);
				if (LtSDK.PayCallBack != null) LtSDK.PayCallBack.Onfail();
			}
		});
	}
	
	/** 调用支付逻辑进行支付 */
	private void pay(int payType, HashMap<String, String> mPayInfo)
	{
		if (payType == 1)
			Alipay.Pay(LtSDK.context, mPayInfo);
		else if (payType == 2)
			Iapppay.Pay(LtSDK.context, mPayInfo);
		else if (payType == 3)
			Unionpay.Pay(LtSDK.context, mPayInfo);
		else if (payType == 4)
			CM_Pay(LtSDK.context, mPayInfo);
		else if (payType == 5)
			Un_Pay(LtSDK.context, mPayInfo);
		else if (payType == 6) Ye_Pay(LtSDK.context, mPayInfo);
	}
	
	public static void AppendPayParams(HashMap<String, String> request)
	{
		request.put("SubChannelId", LtSDK.SubChannelId);	// 预留字段子渠道号
	}
	
	// 移动支付
	private void CM_Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String type = "YD";
					Dialog dialog = new ShenzhoufuDialog(mActivity, mPayInfo, new DialogCallback()
					{
						@Override
						public void onCallback(String type, Object data)
						{}
					}, type);
					
					dialog.show();
				}
				catch (Exception ex)
				{
					Tools.showToast(mActivity, "移动支付异常");
					ex.printStackTrace();
				}
			}
		});
	}
	
	// 联通支付
	private void Un_Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String type = "LT";
					Dialog dialog = new ShenzhoufuDialog(mActivity, mPayInfo, new DialogCallback()
					{
						@Override
						public void onCallback(String type, Object data)
						{}
					}, type);
					
					dialog.show();
				}
				catch (Exception ex)
				{
					Tools.showToast(mActivity, "联通支付异常");
					ex.printStackTrace();
				}
			}
		});
	}
	
	// 易宝支付
	private void Ye_Pay(final Activity mActivity, final HashMap<String, String> mPayInfo)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					Dialog dialog = new YeepayDialog(mActivity, mPayInfo, new DialogCallback()
					{
						@Override
						public void onCallback(String type, Object data)
						{}
					});
					dialog.show();
				}
				catch (Exception ex)
				{
					Tools.showToast(mActivity, "易宝支付异常");
					ex.printStackTrace();
				}
			}
		});
	}
}
