﻿
package com.ltpay.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;

import com.fxlib.util.FAApk;
import com.joymeng.payment.util.ResUtil;


/** userprotocal.java: ----- 2018-5-24 上午10:22:41 wangzhongyuan */
public class UserProtocal extends Activity
{
	private static Activity Instance;
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_userprotocal", "layout"));
		
		// 载入web页信息
		int id = ResUtil.getId(Instance, "ltpay_userprotocal_webview", "id");
		WebView webview = (WebView) this.findViewById(id);
		
		String url = "https://gitee.com/joymeng/empty/raw/master/ltsdk/UserProtocal.txt";
		webview.loadUrl(url);
	}

	public void OnBack(View view)
	{
		this.finish();
	}
	
	/** 显示界面 */
	public static void Show(final Context context)
	{
		FAApk.getMainHandler().post(new Runnable()
		{
			@Override
			public void run()
			{
				Intent intent = new Intent(context, UserProtocal.class);
				context.startActivity(intent);
			}
		});
	}
	
	/** 关闭Loading界面 */
	public static void Hide()
	{
		if (Instance != null) Instance.finish();
	}
	
	// public void onBackPressed()
	// {
	//
	// }
}
