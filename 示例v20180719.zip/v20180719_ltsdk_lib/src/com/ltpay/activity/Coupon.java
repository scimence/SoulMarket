﻿
package com.ltpay.activity;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.function.CallBack;
import com.ltpay.function.CallBack2;
import com.ltpay.function.CallBackF;
import com.ltpay.function.Component;
import com.ltpay.function.ListViewCommonAdapter;
import com.ltpay.function.Server;
import com.ltpay.function.Tools;
import com.ltpay.function.Component.ClickListener;


/** Coupon.java:优惠券界面 ----- 2018-6-12 上午11:49:10 wangzhongyuan */
public class Coupon extends Activity
{
	/** 显示优惠券界面 */
	public static void Show(Context context, String appId, String uid, String ProductId, String ProductName, String ProductMoney)
	{
		Intent intent = new Intent(context, Coupon.class);		// 新的支付调用逻辑
		
		intent.putExtra("appId", appId);
		intent.putExtra("uid", uid);
		intent.putExtra("ProductId", ProductId);
		intent.putExtra("ProductName", ProductName);
		intent.putExtra("ProductMoney", ProductMoney);
		
		context.startActivity(intent);
	}
	
	//--------------------------------
	
	private Activity Instance;
	
	Coupon_T[] useableCoupon;		// 可用优惠券信息
	Coupon_T[] unuseableCoupon;		// 不可用优惠券信息
	Component com;
	
	public static Coupon_T SelectedCoupon = null;	// 当前选中的优惠券
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Instance = this;
		
		setContentView(ResUtil.getId(this, "ltpay_layout_coupon", "layout"));
		
		com = new Component(Instance, listener, "ltpay_text_useable", "ltpay_text_unuseable", "ltpay_content");
		
		InitContent();
	}
	
	public void OnBack(View view)
	{
		this.finish();
		if(!ProductId.equals("")) Tools.ShowActivity(Instance, PayPage.class);
	}
	
	ClickListener listener = new ClickListener()
	{
		@Override
		public void Click(String viewId)
		{
			if (viewId.equals("ltpay_text_useable"))
			{
				setShowMode(1);
			}
			else if (viewId.equals("ltpay_text_unuseable"))
			{
				setShowMode(2);
			}
		}
	};
	
	String ProductId = "";
	private void InitContent()
	{
		Bundle extras = Instance.getIntent().getExtras();
		if(extras==null)
		{
			Tools.showToast(Instance, "无优惠券相关参数！");
			Instance.finish();
			return;
		}
		
		String appId = extras.getString("appId", "");
		String uid = extras.getString("uid", "");
		ProductId = extras.getString("ProductId", "");
		String ProductName = extras.getString("ProductName", "");
		String ProductMoney = extras.getString("ProductMoney", "");
		
		Server.GetCouponList(this, appId, uid, ProductId, ProductName, ProductMoney, call);	// 获取优惠券
	}
	
	// 优惠券信息回调处理逻辑
	CallBack2 call = new CallBack2()
	{
		@Override
		public void Onfail(Object... data)
		{}
		
		@Override
		public void OnSuccess(Object... datas)
		{
			try
			{
				JSONObject data = (JSONObject) datas[0];				// 获取优惠券信息
				JSONArray useableJ = data.getJSONArray("useable");		// 可用优惠券信息
				JSONArray unuseableJ = data.getJSONArray("unuseable");	// 不可用优惠券信息
				
				useableCoupon = Coupon_T.ToArray(useableJ);				// 解析可用优惠券信息
				unuseableCoupon = Coupon_T.ToArray(unuseableJ);			// 解析不可用优惠券信息
				
				setShowMode(1);
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				Tools.showText("解析可用优惠券信息异常");
			}
			// ShowInListView(datas);
		}
	};
	
	private void setShowMode(int mode)
	{
		int gray = Color.parseColor("#b9b9b9");
		int black = Color.parseColor("#000000");
		
		if (mode == 1)
		{
			com.TextView("ltpay_text_useable").setTextColor(black);
			com.TextView("ltpay_text_unuseable").setTextColor(gray);
			if (useableCoupon != null) ShowInListView(useableCoupon, true);
		}
		else
		{
			com.TextView("ltpay_text_useable").setTextColor(gray);
			com.TextView("ltpay_text_unuseable").setTextColor(black);
			if (unuseableCoupon != null) ShowInListView(unuseableCoupon, false);
		}
	}
	
	// 设置活动中心内容信息
	private void ShowInListView(final Coupon_T[] datas, final boolean useable)
	{
		runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				CallBackF call = new CallBackF()
				{
					@Override
					public void F()
					{
						if(!ProductId.equals(""))
						{
							Tools.ShowActivity(Instance, PayPage.class);
							Instance.finish();
						}
						else
						{
							Tools.showToast(Instance, "优惠券，可在游戏支付时，选择使用");
							SelectedCoupon = null;
						}
					}
				};
				
				// 获取content控件
				int Id = ResUtil.getId(Instance, "ltpay_content", "id");
				LinearLayout content = (LinearLayout) Instance.findViewById(Id);
				
				// 生成优惠券信息
				CouponAdapter adapter = new CouponAdapter(Instance, "ltpay_layout_coupon_listiteam", datas, useable, call);
				ListView list = adapter.getListView();	// 生成listView
				list.setDividerHeight(0);				// 设置分割线尺寸
				
				// 在content中显示优惠券信息
				content.removeAllViews();
				content.addView(list);					// 添加listView为显示内容页
			}
		});
	}
	
	
	/** 检测当前是否有可用的优惠券 */
	public static void CheckCoupon(Context context, String appId, String uid, String ProductId, String ProductName, String ProductMoney, 
			final CallBack checkCall)
	{
		CallBack2 call = new CallBack2()
		{
			@Override
			public void Onfail(Object... data)
			{}
			
			@Override
			public void OnSuccess(Object... datas)
			{
				if (checkCall != null)
				{
					try
					{
						JSONObject data = (JSONObject) datas[0];				// 获取优惠券信息
						JSONArray useableJ = data.getJSONArray("useable");		// 可用优惠券信息
						
						Coupon_T[] useableCoupon = Coupon_T.ToArray(useableJ);	// 解析可用优惠券信息
						
						if (useableCoupon.length > 0)	// 有可用优惠券
							checkCall.OnSuccess();
						else checkCall.Onfail();		// 无可用优惠券
					}
					catch (Exception ex)
					{
						ex.printStackTrace();
						Tools.showText("解析可用优惠券信息异常");
						checkCall.Onfail();
					}
				}
			}
		};
		
		Server.GetCouponList(context, appId, uid, ProductId, ProductName, ProductMoney, call);	// 获取优惠券
	}
}


// 定义该结构用于表示列表项的数据结构
class Coupon_T
{
	public String id, value_type, value, limit;
	
	Coupon_T()
	{};
	
	public Coupon_T(String... data)
	{
		this.id = data[0];
		this.value_type = data[1];
		this.value = data[2];
		this.limit = data[3];
	}
	
	// 从Json对象创建
	public Coupon_T(JSONObject obj)
	{
		this.id = obj.optString("cid", "");
		this.value_type = obj.optString("value_type", "");
		this.value = obj.optString("value", "");
		this.limit = obj.optString("limit", "");
	}
	
	// ---------------------------------
	
	// 从Json数组解析数据
	public static Coupon_T[] ToArray(JSONArray data)
	{
		Coupon_T[] Array = new Coupon_T[data.length()];
		
		for (int i = 0; i < data.length(); i++)
		{
			try
			{
				JSONObject obj = data.getJSONObject(i);
				Array[i] = new Coupon_T(obj);
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
				Tools.showText("优惠券数据Coupon_T解析异常!");
			}
		}
		return Array;
	}
	
	// 获取折扣券类型
	public String TypeString()
	{
		if (value_type.equals("0"))
			return "现金抵用券";
		else if (value_type.equals("1"))
			return "现金折扣券";
		else return "(" + value_type + ")折扣券";
	}
	
	// 获取对应的显示值
	public String ValueString()
	{
		if (value_type.equals("0"))
			return "￥" + value;
		else if (value_type.equals("1"))
		{
			float v = Float.parseFloat(value);
			return Tools.FormatDiscount(v * 10) + " 折";
		}
		else return value;
	}
	
	// 获取优惠券的字符串形式
	public String ToString()
	{
		return TypeString() + " " + ValueString();
	}
	
	// 根据商品价格、优惠券类型计算抵扣金额
	public double Deductible(double productMoney)
	{
		double couponValue = Double.parseDouble(value);	// 获取优惠券金额
		
		if(value_type.equals("0")) 		// 现金抵用券
		{
			if(productMoney < couponValue) return productMoney;
			else return couponValue;
		}
		else if (value_type.equals("1"))// 折扣券
		{
			if(couponValue >= 1) return 0;
			else return productMoney - productMoney * couponValue;
		}
		else return 0.0;
	}
}


class CouponAdapter extends ListViewCommonAdapter<Coupon_T>
{
	boolean useable = true;
	CallBackF call;				// 回调处理逻辑
	
	/** 指定context、列表项布局、列表项数据 */
	public CouponAdapter(Context context, String layoutName, Coupon_T[] IteamDatas, boolean useable, CallBackF call)
	{
		super(context, layoutName, IteamDatas);
		this.useable = useable;
		this.call = call;
	}
	
	/** 设置list列表项内容 */
	@Override
	public void setIteamView(View iteamView, Coupon_T iteamData)
	{
		TextView text1 = (TextView) getIteamView(iteamView, "ltpay_text1");
		text1.setText(iteamData.TypeString());
		
		TextView text2 = (TextView) getIteamView(iteamView, "ltpay_text2");
		text2.setText(iteamData.ValueString());
		
		TextView text3 = (TextView) getIteamView(iteamView, "ltpay_text3");
		text3.setText(useable ? "选取" : "不可用");
		
		if (!useable)
		{
			RelativeLayout ltpay_layout_bg = (RelativeLayout) getIteamView(iteamView, "ltpay_layout_bg");
			int unuseableColor = Color.parseColor("#c493a2");		// 优惠券不可用背景色
			ltpay_layout_bg.setBackgroundColor(unuseableColor);
		}
	}
	
	/** 设置list列表项点击响应处理逻辑 */
	@Override
	public void setIteamClick(Context iteamContext, Coupon_T iteamData)
	{
		if (useable)
		{	
			Coupon.SelectedCoupon = iteamData;
			if(call != null) call.F();
		}
		else Tools.showToast(iteamContext, "请选择可用的优惠券");
		
		// Link.http(iteamContext, iteamData.url); // 打开该列表项对应的网址
		// Tools.ShowActivity(iteamContext, ActivityCenter_detail.class, "tittle", iteamData.Title, "url", iteamData.url, "content", iteamData.content);
	}
	
}
