﻿
package com.ltpay.function;

/** CallBack.java: ----- 2017-11-15 下午4:38:52 wangzhongyuan */
public interface CallBack
{
	// 成功
	public void OnSuccess();
	
	// 失败
	public void Onfail();
}
