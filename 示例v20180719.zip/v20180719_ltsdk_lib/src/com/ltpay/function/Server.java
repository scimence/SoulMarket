﻿
package com.ltpay.function;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;

import com.fxlib.util.FJHttp;
import com.fxlib.util.FJThread;
import com.ltpay.LtSDK;
import com.ltpay.activity.ActivityCenter_T;
import com.ltpay.activity.ChargeRecord_T;


/** Server.java:服务器接口，用于向服务器发送url请求 ----- 2018-6-5 下午5:45:42 wangzhongyuan */
public class Server
{
	
	/** 调用接口发送验证码 */
	public static void sendCode(final Context context, final String account, final CallBack call, final String mprefix)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/User/sendVcode");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uname", account);
					if (!mprefix.equals("")) map.put("mprefix", mprefix);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "发送验证码 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 发送成功
							call.OnSuccess();
							break;
						
						default:		// 发送失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "发送验证码异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 调用接口验证验证码是否正确 */
	public static void verifyCode(final Context context, final String account, final String code, final String codeType, final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/User/verifyVcode");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uname", account);
					map.put("vcode", code);
					map.put("vtype", codeType);		// 0-注册 1-登录 2-忘记密码
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "验证验证码 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess();
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "验证码验证异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 用户注册 */
	public static void UserRegister(final Context context, final String account, final String password, final String code, final CallBack call,
			final String mprefix)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/User/reg");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uname", account);
					map.put("vcode", code);
					map.put("password", password);
					map.put("password_twice", password);
					map.put("SubChannelId", LtSDK.SubChannelId);
					if (!mprefix.equals("")) map.put("mprefix", mprefix);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "用户注册 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess();
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "用户注册异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 调用接口重置用户密码 */
	public static void resetPassword(final Context context, final String account, final String password, final String code, final String prePassword,
			final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/User/resetPwd");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uname", account);
					if (!code.equals("")) map.put("vcode", code);
					if (!prePassword.equals("")) map.put("prePassword", prePassword);
					map.put("password", password);
					map.put("password_twice", password);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "重置用户密码 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess();
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "重置用户密码异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取公告信息 */
	public static void GetAnnounceMent(final Context context, final String appId, final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/Notice/detail");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("app_id", appId);
					// map.put("channel_id", channelId);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取公告信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					JSONObject data = userJson.getJSONObject("data");
					String id = data.optString("id", "");
					String tittle = data.optString("title", "");
					String content = data.optString("content", "");
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(id, tittle, content);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取公告异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取活动中心信息 */
	public static void GetActivityList(final Context context, final String appId, /* final String channelId, */final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/Activity/lists");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("app_id", appId);
					// map.put("channel_id", channelId);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取活动列表 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					// 解析活动列表信息
					JSONArray data = userJson.getJSONArray("data");			// 获取活动列表数组
					
					ActivityCenter_T[] Array = new ActivityCenter_T[data.length()];
					for (int i = 0; i < data.length(); i++)
					{
						JSONObject obj = data.getJSONObject(i);
						
						String id = obj.optString("id", "");
						String title = obj.optString("title", "");
						String url = obj.optString("url", "");
						// url = "https://gitee.com/joymeng/empty/raw/master/ltsdk/page1.txt";
						String content = obj.optString("content", "");
						
						Array[i] = new ActivityCenter_T(id, title, url, content);
					}
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(Array);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取活动列表异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取系统消息 */
	public static void GetSystemMessageList(final Context context, final String appId, /* final String channelId, */final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/System/lists");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("app_id", appId);
					// map.put("channel_id", channelId);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取活动列表 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					// 解析活动列表信息
					JSONArray data = userJson.getJSONArray("data");			// 获取活动列表数组
					
					ActivityCenter_T[] Array = new ActivityCenter_T[data.length()];
					for (int i = 0; i < data.length(); i++)
					{
						JSONObject obj = data.getJSONObject(i);
						
						String id = obj.optString("id", "");
						String title = obj.optString("title", "");
						String url = obj.optString("url", "");
						// url = "https://gitee.com/joymeng/empty/raw/master/ltsdk/page1.txt";
						String content = obj.optString("content", "");
						
						Array[i] = new ActivityCenter_T(id, title, url, content);
					}
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(Array);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取活动列表异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取优惠券信息 */
	public static void GetCouponList(final Context context, final String appId, final String uid, final String ProductId, final String ProductName,
			final String ProductMoney, final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/Coupon/lists");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("app_id", appId);
					map.put("uid", uid);
					map.put("omoney", ProductMoney);
					map.put("productId", ProductId);
					map.put("productName", ProductName);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取优惠券信息 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					// rdata =
					// "{\"status\":200,\"msg\":\"\u67e5\u8be2\u6210\u529f\",\"data\":{\"useable\":[{\"cid\":\"12345677abce\",\"value_type\":\"0\",\"value\":\"256\",\"limit\":\"\"},{\"cid\":\"12345678abce\",\"value_type\":\"1\",\"value\":\"0.80\",\"limit\":\"\"},{\"cid\":\"12345679abce\",\"value_type\":\"0\",\"value\":\"1001\",\"limit\":\"\"}],\"unuseable\":[{\"cid\":\"12345678abcd\",\"value_type\":\"0\",\"value\":\"127.99\",\"limit\":\"\"}]}}";
					// rdata =
					// "{\"status\":200,\"msg\":\"\u67e5\u8be2\u6210\u529f\",\"data\":{\"useable\":[],\"unuseable\":[{\"cid\":\"12345678abcd\",\"value_type\":\"0\",\"value\":\"127.99\",\"limit\":\"\"}]}}";
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					// 优惠券信息
					JSONObject data = userJson.getJSONObject("data");
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(data);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取优惠券信息异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取充值记录信息 */
	public static void GetChargeRecodeList(final Context context, final String uid, final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/Order/orderRecord");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uid", uid);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取充值记录 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					// 解析活动列表信息
					JSONArray data = userJson.getJSONArray("data");			// 获取活动列表数组
					
					ChargeRecord_T[] Array = new ChargeRecord_T[data.length()];
					for (int i = 0; i < data.length(); i++)
					{
						JSONObject obj = data.getJSONObject(i);
						
						String id = obj.optString("id", "");
						String chargeTime = obj.optString("chargeTime", "");
						String appName = obj.optString("app_name", "");
						// String appName = "红警争霸战国内渠道版红警争霸战国内渠道版";
						String money = obj.optString("money", "");
						
						Array[i] = new ChargeRecord_T(id, chargeTime, appName, money);
					}
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(Array);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取充值记录异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	

	/** 通知服务器，指定的订单支付已失败或取消 */
	public static void OrderFail(final Context context, final String uid, final String LtOrderId, final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/Order/cancelOrder");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("userId", uid);
					map.put("order_id", LtOrderId);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "通知服务器取消指定的订单 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							if(call != null) call.OnSuccess();
							break;
						
						default:		// 失败
							if(call != null) call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "通知服务器取消指定的订单异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	
	/** 调用接口重置用户密码 */
	public static void ResetNickname(final Context context, final String uid, final String nickname, final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					String Url = LtpayConfig.URL(context, "/User/modifyNname");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uid", uid);
					map.put("nname", nickname);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "修改昵称 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					// Tools.showText(msg);
					Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess();
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "修改昵称异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 上传用户头像 */
	public static void UploadPhoto(final Context context, final String uid, final String picData, final String picIndex, final CallBack call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					// String Url = LtpayConfig.URL(context, "/User/uploadPhoto");
					String Url = LtpayConfig.URL(context, "/User/modifyHeadPic");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uid", uid);
					// map.put("picData", picData);
					map.put("head_pic", picData);
					if (!picIndex.equals("-1") && !picIndex.equals(""))
					{
						map.put("head_index", picData);
					}
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "post");
					Log.d(Tools.TAG, "上传用户头像 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess();
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "上传用户头像异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取用户头像 */
	public static void getPhoto(final Context context, final String uid, final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					// String Url = LtpayConfig.URL(context, "/User/getPhoto");
					String Url = LtpayConfig.URL(context, "/User/getUserInfo");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uid", uid);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取用户头像 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					JSONObject data = userJson.getJSONObject("data");
					String picData = data.optString("head_img", "");
					
					JSONArray pics = data.getJSONArray("heads");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(picData, pics);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取用户头像异常！");
					ex.printStackTrace();
				}
			}
		});
	}
	
	/** 获取用户余额 */
	public static void getBalance(final Context context, final String uid, final CallBack2 call)
	{
		FJThread.getCachedPool().execute(new Runnable()
		{
			@Override
			public void run()
			{
				try
				{
					// String Url = LtpayConfig.URL(context, "/User/getPhoto");
					String Url = LtpayConfig.URL(context, "/Order/balance");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("uid", uid);
					Tools.AddSign(map, Url);
					
					String rdata = FJHttp.request(Url, map, "get");
					Log.d(Tools.TAG, "获取用户余额 ->> " + Url + "?" + FJHttp.praseMap(map, FJHttp.DEFAULT_CHARSET));	// 请求参数信息
					Log.d(Tools.TAG, "服务器返回信息 ->> " + rdata);
					
					JSONObject userJson = new JSONObject(rdata);
					int status = userJson.getInt("status");
					String msg = userJson.getString("msg");
					
					JSONObject data = userJson.getJSONObject("data");
					String balance = data.optString("balance", "0");
					
					Tools.showText(msg);
					// Tools.showToast(context, msg);
					
					switch (status)
					{
						case 200:		// 成功
							call.OnSuccess(balance);
							break;
						
						default:		// 失败
							call.Onfail();
							break;
					}
				}
				catch (Exception ex)
				{
					Tools.showToast(context, "获取用户余额异常！");
					ex.printStackTrace();
				}
			}
		});
	}
}
