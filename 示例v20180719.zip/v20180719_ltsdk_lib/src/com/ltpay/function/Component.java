﻿
package com.ltpay.function;

import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.ToggleButton;


/** Componet.java: ----- 2018-6-7 上午11:00:03 wangzhongyuan */
public class Component
{
	/** 获取资源id */
	public static int getId(Context context, String name, String defType)
	{
		return context.getResources().getIdentifier(name, defType, context.getPackageName());
	}
	
	Activity context;
	OnClickListener clickListener;
	
	HashMap<String, View> Views = new HashMap<String, View>();
	
	public Component(Activity activity, ClickListener listener, String... Id)
	{
		this.context = activity;
		final ClickListener listener0 = listener;
		
		// 映射事件处理逻辑
		clickListener = new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				for (String key : Views.keySet())
				{
					if (Views.get(key) == v)
					{
						if (listener0 != null) listener0.Click(key);
					}
				}
			}
		};
		
		// 初始获取Id对应的所有控件
		if (Id != null) AddView(Id);
	}
	
	/** 记录Id对应控件 */
	public void AddView(String... Id)
	{
		for (String id : Id)
		{
			if (!id.equals("") && !Views.containsKey(id))
			{
				try
				{
					View view = context.findViewById(getId(context, id, "id"));
					Views.put(id, view);
					
					view.setOnClickListener(clickListener);
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
					Tools.showToast(context, ex.toString());
				}
			}
		}
	}
	
	/** 获取Id对应控件 */
	public View GetView(String Id)
	{
		if (!Views.containsKey(Id)) AddView(Id);
		return Views.get(Id);
	}
	
	public TextView TextView(String Id)
	{
		return (TextView) GetView(Id);
	}
	
	public EditText EditText(String Id)
	{
		return (EditText) GetView(Id);
	}
	
	public Button Button(String Id)
	{
		return (Button) GetView(Id);
	}
	
	public RadioButton RadioButton(String Id)
	{
		return (RadioButton) GetView(Id);
	}
	
	public LinearLayout LinearLayout(String Id)
	{
		return (LinearLayout) GetView(Id);
	}
	
	public ImageView ImageView(String Id)
	{
		return (ImageView) GetView(Id);
	}
	
	public ToggleButton ToggleButton(String Id)
	{
		return (ToggleButton) GetView(Id);
	}
	
	/** View控件点击回调处理逻辑 */
	public abstract static interface ClickListener
	{
		public abstract void Click(String viewId);
	}
}
