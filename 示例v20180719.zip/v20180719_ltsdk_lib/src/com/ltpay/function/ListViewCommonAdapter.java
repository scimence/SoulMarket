﻿
package com.ltpay.function;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

import com.joymeng.payment.util.ResUtil;


/** ListAdapter.java:让IteamDatas中的数据按照布局layoutName进行显示 ----- 2018-6-7 下午4:18:10 wangzhongyuan */
public abstract class ListViewCommonAdapter<TE> extends ArrayAdapter<TE>
{
	LayoutInflater layoutInflater;
	int resourceId;
	
	Context context;
	TE iteams[];
	
	/** 指定列表项布局、数据构建Adaper */
	public ListViewCommonAdapter(Context context, String layoutName, TE[] IteamDatas)
	{
		super(context, 0, IteamDatas); 				// 调用数组适配器，进行初始化
		
		this.context = context;
		this.iteams = IteamDatas;
		
		this.resourceId = ResUtil.getId(context, layoutName, "layout");	// listView项布局资源id
		layoutInflater = LayoutInflater.from(context);  				// 获取LayoutInflater服务
	}
	
	/** 获取指定postion位置的列表项对应视图，list列表项view生成 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		// 从预定义的xml布局创建新的view视图
		if (convertView == null) convertView = layoutInflater.inflate(resourceId, null);
		
		// 修改视图中的信息
		TE iteam = getItem(position);   			// 获取position个位置的列表项数据
		
		// int textViewId = ResUtil.getId(convertView.getContext(), "ltpay_text", "id");
		// TextView textView = (TextView) convertView.findViewById(textViewId);
		// textView.setText(iteam.Title);
		setIteamView(convertView, iteam);				// 调用虚方法，设置list列表项内容
		
		return convertView;   								// 返回按给定数据显示视图
	}
	
	/** 获取列表项的指定子view */
	public View getIteamView(View iteamView, String viewId)
	{
		int id = ResUtil.getId(iteamView.getContext(), viewId, "id");
		View view = iteamView.findViewById(id);
		return view;
	}
	
	/** 设置list列表项内容 */
	public abstract void setIteamView(View iteamView, TE iteamData);
	
	// list的事件响应
	OnItemClickListener listenList = new OnItemClickListener()
	{
		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int postion, long arg3)
		{
			// Link.http(context, iteams[postion].url); // 打开该列表项对应的网址
			setIteamClick(context, iteams[postion]);
		}
	};
	
	public abstract void setIteamClick(Context iteamContext, TE iteamData);
	
	// ------------
	
	/** 生成listView */
	public ListView getListView()
	{
		ListView list = new ListView(context);				// 创建listView
		list.setDivider(new ColorDrawable(Color.GRAY));  	// 设置分割线颜色
		list.setDividerHeight(1);							// 设置分割线尺寸
		
		list.setAdapter(this);					// 为列表添加显示数据
		list.setOnItemClickListener(this.listenList);
		
		return list;
	}
}
