﻿
package com.ltpay.floatView;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.joymeng.payment.util.ResUtil;
import com.ltpay.LtSDK;
import com.ltpay.function.Tools;


// AbdroidManifest.xml中添加以下配置:

//<!-- 悬浮窗所需权限 -->
//<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

// 注册当前悬浮窗服务
//<service
//    android:name="com.ltpay.floatView.FloatService"
//    android:enabled="true"
//    android:exported="true" >
//</service>

/** FloatService.java: 安卓悬浮窗 ----- 2018-6-15 上午11:49:11 wangzhongyuan */
public class FloatService extends Service
{
	/** 显示悬浮窗 */
	public static void ShowFloat(Context context)
	{
		if (Instance == null)
		{
			Intent intent = new Intent(context, FloatService.class);
			context.startService(intent);
			
			Tools.showText("ShowFloat()");
		}
	}
	
	/** 关闭悬浮窗 */
	public static void HideFloat()
	{
		// Intent intent = new Intent(context, FloatService.class);
		// context.stopService(intent);
		
		if (Instance != null)
		{
			Instance.Hide();
			Tools.showText("HideFloat()");
		}
	}
	
	// -----------------------
	
	private static FloatService Instance;
	
	@Override
	public void onCreate()
	{
		super.onCreate();
		Instance = this;
		
		SetFloatView();
	}
	
	@Override
	public IBinder onBind(Intent intent)
	{
		return null;
	}
	
	/** 移除悬浮窗，停止服务 */
	public void Hide()
	{
		Instance = null;
		
		manager.removeView(mFloatLayout);	// 移除悬浮窗
		this.stopSelf();					// 停止服务
		this.onDestroy();
	}
	
	WindowManager manager;
	
	LinearLayout mFloatLayout;
	ImageView mFloatView;
	
	WindowManager.LayoutParams params;
	
	private void SetFloatView()
	{
		// 从布局文件，生成悬浮窗
		LayoutInflater inflater = LayoutInflater.from(getApplication());
		
		int id = ResUtil.getId(Instance, "ltpay_layout_float_view", "layout");
		mFloatLayout = (LinearLayout) inflater.inflate(id, null);
		
		// 添加悬浮窗至系统服务
		params = getParams();
		manager = (WindowManager) getApplication().getSystemService(getApplication().WINDOW_SERVICE);
		manager.addView(mFloatLayout, params);
		
		// 浮动窗口按钮
		int imageId = ResUtil.getId(Instance, "ltpay_imageView", "id");
		mFloatView = (ImageView) mFloatLayout.findViewById(imageId);
		
		mFloatLayout.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
				View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
		
		mFloatView.setOnTouchListener(touchListener);
		mFloatView.setOnClickListener(clickListener);
	}
	
	// 拖动浮标时修改浮标位置
	OnTouchListener touchListener = new OnTouchListener()
	{
		@Override
		public boolean onTouch(View v, MotionEvent event)
		{
			params.x = (int) event.getRawX() - mFloatView.getMeasuredWidth() / 2;
			params.y = (int) event.getRawY() - mFloatView.getMeasuredHeight() / 2;
			
			manager.updateViewLayout(mFloatLayout, params);
			
			return false;  // 此处必须返回false，否则OnClickListener获取不到监听
		}
	};
	
	long preClickTime = 0;
	OnClickListener clickListener = new OnClickListener()
	{
		@Override
		public void onClick(View v)
		{
			long currentTime = System.currentTimeMillis();
			if (currentTime - preClickTime <= 500)
			{
				preClickTime = 0;
				LtSDK.ShowActivityCenter();
				// Toast.makeText(FloatService.this, "onClick", Toast.LENGTH_SHORT).show();
			}
			
			preClickTime = currentTime;
		}
	};
	
	private WindowManager.LayoutParams getParams()
	{
		WindowManager.LayoutParams wmParams = new WindowManager.LayoutParams();
		wmParams.type = LayoutParams.TYPE_PHONE;   			// 设置window type
		wmParams.format = PixelFormat.RGBA_8888;   			// 设置图片格式，效果为背景透明
		wmParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE; 	// 设置浮动窗口不可聚焦（实现操作除浮动窗口外的其他可见窗口的操作）
		wmParams.gravity = Gravity.LEFT | Gravity.TOP;		// 调整悬浮窗显示的停靠位置为左侧置顶
		
		// 以屏幕左上角为原点，设置x、y初始值，相对于gravity
		// wmParams.x = 0;
		// wmParams.y = 100;
		wmParams.x = getWidth();
		wmParams.y = 15;
		
		// 设置悬浮窗口长宽数据
		wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
		wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
		
		return wmParams;
	}
	
	// 获取屏幕宽度
	private int getWidth()
	{
		Resources resources = this.getResources();
		DisplayMetrics dm = resources.getDisplayMetrics();
		float density = dm.density;
		int width = dm.widthPixels;
		int height = dm.heightPixels;
		
		return width;
	}
}
