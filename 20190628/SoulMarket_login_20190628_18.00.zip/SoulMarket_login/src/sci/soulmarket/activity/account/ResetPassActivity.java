package sci.soulmarket.activity.account;

import sci.tool.function.ActivityComponent;
import sci.tool.function.CallBack2;
import sci.tool.function.LogTool;
import sci.tool.function.Server;
import sci.tool.function.ThreadTool;
import sci.tool.function.ThreadTool.ThreadPram;
import sci.tool.function.Tools;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

public class ResetPassActivity extends ActivityComponent
{
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_reset_pass");
		
		EditText("edit_phone").setText(LoginActivity.PhoneNumber);
		EditText("edit_phone").setEnabled(false);
		
		CheckUserExist(LoginActivity.PhoneNumber);
	}

	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("dialog_header_back"))
		{
			this.finish();
		}
		else if (viewId.equals("btn_reset_pass"))
		{
			String smsNumber = localInfo.get("smsNumber");	
			if (smsNumber.equals(""))
			{
				SetTip("未获取到服务器smsNumber信息，无法注册！");
				return;
			}
			
			final String PhoneNumber = EditText("edit_phone").getText().toString().trim();
			if (PhoneNumber.equals(""))
			{
				SetTip("未获取到当前手机号信息，无法注册！");
				return;
			}
			
			final String password = EditText("edit_password").getText().toString().trim();
			if (password.equals("") || password.length() < 5)
			{
				SetTip("请输入密码，长度大于5位");
				return;
			}
			
			// 发送注册短信
			String EPASS = Tools.EPassword(password);
			String msg = "MarketReset(" + EPASS + ")";
			LogTool.showText(PhoneNumber + " " + msg);
			
			boolean result = Tools.SendSMS(smsNumber, msg);
			if(result)
			{
				localInfo.put("uname", PhoneNumber);
				localInfo.put("password", password);
				
				LogTool.showToastFrorce(context, "密码重置信息已发送！");
				LogTool.showToastFrorce(context, "请稍候进行登录");
				
				context.finish();
				Tools.ShowActivity(context, LoginActivity.class); // 跳转登录界面
			}
			else SetTip("密码重置信息发送失败！");
		}
	}	

	// 设置点击按钮是否可用
	private void setClickAble(final boolean clickable)
	{
		ThreadTool.RunInMainThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				Button("btn_reset_pass").setEnabled(clickable);
				
				int gray = Color.parseColor("#b9b9b9");
				int blue = Color.parseColor("#5677fc");
				Button("btn_reset_pass").setTextColor(clickable ? blue : gray);
			}
		});
	}

	/** 显示提示信息 */
	private void SetTip(final String msg)
	{
		final TextView text = TextView("textTip");
		
		ThreadTool.RunInMainThread(new ThreadPram()
		{
			@Override
			public void Function()
			{
				text.setText("提示：" + msg);
				text.setTextColor(Color.RED);
			}
		});
	}
	
	/** 检测用户是否已存在 */
	private void CheckUserExist(final String NAME)
	{
		CallBack2 call = new CallBack2()
		{
			@Override
			public void OnSuccess(Object... data)	
			{
				setClickAble(true);			// 若账号存在，则允许修改密码
				SetTip((String) data[0]);
			}
			
			@Override
			public void Onfail(Object... data)
			{
				setClickAble(false);
				SetTip((String) data[0]);
			}
		};
		
		Server.CheckUser(context, NAME, call);
	}
}
