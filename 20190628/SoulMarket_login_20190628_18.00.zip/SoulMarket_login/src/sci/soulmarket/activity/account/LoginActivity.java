
package sci.soulmarket.activity.account;

import sci.tool.function.ActivityComponent;
import sci.tool.function.CallBack2;
import sci.tool.function.LogTool;
import sci.tool.function.SIM;
import sci.tool.function.Server;
import sci.tool.function.Tools;
import android.os.Bundle;
import android.text.InputType;


public class LoginActivity extends ActivityComponent
{
	boolean showPassword = false;		// 是否显示密码
	boolean saveAccountInfo = true;		// 是否保存帐号、密码信息
	
	public static String PhoneNumber = "";	// 当前手机号
	
	/** 设置界面显示 */
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("layout_login");
		
		PhoneNumber = SIM.getPhoneNumber(this);
		loadAccountInfo();
		
		loadAppConfig();	// 载入服务器配置信息
	}
	
	/** 按钮点击响应逻辑 */
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("btn_login"))
		{
			final String name = EditText("edit_account").getText().toString();
			final String password = EditText("edit_password").getText().toString();
			
			CallBack2 call = new CallBack2()
			{
				@Override
				public void Onfail(Object... data)
				{
					LogTool.showToastFrorce(context, data[0].toString());
					
					localInfo.put("ID", "");
					localInfo.put("token", "");
					localInfo.put("NickName", "");
				}
				
				@Override
				public void OnSuccess(Object... data)
				{
					LogTool.showToastFrorce(context, data[0].toString());
					
					// 记录账号密码信息
					localInfo.put("uname", name);
					localInfo.put("password", password);
					
					// 记录登录后的相关参数
					localInfo.put("ID", data[1].toString());
					localInfo.put("token", data[2].toString());
					localInfo.put("NickName", data[3].toString());
					
					context.finish();
				}
			};
			
			Server.UserLogin(context, name, Tools.EPassword(password), call);
		}
		else if (viewId.equals("password_eye"))
		{
			showPassword = !showPassword;
			if (showPassword)
				EditText("edit_password").setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			else EditText("edit_password").setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
		}
		else if (viewId.equals("btn_register"))
		{
			Tools.ShowActivity(context, RegisterActivity.class);  // 跳转注册界面
			this.finish();
		}
		else if (viewId.equals("btn_foget"))
		{
			Tools.ShowActivity(context, ResetPassActivity.class); // 跳转重置密码界面
			this.finish();
		}
	}
	
	// 设置是否记住帐号密码信息
	private void setSaveState(boolean save)
	{
		saveAccountInfo = save;
	}
	
	// 保存帐号信息
	private void SaveAccountInfo(/* String uname, String password */)
	{
		String uname = EditText("edit_account").getText().toString();
		String password = EditText("edit_password").getText().toString();
		
		localInfo.put("isSaved", saveAccountInfo + "");
		if (saveAccountInfo)
		{
			localInfo.put("uname", uname);
			localInfo.put("password", password);
		}
		else
		{
			localInfo.put("uname", "");
			localInfo.put("password", "");
		}
	}
	
	// 载入本地帐号信息
	public void loadAccountInfo()
	{
		boolean isSaved = localInfo.get("isSaved").equals("true");
		setSaveState(isSaved);	// 显示是否保存帐号
		
		String uname = localInfo.get("uname");
		if (uname.equals("")) uname = PhoneNumber;
		String password = localInfo.get("password");
		
		EditText("edit_account").setText(uname);
		EditText("edit_password").setText(password);
	}
	
	/** 载入服务器配置信息 */
	private void loadAppConfig()
	{
		CallBack2 call = new CallBack2()
		{
			@Override
			public void Onfail(Object... data)
			{
				Tools.showText(data[0].toString());
			}
			
			@Override
			public void OnSuccess(Object... data)
			{
				String smsNumber = data[1].toString();
				localInfo.put("smsNumber", smsNumber);
			}
		};
		
		Server.GetAppConfig(this, call);
	}
	
}

