package sci.tool.function;


/** CallBackF.java: ----- 2018-6-6 下午5:50:22 wangzhongyuan */
public interface CallBackF
{
    // 回调处理逻辑
    public void F();
}

