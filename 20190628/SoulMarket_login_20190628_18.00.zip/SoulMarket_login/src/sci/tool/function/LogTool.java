package sci.tool.function;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class LogTool
{
	// --------------
	
	public static String TAG = "Market";
	public static boolean needShowToast = false;		// 是否已Toast形式，显示异常提示信息
	public static boolean ShowDebugInfo = true;			// 是否显示ShowDebugInfo调试信息
	
	public static void showToast(final Context context, final String info)
	{
		if (!ShowDebugInfo) return;
		
		ThreadTool.RunInMainThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				Log.d(TAG, info);
				if (needShowToast) Toast.makeText(context, info, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	public static void showToastFrorce(final Context context, final String info)
	{
		ThreadTool.RunInMainThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				Log.d(TAG, info);
				Toast.makeText(context, info, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	public static void showText(final String info)
	{
		if (!ShowDebugInfo) return;
		
		ThreadTool.RunInMainThread(new ThreadTool.ThreadPram()
		{
			@Override
			public void Function()
			{
				// 在主线程执行逻辑
				Log.d(TAG, info);
			}
		});
	}
	
	// --------------
}
