﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SoulMarket
{
    /// <summary>
    /// 对所有请求数据进行统一处理
    /// </summary>
    public partial class Request : System.Web.UI.Page
    {
        Dictionary<string, string> paramDic = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            String param = ScTool.getParam(Request, this);
            paramDic = ScTool.ToParamsDic(param);

            if (paramDic.ContainsKey("TYPE"))
            {
                string TYPE = paramDic["TYPE"].Trim().ToLower();
                string NAME = !paramDic.ContainsKey("NAME") ? null : paramDic["NAME"];
                string PASS = !paramDic.ContainsKey("PASS") ? null : paramDic["PASS"];

                string data = "";

                if (TYPE.Equals("checkuser"))
                {
                    data = SoulMarket.User.checkUser(NAME);
                }
                else if (TYPE.Equals("login"))
                {
                    data = SoulMarket.User.login(NAME, PASS);
                }
                else if (TYPE.Equals("checktoken"))
                {
                    data = SoulMarket.User.checkToken(paramDic["ID"], paramDic["token"]);
                }
                else if (TYPE.Equals("logout"))
                {
                    data = SoulMarket.User.logout(NAME, PASS);
                }

                if (!data.Equals("")) data = Encoder.Encode(data);   // 对数据进行加密
                Response.Write(data);
            }
        }


    }
}